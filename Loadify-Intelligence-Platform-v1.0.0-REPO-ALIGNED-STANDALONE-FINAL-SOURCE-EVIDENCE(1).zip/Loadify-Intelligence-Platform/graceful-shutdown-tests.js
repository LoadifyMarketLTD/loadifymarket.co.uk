'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const {createShutdownHandler}=require('./server');

test('graceful shutdown closes idle connections and cleans up once on normal close',async()=>{
  let closeCalls=0,idleCalls=0,allCalls=0,cleanupCalls=0,exitCalls=0;
  const runtimeServer={close(cb){closeCalls++;setImmediate(cb);},closeIdleConnections(){idleCalls++;},closeAllConnections(){allCalls++;}};
  await new Promise((resolve,reject)=>{
    const shutdown=createShutdownHandler({runtimeServer,cleanup:()=>cleanupCalls++,exitFn:code=>{try{exitCalls++;assert.equal(code,0);resolve();}catch(e){reject(e)}},graceMs:40});
    shutdown();shutdown();
  });
  assert.equal(closeCalls,1);assert.equal(idleCalls,1);assert.equal(allCalls,0);assert.equal(cleanupCalls,1);assert.equal(exitCalls,1);
});

test('graceful shutdown force-closes lingering connections after a bounded grace window',async()=>{
  let allCalls=0,cleanupCalls=0;
  const runtimeServer={close(){},closeIdleConnections(){},closeAllConnections(){allCalls++;}};
  const keepAlive=setTimeout(()=>{},100);
  await new Promise(resolve=>{
    const shutdown=createShutdownHandler({runtimeServer,cleanup:()=>cleanupCalls++,exitFn:()=>resolve(),graceMs:15});shutdown();
  });
  clearTimeout(keepAlive);
  assert.equal(allCalls,1);assert.equal(cleanupCalls,1);
});
