'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const {buildIndex,serialize}=require('./build-capability-evidence-index');
const registry=JSON.parse(fs.readFileSync('./data/feature-registry.json','utf8'));
const checked=fs.readFileSync('./data/capability-evidence-index.json','utf8');
test('capability evidence index is deterministically reproducible from canonical registry and bundle config',()=>{
  const generated=serialize(buildIndex(registry));
  assert.equal(generated,checked);
});
test('capability evidence index preserves honest direct versus module-bundle evidence semantics',()=>{
  const index=buildIndex(registry);
  const scopes=registry.reduce((a,f)=>(a[f.evidenceScope]=(a[f.evidenceScope]||0)+1,a),{});
  assert.ok(scopes.MODULE_BUNDLE>0);
  assert.ok(scopes.DIRECT>0);
  for(const f of registry){
    const b=index.bundles[index.features[f.id]];
    assert.equal(b.scope,f.evidenceScope,f.id);
  }
});
