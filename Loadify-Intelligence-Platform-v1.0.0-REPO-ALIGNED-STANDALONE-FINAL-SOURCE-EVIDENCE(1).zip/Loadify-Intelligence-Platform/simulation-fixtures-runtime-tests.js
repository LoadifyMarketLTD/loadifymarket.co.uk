'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const path=require('path');
const sim=require('./lib/simulation-engine');
const {server}=require('./server');
let base;
test.before(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));base=`http://127.0.0.1:${server.address().port}`;});
test.after(async()=>new Promise(r=>server.close(r)));

test('synthetic evidence and immune fixtures declare non-production provenance',()=>{
 const f=sim.fixtures({seed:'x'});assert.equal(f.live,false);assert.equal(f.provenance.kind,'SYNTHETIC');assert.equal(f.provenance.authoritativeForProduction,false);assert.ok(f.evidence.length>=5);assert.ok(f.immuneCases.length>=5);
});

test('fixtures endpoint exposes canonical synthetic fixtures',async()=>{
 const r=await fetch(base+'/api/simulation/fixtures?seed=fixture-test');assert.equal(r.status,200);const f=await r.json();assert.equal(f.seed,'fixture-test');assert.equal(f.live,false);assert.equal(f.provenance.authoritativeForProduction,false);
});

test('front-end hydrates evidence and immune fixtures from runtime',()=>{
 const src=fs.readFileSync(path.join(__dirname,'app.js'),'utf8');assert.match(src,/api\('\/api\/simulation\/fixtures\?seed=lip-baseline-2026'\)/);assert.match(src,/state\.syntheticFixtures/);assert.doesNotMatch(src,/const evidence = \[/);assert.doesNotMatch(src,/const immuneCases = \[/);
});
