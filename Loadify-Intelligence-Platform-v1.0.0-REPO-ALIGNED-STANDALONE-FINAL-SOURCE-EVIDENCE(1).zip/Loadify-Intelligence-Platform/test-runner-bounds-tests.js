'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const runner=require('./test-runner');

test('test runner records execution time and bounded successful output',()=>{
  const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'lip-runner-ok-'));const file=path.join(tmp,'ok.js');fs.writeFileSync(file,"console.log('ok')\n");
  const r=runner.runSuiteFile(file,{suite:'fixture-ok.js',timeoutMs:1000});
  assert.equal(r.passed,true);assert.equal(r.timedOut,false);assert.ok(r.executionMs>=0);assert.match(r.stdout,/ok/);fs.rmSync(tmp,{recursive:true,force:true});
});

test('test runner kills a hung suite at the configured timeout instead of hanging the release gate',()=>{
  const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'lip-runner-timeout-'));const file=path.join(tmp,'hang.js');fs.writeFileSync(file,'setInterval(()=>{},1000)\n');
  const r=runner.runSuiteFile(file,{suite:'fixture-hang.js',timeoutMs:80});
  assert.equal(r.passed,false);assert.equal(r.timedOut,true);assert.equal(r.errorCode,'ETIMEDOUT');assert.ok(r.executionMs<1000);fs.rmSync(tmp,{recursive:true,force:true});
});

test('test runner publishes explicit finite resource limits',()=>{
  assert.equal(runner.DEFAULT_SUITE_TIMEOUT_MS,30_000);assert.equal(runner.MAX_TEST_OUTPUT_BYTES,8*1024*1024);
});
