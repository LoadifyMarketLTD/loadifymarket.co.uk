'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const {server}=require('./server');
let base;test.before(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));base=`http://127.0.0.1:${server.address().port}`});test.after(async()=>new Promise(r=>server.close(r)));
test('request budget posture is observable',async()=>{const r=await fetch(base+'/api/security/request-budget/posture');assert.equal(r.status,200);const j=await r.json();assert.equal(j.enabled,true);assert.equal(j.externalDependency,false);assert.equal(j.policy.readLimit,120)});
test('runtime rejects unbounded read consumption with retry guidance',async()=>{let last;for(let i=0;i<120;i++)last=await fetch(base+'/api/health');assert.equal(last.status,429);assert.ok(Number(last.headers.get('retry-after'))>=1);const j=await last.json();assert.equal(j.error,'REQUEST_BUDGET_EXCEEDED');assert.equal(j.budget.kind,'read')});
