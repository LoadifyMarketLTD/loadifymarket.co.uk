'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const crypto=require('node:crypto');
const {Readable}=require('node:stream');
const srv=require('./server');
const admission=require('./lib/http-admission-engine');

function streamRequest(bytes,headers={}){
  const req=Readable.from(bytes.length?[bytes]:[]);
  req.headers={...headers};
  req.method='POST';
  req.url='/api/policy/evaluate';
  req.rawHeaders=Object.entries(req.headers).flatMap(([k,v])=>[k,String(v)]);
  return req;
}

test('request body digest binds to exact received UTF-8 bytes rather than a re-encoded string',async()=>{
  const raw=Buffer.from('{"text":"é"}','utf8');
  const req=streamRequest(raw,{'content-type':'application/json','content-length':String(raw.length)});
  const parsed=await srv.bodyJson(req);
  assert.equal(parsed.text,'é');
  assert.equal(req._lipRawBodyBytes,raw.length);
  assert.equal(req._lipBodyDigest,crypto.createHash('sha256').update(raw).digest('hex'));
});

test('invalid UTF-8 JSON fails closed before parsing or idempotency binding',async()=>{
  const raw=Buffer.from([0x7b,0x22,0x78,0x22,0x3a,0x22,0xc3,0x28,0x22,0x7d]);
  const req=streamRequest(raw,{'content-type':'application/json','content-length':String(raw.length)});
  await assert.rejects(()=>srv.bodyJson(req),e=>e&&e.code==='INVALID_UTF8_JSON'&&e.status===400);
  assert.equal(req._lipBodyDigest,undefined);
});

test('declared Content-Length must equal received body bytes at the body boundary',async()=>{
  const raw=Buffer.from('{}');
  const req=streamRequest(raw,{'content-type':'application/json','content-length':'3'});
  await assert.rejects(()=>srv.bodyJson(req),e=>e&&e.code==='CONTENT_LENGTH_MISMATCH'&&e.status===400);
});

test('GET and HEAD request bodies and HTTP trailers are rejected at metadata admission',()=>{
  const base={url:'/api/health',socket:{},rawHeaders:[]};
  let req={...base,method:'GET',headers:{'content-length':'1'},rawHeaders:['content-length','1']};
  let out=srv.requestMetadataBoundary(req);assert.equal(out.allowed,false);assert.equal(out.error,'REQUEST_BODY_NOT_ALLOWED_FOR_METHOD');
  req={...base,method:'HEAD',headers:{'transfer-encoding':'chunked'},rawHeaders:['transfer-encoding','chunked']};
  out=srv.requestMetadataBoundary(req);assert.equal(out.allowed,false);assert.equal(out.error,'REQUEST_BODY_NOT_ALLOWED_FOR_METHOD');
  req={...base,method:'POST',headers:{trailer:'x-test'},rawHeaders:['trailer','x-test']};
  out=srv.requestMetadataBoundary(req);assert.equal(out.allowed,false);assert.equal(out.error,'HTTP_TRAILERS_NOT_SUPPORTED');
});

test('unsafe integer precision is rejected from JSON structures',()=>{
  const out=admission.validateJsonStructure(JSON.parse('{"amount":9007199254740993}'));
  assert.equal(out.allowed,false);assert.equal(out.error,'UNSAFE_JSON_NUMBER');
  assert.equal(admission.validateJsonStructure({amount:Number.MAX_SAFE_INTEGER}).allowed,true);
});
