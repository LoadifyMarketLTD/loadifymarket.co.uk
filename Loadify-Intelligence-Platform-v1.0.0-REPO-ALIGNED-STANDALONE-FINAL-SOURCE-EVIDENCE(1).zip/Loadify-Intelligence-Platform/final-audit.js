'use strict';
const fs=require('fs');
const path=require('path');
const cp=require('child_process');
const http=require('http');
const net=require('net');
const os=require('os');
const crypto=require('crypto');
const ROOT=__dirname;
const REPORT=path.join(ROOT,'data','final-audit-report.json');
function runSync(args,{cwd=ROOT,env=process.env,timeout=180_000}={}){const r=cp.spawnSync(process.execPath,args,{cwd,env,encoding:'utf8',maxBuffer:24*1024*1024,timeout,killSignal:'SIGKILL'});return {ok:r.status===0&&!r.error,status:r.status,errorCode:r.error?.code||null,stdout:r.stdout||'',stderr:r.stderr||''};}
function request(port,p,{method='GET',headers={},body=null}={}){return new Promise((resolve,reject)=>{const payload=body===null?null:Buffer.isBuffer(body)?body:Buffer.from(String(body));const req=http.request({host:'127.0.0.1',port,path:p,method,headers:{Host:`127.0.0.1:${port}`,...headers,...(payload&&!Object.keys(headers).some(k=>k.toLowerCase()==='content-length')?{'Content-Length':String(payload.length)}:{})}},res=>{const chunks=[];res.on('data',c=>chunks.push(c));res.on('end',()=>{const raw=Buffer.concat(chunks);let json=null;try{json=JSON.parse(raw.toString('utf8'))}catch{}resolve({status:res.statusCode,headers:res.headers,raw,text:raw.toString('utf8'),body:json})})});req.on('error',reject);req.setTimeout(2500,()=>req.destroy(new Error('timeout')));if(payload)req.write(payload);req.end();});}
async function waitJson(port,p,attempts=80){let last;for(let i=0;i<attempts;i++){try{const r=await request(port,p);if(r.body)return r;}catch(e){last=e;}await new Promise(r=>setTimeout(r,100));}throw last||new Error('STARTUP_TIMEOUT');}
function reservePort(){return new Promise((resolve,reject)=>{const s=net.createServer();s.unref();s.on('error',reject);s.listen(0,'127.0.0.1',()=>{const port=s.address().port;s.close(e=>e?reject(e):resolve(port));});});}
function spawnRuntime(cwd,port){const child=cp.spawn(process.execPath,['server.js'],{cwd,env:{...process.env,PORT:String(port),LIP_PRINT_TOOLING_TOKEN:'0'},stdio:['ignore','pipe','pipe']});let stdout='',stderr='';child.stdout.on('data',c=>stdout+=c.toString());child.stderr.on('data',c=>stderr+=c.toString());return{child,getOutput:()=>({stdout,stderr})};}
async function stopRuntime(runtime,{timeoutMs=5000}={}){if(!runtime?.child||runtime.child.exitCode!==null)return;runtime.child.kill('SIGTERM');await new Promise(resolve=>{let done=false;const finish=()=>{if(done)return;done=true;clearTimeout(t);resolve();};const t=setTimeout(()=>{try{runtime.child.kill('SIGKILL')}catch{}finish();},timeoutMs);runtime.child.once('exit',finish);});}
function sha256(v){return crypto.createHash('sha256').update(v).digest('hex');}
function browserHeaders({base,cookie,key,body}){return {'Content-Type':'application/json','Cookie':cookie,'Origin':base,'Sec-Fetch-Site':'same-origin','Sec-Fetch-Mode':'cors','Sec-Fetch-Dest':'empty','Idempotency-Key':key,'Idempotency-Content-Digest':sha256(Buffer.from(body))};}
async function main(){
  const startedAt=new Date().toISOString();const stages=[];let dist=null,runtimeDir=null,runtime=null;
  const stage=(name,r)=>{stages.push({name,ok:r.ok,detail:r.detail||null});if(!r.ok)throw new Error(`${name}:${r.detail||'FAILED'}`);};
  try{
    let r=runSync(['build-capability-evidence-index.js','--check']);stage('evidence-index-reproducibility',{ok:r.ok,detail:(r.stderr||r.stdout).trim()});
    r=runSync(['build-release-manifest.js']);stage('release-manifest',{ok:r.ok,detail:(r.stderr||r.stdout).trim()});
    r=runSync(['run-release-gate.js'],{timeout:240_000});stage('release-gate',{ok:r.ok,detail:(r.stderr||r.stdout).trim()});
    r=runSync(['self-check.js']);stage('source-self-check',{ok:r.ok,detail:(r.stderr||r.stdout).trim()});
    r=runSync(['build-distribution.js']);let distResult=null;try{distResult=JSON.parse(r.stdout.trim().split(/\n/).filter(Boolean).at(-1)||'{}')}catch{};dist=distResult?.path;stage('distribution-build',{ok:r.ok&&!!dist,detail:r.ok?dist:(r.stderr||r.stdout).trim()});
    r=runSync(['verify-distribution.js',dist]);stage('distribution-verify',{ok:r.ok,detail:(r.stderr||r.stdout).trim()});

    runtimeDir=fs.mkdtempSync(path.join(os.tmpdir(),'lip-final-runtime-'));fs.cpSync(dist,runtimeDir,{recursive:true});
    let port=await reservePort();runtime=spawnRuntime(runtimeDir,port);
    let health=await waitJson(port,'/api/health');stage('clean-install-health',{ok:health.status===200&&health.body?.ok===true&&health.body?.externalLiveConnections===false,detail:JSON.stringify(health.body)});
    let guardian=await request(port,'/api/guardian/readiness');stage('clean-install-guardian',{ok:guardian.status===200&&guardian.body?.ready===true&&guardian.body?.gate==='RELEASE_CANDIDATE',detail:JSON.stringify(guardian.body)});
    const statePath=path.join(runtimeDir,'data','state.json');let state=JSON.parse(fs.readFileSync(statePath,'utf8'));stage('clean-install-seed',{ok:state.revision===0&&state.mode==='SHADOW'&&state.killSwitch===false&&Array.isArray(state.auditChain)&&state.auditChain.length===0,detail:JSON.stringify({revision:state.revision,mode:state.mode,killSwitch:state.killSwitch,auditChain:state.auditChain?.length})});
    const page=await request(port,'/');const setCookie=Array.isArray(page.headers['set-cookie'])?page.headers['set-cookie'][0]:page.headers['set-cookie'];const cookie=String(setCookie||'').split(';')[0];stage('clean-install-browser-session',{ok:page.status===200&&/^LIP_LOCAL_SESSION=[a-f0-9]{64}$/.test(cookie)&&page.headers['x-frame-options']==='DENY'&&page.headers['cache-control']==='no-store'&&String(page.headers['content-security-policy']||'').includes("default-src 'self'"),detail:JSON.stringify({status:page.status,sessionIssued:Boolean(cookie),xFrameOptions:page.headers['x-frame-options'],cacheControl:page.headers['cache-control']})});
    const mutationBody=JSON.stringify({mode:'RECOMMEND'}),base=`http://127.0.0.1:${port}`;
    const unauth=await request(port,'/api/mode',{method:'POST',headers:{'Content-Type':'application/json','Origin':base,'Sec-Fetch-Site':'same-origin','Sec-Fetch-Mode':'cors','Sec-Fetch-Dest':'empty'},body:mutationBody});stage('clean-install-unauthenticated-mutation-denied',{ok:unauth.status===401&&unauth.body?.error==='LOCAL_SESSION_REQUIRED',detail:JSON.stringify(unauth.body)});
    const idemKey='FINAL-AUDIT-MODE-RECOMMEND';const authHeaders=browserHeaders({base,cookie,key:idemKey,body:mutationBody});
    const changed=await request(port,'/api/mode',{method:'POST',headers:authHeaders,body:mutationBody});stage('clean-install-authenticated-mutation',{ok:changed.status===200&&changed.body?.mode==='RECOMMEND'&&changed.body?.revision===1,detail:JSON.stringify({status:changed.status,mode:changed.body?.mode,revision:changed.body?.revision,killSwitch:changed.body?.killSwitch})});
    const replay=await request(port,'/api/mode',{method:'POST',headers:authHeaders,body:mutationBody});stage('same-process-idempotent-replay',{ok:replay.status===200&&replay.headers['idempotency-replayed']==='true'&&JSON.stringify(replay.body)===JSON.stringify(changed.body),detail:JSON.stringify({status:replay.status,replayed:replay.headers['idempotency-replayed'],mode:replay.body?.mode,revision:replay.body?.revision})});
    const healthAfter=await request(port,'/api/storage/health');stage('post-mutation-storage-health',{ok:healthAfter.status===200&&healthAfter.body?.healthy===true&&healthAfter.body?.primary?.revision===1,detail:JSON.stringify({healthy:healthAfter.body?.healthy,revision:healthAfter.body?.primary?.revision,auditChainValid:healthAfter.body?.primary?.auditChainValid,backupCount:healthAfter.body?.backupCount})});
    const drillBody='{}',drill=await request(port,'/api/storage/recovery-drill',{method:'POST',headers:browserHeaders({base,cookie,key:'FINAL-AUDIT-RECOVERY-DRILL',body:drillBody}),body:drillBody});stage('runtime-recovery-drill',{ok:drill.status===200&&drill.body?.passed===true&&drill.body?.recovered===true,detail:JSON.stringify(drill.body)});
    await stopRuntime(runtime);runtime=null;stage('runtime-lock-cleanup-after-mutation',{ok:!fs.existsSync(path.join(runtimeDir,'data','runtime.lock')),detail:null});

    port=await reservePort();runtime=spawnRuntime(runtimeDir,port);health=await waitJson(port,'/api/health');const page2=await request(port,'/');const setCookie2=Array.isArray(page2.headers['set-cookie'])?page2.headers['set-cookie'][0]:page2.headers['set-cookie'];const cookie2=String(setCookie2||'').split(';')[0],base2=`http://127.0.0.1:${port}`;
    const replayAfterRestart=await request(port,'/api/mode',{method:'POST',headers:browserHeaders({base:base2,cookie:cookie2,key:idemKey,body:mutationBody}),body:mutationBody});
    state=JSON.parse(fs.readFileSync(statePath,'utf8'));stage('restart-persistence-and-idempotent-replay',{ok:health.status===200&&state.revision===1&&state.mode==='RECOMMEND'&&replayAfterRestart.status===200&&replayAfterRestart.headers['idempotency-replayed']==='true'&&JSON.stringify(replayAfterRestart.body)===JSON.stringify(changed.body),detail:JSON.stringify({revision:state.revision,mode:state.mode,replayed:replayAfterRestart.headers['idempotency-replayed'],responseRevision:replayAfterRestart.body?.revision})});
    await stopRuntime(runtime);runtime=null;stage('runtime-lock-cleanup-after-restart',{ok:!fs.existsSync(path.join(runtimeDir,'data','runtime.lock')),detail:null});

    const distVerify=runSync(['verify-distribution.js',dist]);stage('canonical-distribution-remains-pristine',{ok:distVerify.ok,detail:(distVerify.stderr||distVerify.stdout).trim()});
    const release=JSON.parse(fs.readFileSync(path.join(ROOT,'data','release-manifest.json'),'utf8'));
    const att=JSON.parse(fs.readFileSync(path.join(ROOT,'data','test-attestation.json'),'utf8'));
    const registry=JSON.parse(fs.readFileSync(path.join(ROOT,'data','feature-registry.json'),'utf8'));
    const evidence=JSON.parse(fs.readFileSync(path.join(ROOT,'data','capability-evidence-index.json'),'utf8'));
    const report={schemaVersion:2,product:'Loadify Intelligence Platform',startedAt,completedAt:new Date().toISOString(),decision:'PASS',releaseDigest:release.releaseDigest,capabilities:registry.length,evidenceIndexed:Object.keys(evidence.features||{}).length,attestedSuites:att.suitesTotal,failedSuites:att.failedSuites,externalLiveConnections:false,cleanInstallLifecycle:'PASS',stages};
    fs.writeFileSync(REPORT,JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));return report;
  }catch(e){if(runtime)await stopRuntime(runtime).catch(()=>{});const report={schemaVersion:2,product:'Loadify Intelligence Platform',startedAt,completedAt:new Date().toISOString(),decision:'HOLD',error:String(e.message||e),stages};fs.writeFileSync(REPORT,JSON.stringify(report,null,2)+'\n');console.error(JSON.stringify(report));process.exitCode=1;return report;}
  finally{if(runtimeDir)try{fs.rmSync(runtimeDir,{recursive:true,force:true})}catch{}}
}
if(require.main===module)main();
module.exports={main,runSync,request,waitJson,reservePort,spawnRuntime,stopRuntime,browserHeaders};
