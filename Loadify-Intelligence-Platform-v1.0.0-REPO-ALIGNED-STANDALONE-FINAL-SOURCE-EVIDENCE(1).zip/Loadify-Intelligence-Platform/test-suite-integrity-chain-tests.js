'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const path=require('path');
const os=require('os');
const crypto=require('crypto');
const startup=require('./lib/runtime-startup-engine');

function sha(v){return crypto.createHash('sha256').update(v).digest('hex');}

test('release manifest declares a digest for every discovered test suite',()=>{
  const root=__dirname;
  const manifest=JSON.parse(fs.readFileSync(path.join(root,'data/release-manifest.json'),'utf8'));
  const suites=fs.readdirSync(root).filter(x=>x.endsWith('tests.js')).sort();
  assert.equal(Object.keys(manifest.testSuiteDigests||{}).length,suites.length);
  for(const suite of suites) assert.match(String(manifest.testSuiteDigests[suite]||''),/^[a-f0-9]{64}$/);
});

test('startup verifier source binds test files to release manifest and attestation',()=>{
  const src=fs.readFileSync(path.join(__dirname,'lib/runtime-startup-engine.js'),'utf8');
  assert.match(src,/RELEASE_TEST_SUITE_DIGEST_MISMATCH/);
  assert.match(src,/TEST_ATTESTATION_SUITE_DIGEST_MISMATCH/);
  assert.match(src,/TEST_ATTESTATION_UNDECLARED_SUITE/);
});
