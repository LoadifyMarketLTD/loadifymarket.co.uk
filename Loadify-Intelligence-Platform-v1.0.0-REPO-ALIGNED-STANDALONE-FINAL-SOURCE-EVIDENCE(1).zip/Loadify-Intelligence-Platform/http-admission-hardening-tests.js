'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const http=require('http');
const {server,httpAdmission,TRANSPORT_LIMITS}=require('./server');

let base,port;
test.before(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));port=server.address().port;base=`http://127.0.0.1:${port}`;});
test.after(async()=>new Promise(r=>server.close(r)));

function request({path='/api/health',method='GET',headers={},body}={}){
  return new Promise((resolve,reject)=>{
    const req=http.request({host:'127.0.0.1',port,path,method,headers},res=>{let text='';res.on('data',c=>text+=c);res.on('end',()=>resolve({status:res.statusCode,headers:res.headers,text,json:()=>JSON.parse(text||'{}')}));});
    req.on('error',reject);if(body!==undefined)req.write(body);req.end();
  });
}

test('Host authority is bound to loopback and the actual listening port',async()=>{
  const good=await request();assert.equal(good.status,200);
  const bad=await request({headers:{host:`127.0.0.1:${port+1}`}});assert.equal(bad.status,403);assert.equal(bad.json().error,'HOST_PORT_NOT_ALLOWED');
  assert.equal(httpAdmission.validateHostAuthority('localhost:1234',{expectedPort:1234}).allowed,true);
  assert.equal(httpAdmission.validateHostAuthority('localhost:1235',{expectedPort:1234}).error,'HOST_PORT_NOT_ALLOWED');
  assert.equal(httpAdmission.validateHostAuthority('localhost.'.padEnd(300,'x'),{expectedPort:80}).error,'HOST_HEADER_TOO_LARGE');
});

test('API Accept negotiation is bounded and JSON-compatible',async()=>{
  const ok=await request({headers:{accept:'application/json'}});assert.equal(ok.status,200);
  const wildcard=await request({headers:{accept:'text/plain;q=0.2, */*;q=0.1'}});assert.equal(wildcard.status,200);
  const denied=await request({headers:{accept:'text/html'}});assert.equal(denied.status,406);assert.equal(denied.json().error,'NOT_ACCEPTABLE');
  const oversized=httpAdmission.validateAcceptHeader('a'.repeat(1025));assert.equal(oversized.error,'ACCEPT_HEADER_TOO_LARGE');
  assert.equal(httpAdmission.validateAcceptHeader('application/json;q=bogus').error,'INVALID_ACCEPT_HEADER');
  assert.equal(httpAdmission.validateAcceptHeader('application/json;q=1;q=0.5').error,'INVALID_ACCEPT_HEADER');
});

test('JSON media type admission is exact and UTF-8 only',async()=>{
  const invalid=await request({path:'/api/policy/evaluate',method:'POST',headers:{'content-type':'application/jsonx'},body:'{}'});assert.equal(invalid.status,415);assert.equal(invalid.json().error,'JSON_CONTENT_TYPE_REQUIRED');
  const charset=await request({path:'/api/policy/evaluate',method:'POST',headers:{'content-type':'application/json; charset=iso-8859-1'},body:'{}'});assert.equal(charset.status,415);assert.equal(charset.json().error,'JSON_CHARSET_NOT_SUPPORTED');
  assert.equal(httpAdmission.validateJsonContentType('application/json; charset=utf-8').allowed,true);
  assert.equal(httpAdmission.validateJsonContentType('application/json; profile=x').error,'INVALID_JSON_CONTENT_TYPE');
});

test('Content-Length is canonical, safe and bounded',()=>{
  assert.equal(httpAdmission.validateContentLength('0').allowed,true);
  assert.equal(httpAdmission.validateContentLength('42').value,42);
  for(const raw of ['-1','+1','01','1.0','1e3',' 1'])assert.equal(httpAdmission.validateContentLength(raw).error,'INVALID_CONTENT_LENGTH');
  assert.equal(httpAdmission.validateContentLength('1000001',{maxBodyBytes:1_000_000}).error,'PAYLOAD_TOO_LARGE');
});

test('Node parser header count is explicitly bounded',()=>{
  assert.equal(TRANSPORT_LIMITS.maxHeadersCount,64);
  assert.equal(TRANSPORT_LIMITS.maxHeaderBytes,16384);
  assert.equal(server.maxHeadersCount,64);
  const tooMany=[];for(let i=0;i<65;i++)tooMany.push(`x-test-${i}`,'v');
  const boundary=require('./server').requestMetadataBoundary({url:'/api/health',headers:{},rawHeaders:tooMany});assert.equal(boundary.status,431);assert.equal(boundary.error,'HEADER_COUNT_LIMIT_EXCEEDED');
});

test('Expect 100-continue is refused without sending interim Continue',async()=>{
  const result=await new Promise((resolve,reject)=>{
    let continued=false;
    const req=http.request({host:'127.0.0.1',port,path:'/api/policy/evaluate',method:'POST',headers:{expect:'100-continue','content-type':'application/json','content-length':'2'}},res=>{let text='';res.on('data',c=>text+=c);res.on('end',()=>resolve({status:res.statusCode,text,continued}));});
    req.on('continue',()=>{continued=true;});req.on('error',reject);req.end('{}');
  });
  assert.equal(result.continued,false);assert.equal(result.status,417);assert.equal(JSON.parse(result.text).error,'EXPECTATION_NOT_SUPPORTED');
});

test('JSON nesting depth is fail-closed',async()=>{
  let payload={x:true};for(let i=0;i<40;i++)payload={x:payload};
  const body=JSON.stringify(payload);const r=await request({path:'/api/policy/evaluate',method:'POST',headers:{'content-type':'application/json','content-length':String(Buffer.byteLength(body))},body});
  assert.equal(r.status,413);assert.equal(r.json().error,'JSON_DEPTH_LIMIT_EXCEEDED');
});

test('Aggregate JSON key and array complexity are bounded',async()=>{
  const manyKeys={};for(let i=0;i<4100;i++)manyKeys[`k${i}`]=i;
  let body=JSON.stringify(manyKeys);let r=await request({path:'/api/policy/evaluate',method:'POST',headers:{'content-type':'application/json','content-length':String(Buffer.byteLength(body))},body});assert.equal(r.status,413);assert.equal(r.json().error,'JSON_KEY_LIMIT_EXCEEDED');
  body=JSON.stringify({items:Array.from({length:8193},(_,i)=>i)});r=await request({path:'/api/policy/evaluate',method:'POST',headers:{'content-type':'application/json','content-length':String(Buffer.byteLength(body))},body});assert.equal(r.status,413);assert.equal(r.json().error,'JSON_ARRAY_LIMIT_EXCEEDED');
});

test('Oversized JSON keys/strings and prototype-pollution keys are rejected',async()=>{
  assert.equal(httpAdmission.validateJsonStructure({['k'.repeat(257)]:1}).error,'JSON_KEY_SIZE_LIMIT_EXCEEDED');
  assert.equal(httpAdmission.validateJsonStructure({v:'x'.repeat(262145)}).error,'JSON_STRING_LIMIT_EXCEEDED');
  const body='{"__proto__":{"polluted":true}}';const r=await request({path:'/api/policy/evaluate',method:'POST',headers:{'content-type':'application/json','content-length':String(Buffer.byteLength(body))},body});assert.equal(r.status,400);assert.equal(r.json().error,'UNSAFE_JSON_KEY');assert.equal({}.polluted,undefined);
});

test('HTTP admission posture exposes the active fail-closed contract',async()=>{
  const r=await request({path:'/api/security/http-admission/posture'});assert.equal(r.status,200);const j=r.json();assert.equal(j.enabled,true);assert.equal(j.failMode,'FAIL_CLOSED');assert.equal(j.policies.hostAuthority,'LOOPBACK_AND_BOUND_PORT_ONLY');assert.equal(j.limits.maxJsonDepth,32);assert.equal(j.externalDependency,false);
});
