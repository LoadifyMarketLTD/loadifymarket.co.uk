'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const s=require('./lib/standards-governance-engine');
test('working draft cannot silently become binding policy',()=>{const r=s.canBindPolicy({status:'WORKING_DRAFT'});assert.equal(r.allowed,false)});
test('beta protocol remains experimental',()=>{assert.equal(s.classify({status:'BETA'}).experimental,true)});
test('final recommendation can be binding eligible',()=>{assert.equal(s.canBindPolicy({status:'RECOMMENDATION',adapterPolicy:'map'}).allowed,true)});
test('unsupported adapter version fails closed',()=>{const r=s.adapterVersionDecision({adapter:{id:'a',status:'ACTIVE'},standard:{id:'s'},supportedVersions:['1'],requestedVersion:'2'});assert.equal(r.allowed,false)});
test('compatibility matrix catches missing capabilities',()=>{const r=s.compatibilityMatrix({components:[{id:'a',requires:['x'],provides:[]},{id:'b',requires:[],provides:[]} ]});assert.equal(r.compatible,false)});
test('removed adapter cannot retain active dependents',()=>{const r=s.lifecycleDecision({status:'REMOVED',dependentCount:2});assert.equal(r.allowed,false)});
test('change radar requires contract tests on material version change',()=>{const r=s.changeRadar({previous:{version:'1'},current:{version:'2'},dependents:['gateway']});assert.equal(r.material,true);assert.ok(r.requiredActions.includes('RUN_CONTRACT_TESTS'))});

test('public review draft is non-binding',()=>{const r=s.canBindPolicy({status:'PUBLIC_REVIEW_DRAFT',adapterPolicy:'map'});assert.equal(r.allowed,false)});
test('final pre-effective reference is non-binding until effective',()=>{const r=s.canBindPolicy({status:'FINAL_PRE_EFFECTIVE',adapterPolicy:'map'});assert.equal(r.allowed,false)});
test('live testing registry is not a normative policy source',()=>{const r=s.canBindPolicy({status:'LIVE_REGISTRY_TESTING_AVAILABLE',adapterPolicy:'map'});assert.equal(r.allowed,false)});
test('stable standard adapter may be binding eligible',()=>{const r=s.canBindPolicy({status:'STABLE_STANDARD_ADAPTER_READY',adapterPolicy:'map'});assert.equal(r.allowed,true)});
test('unknown maturity status fails closed',()=>{const c=s.classify({status:'SOME_FUTURE_STATUS'});assert.equal(c.known,false);assert.equal(c.bindingEligible,false);assert.equal(s.canBindPolicy({status:'SOME_FUTURE_STATUS',adapterPolicy:'map'}).allowed,false)});

test('canonical standards registry entries all have authoritative identity and source',()=>{
  const fs=require('fs');
  const registry=JSON.parse(fs.readFileSync('data/standards-registry.json','utf8'));
  for(const entry of registry){
    const r=s.registryEntry(entry);
    assert.equal(r.valid,true,`${entry.name}: ${r.reasons.join(',')}`);
  }
});
