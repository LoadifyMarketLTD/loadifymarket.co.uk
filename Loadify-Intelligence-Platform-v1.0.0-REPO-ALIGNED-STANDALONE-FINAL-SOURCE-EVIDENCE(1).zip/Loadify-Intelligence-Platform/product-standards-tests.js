'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const s=require('./lib/product-standards-engine');

test('GS1 readiness normalizes valid GTIN-13 to 14 digits',()=>{
  const r=s.gs1DigitalLinkReadiness({gtin:'4006381333931'});
  assert.equal(r.ready,true); assert.equal(r.gtin14,'04006381333931'); assert.match(r.canonicalUri,/^https:\/\/id\.gs1\.org\/01\//);
});
test('GS1 readiness rejects invalid check digit',()=>{
  const r=s.gs1DigitalLinkReadiness({gtin:'4006381333932'}); assert.equal(r.ready,false); assert.ok(r.reasons.includes('GTIN_CHECK_DIGIT_INVALID'));
});
test('canonical GS1 URI cannot silently use noncanonical domain',()=>{
  const r=s.gs1DigitalLinkReadiness({gtin:'4006381333931',domain:'example.com'}); assert.equal(r.ready,false); assert.ok(r.reasons.includes('CANONICAL_URI_REQUIRES_ID_GS1_ORG'));
});
test('DPP readiness requires identifiers, carrier, access, model, integrity and lifecycle owner',()=>{
  const r=s.dppReadiness({productId:'p1'}); assert.equal(r.ready,false); assert.ok(r.reasons.includes('ECONOMIC_OPERATOR_IDENTIFIER_REQUIRED')); assert.ok(r.reasons.includes('ACCESS_RIGHTS_POLICY_REQUIRED'));
});
test('DPP readiness passes complete not-registered preparation without claiming registration',()=>{
  const r=s.dppReadiness({productId:'p1',economicOperatorId:'op1',dataCarrierType:'QR',dataLocation:'https://example.invalid/dpp/p1',accessPolicyRef:'policy://dpp-access/v1',dataModelRef:'model://dpp/category/v1',integrityProofRef:'proof://sha256/x',lifecycleOwner:'op1',registrationStatus:'NOT_REGISTERED'});
  assert.equal(r.ready,true); assert.equal(r.externalConnection,false); assert.equal(r.mode,'READINESS_ONLY');
});
test('cannot claim live DPP registration from non-live environment',()=>{
  const r=s.dppReadiness({productId:'p1',economicOperatorId:'op1',dataCarrierType:'QR',dataLocation:'x',accessPolicyRef:'a',dataModelRef:'m',integrityProofRef:'i',lifecycleOwner:'op1',registrationStatus:'REGISTERED',registryRegistrationId:'reg1',environment:'DEMO'});
  assert.equal(r.ready,false); assert.ok(r.reasons.includes('LIVE_REGISTRATION_CANNOT_BE_ASSERTED_FROM_NONLIVE_ENVIRONMENT'));
});
test('distance-selling DPP requirement fails closed if unavailable',()=>{
  const r=s.marketplaceDppExposure({dppRequired:true,dppReady:false,distanceSelling:true}); assert.equal(r.allowed,false); assert.ok(r.reasons.includes('DPP_MUST_BE_ACCESSIBLE_FOR_DISTANCE_SELLING'));
});
