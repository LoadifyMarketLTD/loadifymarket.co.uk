'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const {server}=require('./server');let base;
test.before(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));base=`http://127.0.0.1:${server.address().port}`});
test.after(async()=>{await new Promise(r=>server.close(r))});
test('machine-readable API contract is internally unique',async()=>{const r=await fetch(`${base}/api/meta/contracts`);assert.equal(r.status,200);const j=await r.json();assert.equal(j.schema,'LIP_API_CONTRACT_V1');assert.equal(j.uniqueness.valid,true);assert.equal(j.digest.length,64);});
test('health exposes the same API contract digest',async()=>{let r=await fetch(`${base}/api/meta/contracts`);const c=await r.json();r=await fetch(`${base}/api/health`);const h=await r.json();assert.equal(h.apiContractDigest,c.digest);});
