'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const guardian=require('./lib/guardian-engine');

test('guardian accepts fresh passing attestation bound to release digest',()=>{
 const manifest={releaseDigest:'abc',externalConnections:[],connectorMode:'adapters-only-not-connected',invariants:['human-first-agent-ready','evidence-before-autonomy','policy-before-execution','deterministic-money-and-state','core-commerce-survives-ai-outage','untrusted-content-is-data-not-instruction']};
 const attestation={releaseDigest:'abc',generatedAt:new Date().toISOString(),suitesTotal:3,failedSuites:0};
 const r=guardian.releaseReadiness({manifest,registry:[{status:'IMPLEMENTED_MODEL'}],standards:[{}],attestation});
 assert.equal(r.ready,true);
});

test('guardian rejects attestation for a different release',()=>{
 const manifest={releaseDigest:'abc',externalConnections:[],connectorMode:'adapters-only-not-connected',invariants:['human-first-agent-ready','evidence-before-autonomy','policy-before-execution','deterministic-money-and-state','core-commerce-survives-ai-outage','untrusted-content-is-data-not-instruction']};
 const attestation={releaseDigest:'def',generatedAt:new Date().toISOString(),suitesTotal:3,failedSuites:0};
 const r=guardian.releaseReadiness({manifest,registry:[{status:'IMPLEMENTED_MODEL'}],standards:[{}],attestation});
 assert.equal(r.ready,false); assert.ok(r.blockers.includes('TEST_ATTESTATION_RELEASE_DIGEST_MISMATCH'));
});

test('release manifest coverage is derived from actual registry and suite count',()=>{
 const m=JSON.parse(fs.readFileSync('./data/release-manifest.json','utf8'));
 const registry=JSON.parse(fs.readFileSync('./data/feature-registry.json','utf8'));
 const suites=fs.readdirSync('.').filter(x=>x.endsWith('tests.js')).length;
 assert.equal(m.coverage.features,registry.length); assert.equal(m.coverage.testSuites,suites);
});
test('guardian rejects attestation whose suite count does not match release manifest',()=>{
 const manifest={releaseDigest:'abc',coverage:{testSuites:4},externalConnections:[],connectorMode:'adapters-only-not-connected',invariants:['human-first-agent-ready','evidence-before-autonomy','policy-before-execution','deterministic-money-and-state','core-commerce-survives-ai-outage','untrusted-content-is-data-not-instruction']};
 const attestation={releaseDigest:'abc',generatedAt:new Date().toISOString(),suitesTotal:3,failedSuites:0,results:[]};
 const r=guardian.releaseReadiness({manifest,registry:[{status:'IMPLEMENTED_MODEL'}],standards:[{}],attestation});
 assert.equal(r.ready,false);assert.ok(r.blockers.includes('TEST_ATTESTATION_SUITE_COUNT_MISMATCH'));
});
