'use strict';
const test=require('node:test'); const assert=require('node:assert/strict'); const fs=require('node:fs');
const app=fs.readFileSync('app.js','utf8');
test('Diagnostics page is wired to runtime storage and audit integrity endpoints',()=>{
  assert.match(app,/Diagnostics & Recovery/);
  assert.match(app,/api\/storage\/health/);
  assert.match(app,/api\/storage\/audit-chain\/verify/);
  assert.match(app,/api\/storage\/recovery-drill/);
});
test('Diagnostics renders release and external connection state from hydrated runtime',()=>{
  assert.match(app,/state\.health/);assert.match(app,/state\.guardian/);assert.match(app,/externalLiveConnections/);assert.match(app,/connectedMarketplace/);
});

test('recovery drill reads the runtime passed contract rather than a local ok alias',()=>{assert.match(app,/recoveryDrill\.passed===true/);assert.doesNotMatch(app,/recoveryDrill\.ok===true/);});
test('audit integrity reads the verifier count contract',()=>{assert.match(app,/ai\.count\?\?0/);assert.doesNotMatch(app,/ai\.entries\?\?/);});

test('diagnostics exposes runtime backup lifecycle rather than a hardcoded posture',()=>{
  const app=fs.readFileSync('./app.js','utf8');
  assert.match(app,/st\.lifecycleHealthy/);
  assert.match(app,/st\.backupBytes/);
  assert.match(app,/Backup lifecycle/);
});
