'use strict';
const assert=require('assert');
const e=require('./lib/recovery-package-engine');
const state={schemaVersion:1,revision:2,mode:'SHADOW',killSwitch:false,approvals:[],experiments:[],flags:[],agents:[],audit:[],auditChain:[],telemetry:[]};
const pkg=e.buildExport({state,releaseManifest:{releaseDigest:'abc'},systemManifest:{version:'0.3'}});
let r=e.validateImport(pkg,{defaults:state});assert.strictEqual(r.valid,true);assert.strictEqual(r.applyAllowed,false);assert.strictEqual(r.mode,'DRY_RUN_ONLY');
const bad=JSON.parse(JSON.stringify(pkg));bad.state.mode='CONTROLLED_AUTONOMY';r=e.validateImport(bad,{defaults:state});assert.strictEqual(r.valid,false);assert(r.errors.includes('STATE_DIGEST_MISMATCH'));
const live=e.buildExport({state:{...state,externalLiveConnections:true},releaseManifest:{releaseDigest:'abc'},systemManifest:{version:'0.3'}});r=e.validateImport(live,{defaults:state});assert.strictEqual(r.valid,false);assert(r.errors.includes('LIVE_CONNECTION_STATE_NOT_ADMISSIBLE'));
console.log(JSON.stringify({ok:true}));
