#!/usr/bin/env sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT"
if ! command -v node >/dev/null 2>&1; then
  echo "Loadify Intelligence requires Node.js 20 or newer." >&2
  exit 1
fi
MAJOR=$(node -p "process.versions.node.split('.')[0]")
if [ "$MAJOR" -lt 20 ]; then
  echo "Loadify Intelligence requires Node.js 20 or newer." >&2
  exit 1
fi
node self-check.js
node server.js &
PID=$!
trap 'kill "$PID" 2>/dev/null || true' INT TERM EXIT
sleep 2
URL=http://127.0.0.1:4173
if command -v xdg-open >/dev/null 2>&1; then xdg-open "$URL" >/dev/null 2>&1 || true
elif command -v open >/dev/null 2>&1; then open "$URL" >/dev/null 2>&1 || true
else echo "Open $URL in your browser."
fi
wait "$PID"
