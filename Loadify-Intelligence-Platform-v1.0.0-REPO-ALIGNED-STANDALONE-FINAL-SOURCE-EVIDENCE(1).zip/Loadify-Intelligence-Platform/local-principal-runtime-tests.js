'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const path=require('path');
const {server,STATE_FILE}=require('./server');
let base,original;

test.before(async()=>{
  original=fs.readFileSync(STATE_FILE);
  await new Promise(r=>server.listen(0,'127.0.0.1',r));
  base=`http://127.0.0.1:${server.address().port}`;
});
test.after(async()=>{
  await new Promise(r=>server.close(r));
  fs.writeFileSync(STATE_FILE,original);
});

test('browser mutation is attributed to an ephemeral local-session principal',async()=>{
  const home=await fetch(base+'/');
  const setCookie=home.headers.get('set-cookie');
  assert.ok(setCookie && setCookie.includes('LIP_LOCAL_SESSION='));
  const cookie=setCookie.split(';')[0];
  const r=await fetch(base+'/api/mode',{method:'POST',headers:{'content-type':'application/json','origin':base,'sec-fetch-site':'same-origin','cookie':cookie},body:JSON.stringify({mode:'RECOMMEND'})});
  assert.equal(r.status,200);
  const state=await (await fetch(base+'/api/state')).json();
  const event=state.audit.find(x=>String(x.action||'').includes('Autopilot mode changed to RECOMMEND'));
  assert.ok(event);
  assert.match(event.actor,/^LOCAL-SESSION-[0-9a-f]{12}$/);
  assert.notEqual(event.actor,'LOCAL-OPERATOR-1');
});

test('approval code does not embed a persistent fictitious local operator identity',()=>{
  const source=fs.readFileSync(path.join(__dirname,'server.js'),'utf8');
  assert.doesNotMatch(source,/LOCAL-OPERATOR-1|Demo Operator/);
  assert.match(source,/requestPrincipal\(req\)/);
});
