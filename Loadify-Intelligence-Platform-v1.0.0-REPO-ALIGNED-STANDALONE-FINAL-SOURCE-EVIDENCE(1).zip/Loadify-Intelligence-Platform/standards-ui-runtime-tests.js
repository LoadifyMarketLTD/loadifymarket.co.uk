'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const path=require('path');
const {server}=require('./server');
let base;
test.before(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));base=`http://127.0.0.1:${server.address().port}`;});
test.after(async()=>new Promise(r=>server.close(r)));

test('standards endpoint serves canonical registry',async()=>{
 const r=await fetch(base+'/api/standards');assert.equal(r.status,200);const j=await r.json();
 const canonical=JSON.parse(fs.readFileSync(path.join(__dirname,'data/standards-registry.json'),'utf8'));
 assert.equal(j.count,canonical.length);assert.equal(j.items[0].id,canonical[0].id);
});

test('front-end hydrates standards from runtime instead of hardcoded planned table',()=>{
 const src=fs.readFileSync(path.join(__dirname,'app.js'),'utf8');
 assert.match(src,/api\('\/api\/standards'\)/);
 assert.match(src,/state\.standardsRecords/);
 assert.doesNotMatch(src,/\['GS1 Digital Link','Planned adapter'/);
 assert.doesNotMatch(src,/\['W3C Verifiable Credentials 2\.0','Planned adapter'/);
});

test('standards posture endpoint classifies maturity fail-closed',async()=>{
 const r=await fetch(base+'/api/standards/posture');assert.equal(r.status,200);const j=await r.json();
 assert.equal(j.unknown,0);assert.equal(j.count,j.bindingEligible+j.nonBinding);
 const byId=Object.fromEntries(j.items.map(x=>[x.id,x]));
 assert.equal(byId['STD-OWASP-AGENTIC-SKILLS-TOP10-2026'].governance.bindingEligible,false);
 assert.equal(byId['STD-GS1-DIGITAL-LINK-URI-1.7.0'].governance.bindingEligible,true);
 assert.equal(byId['STD-EU-DPP-REGISTRY-2026-07'].governance.bindingEligible,false);
});
