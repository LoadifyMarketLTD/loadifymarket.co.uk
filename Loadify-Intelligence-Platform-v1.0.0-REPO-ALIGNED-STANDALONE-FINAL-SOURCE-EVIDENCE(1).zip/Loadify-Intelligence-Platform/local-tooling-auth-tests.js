'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const {localMutationAuth}=require('./server');
test('normal standalone tooling mutations require ephemeral tooling authentication',()=>{
 assert.equal(localMutationAuth({browserContext:false,toolingValid:false,testProcess:false}).allowed,false);
 assert.equal(localMutationAuth({browserContext:false,toolingValid:true,testProcess:false}).allowed,true);
});
test('browser mutations require the ephemeral browser session',()=>{
 assert.equal(localMutationAuth({browserContext:true,sessionValid:false,testProcess:false}).allowed,false);
 assert.equal(localMutationAuth({browserContext:true,sessionValid:true,testProcess:false}).allowed,true);
});
test('test-process bypass is explicit and cannot override browser session checks',()=>{
 assert.equal(localMutationAuth({browserContext:false,toolingValid:false,testProcess:true}).allowed,true);
 assert.equal(localMutationAuth({browserContext:true,sessionValid:false,testProcess:true}).allowed,false);
});
