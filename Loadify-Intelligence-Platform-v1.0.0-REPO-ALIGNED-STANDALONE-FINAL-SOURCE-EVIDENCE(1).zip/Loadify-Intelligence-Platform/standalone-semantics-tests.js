'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const os=require('os');
const path=require('path');
const store=require('./lib/state-store-engine');
const {runtimeConfig}=require('./lib/runtime-config-engine');

test('runtime environment is standalone, not demo',()=>{
  assert.equal(runtimeConfig({}).environment,'standalone');
  const state=JSON.parse(fs.readFileSync('./data/state.json','utf8'));
  assert.equal(state.environment,'standalone');
});

test('legacy standalone-demo state is migrated without losing isolation',()=>{
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'lip-semantic-migration-'));
  const file=path.join(root,'state.json'); const backupDir=path.join(root,'backups');
  fs.writeFileSync(file,JSON.stringify({environment:'standalone-demo',connectedMarketplace:null,mode:'SHADOW',killSwitch:false,schemaVersion:1,revision:2,approvals:[],experiments:[],flags:[],agents:[{id:'A',allowed:['metadata.demo_write']}],audit:[],auditChain:[],telemetry:[]}));
  const result=store.loadState({file,backupDir,defaults:{environment:'standalone',connectedMarketplace:null,mode:'SHADOW',killSwitch:false,approvals:[],experiments:[],flags:[],agents:[],audit:[],auditChain:[],telemetry:[]}});
  assert.equal(result.state.environment,'standalone');
  assert.deepEqual(result.state.agents[0].allowed,['sandbox.metadata.write']);
  assert.equal(result.state.connectedMarketplace,null);
});

test('synthetic fixtures remain explicitly non-live and non-authoritative',()=>{
  const simulation=require('./lib/simulation-engine');
  const fixture=simulation.syntheticFixtures ? simulation.syntheticFixtures() : null;
  if (fixture) {
    assert.equal(fixture.live,false);
    assert.equal(fixture.provenance.authoritativeForProduction,false);
  } else {
    const app=fs.readFileSync('./app.js','utf8');
    assert.match(app,/SYNTHETIC|Synthetic/);
  }
});

test('historical demo labels are not used as canonical runtime semantics',()=>{
  const source=[fs.readFileSync('./server.js','utf8'),fs.readFileSync('./app.js','utf8'),fs.readFileSync('./lib/runtime-config-engine.js','utf8')].join('\n');
  assert.doesNotMatch(source,/environment:\s*['"]standalone-demo['"]/);
  assert.doesNotMatch(source,/metadata\.demo_write/);
  assert.doesNotMatch(source,/Create Demo Experiment/);
});
