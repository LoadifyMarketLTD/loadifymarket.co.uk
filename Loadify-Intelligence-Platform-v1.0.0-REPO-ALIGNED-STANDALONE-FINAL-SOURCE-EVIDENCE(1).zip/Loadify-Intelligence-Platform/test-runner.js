'use strict';
const fs=require('fs');
const path=require('path');
const crypto=require('crypto');
const cp=require('child_process');
const ROOT=__dirname;
const STATE=path.join(ROOT,'data/state.json');
const BACKUPS=path.join(ROOT,'data/state-backups');
const DEFAULT_SUITE_TIMEOUT_MS=30_000;
const MAX_TEST_OUTPUT_BYTES=8*1024*1024;
function sha256(v){return crypto.createHash('sha256').update(v).digest('hex');}
function snapshotRuntime(){
  return {state:fs.existsSync(STATE)?fs.readFileSync(STATE):null,backupNames:fs.existsSync(BACKUPS)?new Set(fs.readdirSync(BACKUPS)):new Set()};
}
function restoreRuntime(s){
  if(s.state)fs.writeFileSync(STATE,s.state);else if(fs.existsSync(STATE))fs.unlinkSync(STATE);
  if(fs.existsSync(BACKUPS))for(const n of fs.readdirSync(BACKUPS))if(!s.backupNames.has(n))fs.rmSync(path.join(BACKUPS,n),{force:true});
}
function runSuiteFile(file,{suite=path.basename(file),timeoutMs=DEFAULT_SUITE_TIMEOUT_MS,env=process.env}={}){
  const started=process.hrtime.bigint();
  const r=cp.spawnSync(process.execPath,[file],{cwd:ROOT,encoding:'utf8',env:{...env,TERM:'xterm'},timeout:timeoutMs,maxBuffer:MAX_TEST_OUTPUT_BYTES,killSignal:'SIGKILL'});
  const executionMs=Number(process.hrtime.bigint()-started)/1e6;
  const stdout=r.stdout||'',stderr=r.stderr||'';
  return {suite,suiteSha256:sha256(fs.readFileSync(file)),passed:r.status===0&&!r.error,status:r.status,signal:r.signal||null,errorCode:r.error?.code||null,timedOut:r.error?.code==='ETIMEDOUT',executionMs:Number(executionMs.toFixed(3)),stderrDigest:sha256(stderr),stdoutDigest:sha256(stdout),stdout,stderr};
}
function runTestSuites(){
  const suites=fs.readdirSync(ROOT).filter(x=>x.endsWith('tests.js')).sort();
  const before=snapshotRuntime(); const results=[];
  try{
    for(const suite of suites){
      restoreRuntime(before);
      results.push(runSuiteFile(path.join(ROOT,suite),{suite}));
    }
  } finally { restoreRuntime(before); }
  return {suites,results,failed:results.filter(x=>!x.passed)};
}
module.exports={runTestSuites,runSuiteFile,snapshotRuntime,restoreRuntime,sha256,DEFAULT_SUITE_TIMEOUT_MS,MAX_TEST_OUTPUT_BYTES};
