'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const path=require('path');
const {getPolicyBundle}=require('./lib/policy-bundle-engine');
const {getConnectorRegistry}=require('./lib/connector-registry-engine');

test('system manifest binds canonical policy and standalone connector boundary',()=>{
 const m=JSON.parse(fs.readFileSync(path.join(__dirname,'data/system-manifest.json'),'utf8'));const p=getPolicyBundle();const c=getConnectorRegistry();
 assert.equal(m.policyBundle.id,p.id);assert.equal(m.policyBundle.version,p.version);assert.equal(m.policyBundle.agentMutable,false);assert.equal(m.policyBundle.highRiskDefault,'DENY');
 assert.equal(m.connectorRegistry.liveConnectionsEnabled,c.liveConnectionsEnabled);assert.equal(m.connectorRegistry.credentialMode,'NONE');assert.equal(m.connectorMode,'adapters-only-not-connected');
});
