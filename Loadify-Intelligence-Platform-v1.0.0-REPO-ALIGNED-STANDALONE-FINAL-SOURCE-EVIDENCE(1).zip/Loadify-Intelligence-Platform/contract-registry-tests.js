'use strict';const test=require('node:test');const assert=require('node:assert/strict');const c=require('./lib/contract-registry-engine');
const base={id:'catalog.product',name:'Canonical Product',module:'Catalog',version:'1.0.0',owner:'Catalog',schema:{type:'object'},api:[{operation:'read',input:{id:'string'},output:{product:'object'}}],invariants:['identity-before-similarity'],dependencies:[]};
test('canonical contract requires complete API and invariants',()=>{const r=c.validateContract({...base,api:[]});assert.equal(r.valid,false)});
test('contract registration is immutable by version',()=>{const a=c.register({},base);const b=c.register(a.registry,base);assert.equal(a.registered,true);assert.equal(b.registered,false)});
test('removing invariant is a breaking change',()=>{const r=c.compatibility(base,{...base,version:'1.1.0',invariants:[]});assert.equal(r.compatible,false);assert.ok(r.reasons.includes('BREAKING_CHANGE_REQUIRES_MAJOR_VERSION'))});
test('dependency closure fails closed when dependency absent',()=>{const r=c.dependencyClosure({...base,dependencies:['evidence.source']},{});assert.equal(r.ready,false);assert.deepEqual(r.missing,['evidence.source'])});
