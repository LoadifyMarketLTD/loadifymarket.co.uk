const test=require('node:test');const assert=require('node:assert/strict');const {server}=require('./server');let base;
test.before(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));base=`http://127.0.0.1:${server.address().port}`});test.after(()=>server.close());
async function post(p,b={}){const r=await fetch(base+p,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(b)});assert.equal(r.status,200);return r.json()}
test('virtual inventory fails stale',async()=>assert.equal((await post('/api/catalog/virtual-inventory',{quantity:1,confidence:1,observedAt:'2020-01-01'})).checkoutEligible,false));
test('concentration API detects dominance',async()=>assert.equal((await post('/api/demand/concentration-risk',{sellerShares:[.9,.1]})).state,'HIGH'));
test('buyer grounding refuses missing facts',async()=>assert.equal((await post('/api/buyer/grounded-answer',{commerceFacts:{price:5}})).answerable,false));
test('green claims fail closed',async()=>assert.equal((await post('/api/safety/green-claim',{claim:'eco',evidence:[]})).allowed,false));
