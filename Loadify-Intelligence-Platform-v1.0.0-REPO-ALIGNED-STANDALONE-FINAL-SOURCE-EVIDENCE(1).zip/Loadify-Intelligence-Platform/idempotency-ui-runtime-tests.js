'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const fs=require('fs');const app=fs.readFileSync('./app.js','utf8');
test('browser mutations generate keys bound to SHA-256 body digests',()=>{assert.match(app,/method==='POST'/);assert.match(app,/crypto\.randomUUID\(\)/);assert.match(app,/'idempotency-key'/);assert.match(app,/'idempotency-content-digest'/);assert.match(app,/crypto\.subtle\.digest\('SHA-256'/)});
test('UI hydrates and displays idempotency posture',()=>{assert.match(app,/api\/security\/idempotency\/posture/);assert.match(app,/state\.idempotencyPosture=idempotencyPosture/);assert.match(app,/Mutation replay protection/)});
