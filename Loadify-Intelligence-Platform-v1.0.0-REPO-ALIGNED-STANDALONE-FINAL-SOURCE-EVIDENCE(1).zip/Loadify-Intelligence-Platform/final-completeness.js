'use strict';
const fs=require('fs');
const path=require('path');
const crypto=require('crypto');
const {validateReleaseManifest}=require('./run-release-gate');
const {verify:verifyDistribution}=require('./verify-distribution');
const connectorRegistry=require('./lib/connector-registry-engine');
const runtimeConfig=require('./lib/runtime-config-engine');
const ROOT=__dirname;
const REPORT=path.join(ROOT,'data','final-completeness-report.json');
function shaFile(file){return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');}
function sourceJsFiles(root){const out=[];for(const name of fs.readdirSync(root,{withFileTypes:true})){if(name.name==='dist')continue;const full=path.join(root,name.name);if(name.isDirectory()){if(name.name==='lib')for(const f of fs.readdirSync(full))if(f.endsWith('.js'))out.push(path.join(full,f));}else if(name.name.endsWith('.js')&&!name.name.endsWith('-tests.js'))out.push(full);}return out;}
function evaluateCompleteness({root=ROOT}={}){
  const blockers=[],warnings=[];
  const read=(rel)=>JSON.parse(fs.readFileSync(path.join(root,rel),'utf8'));
  let pkg,system,release,attestation,registry,evidence,audit,state;
  try{pkg=read('package.json');system=read('data/system-manifest.json');release=read('data/release-manifest.json');attestation=read('data/test-attestation.json');registry=read('data/feature-registry.json');evidence=read('data/capability-evidence-index.json');audit=read('data/final-audit-report.json');state=read('data/state.json');}catch(e){return{decision:'HOLD',blockers:[`FINAL_INPUT_INVALID:${e.message}`],warnings,metrics:{}};}
  if(pkg.version!=='1.0.0'||system.version!=='1.0.0'||system.environment!=='standalone')blockers.push('FINAL_VERSION_OR_ENVIRONMENT_NOT_LOCKED');
  if(release.releaseChannel!=='standalone-final'||release.externalLiveConnections!==false||release.connectedMarketplace!==null)blockers.push('FINAL_RELEASE_BOUNDARY_INVALID');
  const manifestCheck=validateReleaseManifest(release,{root});if(!manifestCheck.valid)blockers.push(...manifestCheck.errors.map(x=>`RELEASE:${x}`));
  if(!Array.isArray(registry)||registry.length===0)blockers.push('FEATURE_REGISTRY_INVALID');
  const ids=new Set();let planned=0,designed=0,direct=0,moduleBundle=0,missingRefs=0;
  for(let i=0;i<(Array.isArray(registry)?registry.length:0);i++){
    const f=registry[i]||{};const expected=`LIP-${String(i+1).padStart(3,'0')}`;
    if(f.id!==expected)blockers.push(`FEATURE_ID_SEQUENCE_INVALID:${f.id||'MISSING'}:${expected}`);
    if(ids.has(f.id))blockers.push(`FEATURE_ID_DUPLICATE:${f.id}`);ids.add(f.id);
    if(f.status==='PLANNED')planned++;if(f.status==='DESIGNED')designed++;if(f.status!=='IMPLEMENTED_MODEL')blockers.push(`FEATURE_NOT_IMPLEMENTED:${f.id}:${f.status}`);
    if(f.evidenceScope==='DIRECT')direct++;else if(f.evidenceScope==='MODULE_BUNDLE')moduleBundle++;else blockers.push(`FEATURE_EVIDENCE_SCOPE_INVALID:${f.id}`);
    if(f.evidenceRequired===true){for(const ref of f.verificationRefs||[]){if(typeof ref!=='string'||!fs.existsSync(path.join(root,ref))){missingRefs++;blockers.push(`FEATURE_EVIDENCE_REF_MISSING:${f.id}:${ref}`);}}}
  }
  if(planned||designed)blockers.push(`UNFINISHED_FEATURE_STATES:${planned}:${designed}`);
  const featureMap=evidence?.features&&typeof evidence.features==='object'?evidence.features:{};const bundles=evidence?.bundles&&typeof evidence.bundles==='object'?evidence.bundles:{};
  if(Object.keys(featureMap).length!==registry.length)blockers.push('EVIDENCE_INDEX_COVERAGE_MISMATCH');
  for(const f of registry){const bundleId=featureMap[f.id];if(!bundleId||!bundles[bundleId])blockers.push(`EVIDENCE_INDEX_ENTRY_MISSING:${f.id}`);}
  const suiteFiles=fs.readdirSync(root).filter(x=>x.endsWith('tests.js')).sort();
  if(attestation.releaseDigest!==release.releaseDigest||attestation.failedSuites!==0||attestation.suitesTotal!==suiteFiles.length||attestation.passedSuites!==suiteFiles.length)blockers.push('TEST_ATTESTATION_NOT_FINAL');
  const attested=new Map((attestation.results||[]).map(x=>[x.suite,x]));for(const suite of suiteFiles){const x=attested.get(suite);if(!x||x.passed!==true||x.suiteSha256!==release.testSuiteDigests?.[suite]||x.suiteSha256!==shaFile(path.join(root,suite)))blockers.push(`ATTESTED_SUITE_INVALID:${suite}`);}
  if(audit.decision!=='PASS'||audit.releaseDigest!==release.releaseDigest||audit.capabilities!==registry.length||audit.evidenceIndexed!==registry.length||audit.attestedSuites!==suiteFiles.length||audit.failedSuites!==0||audit.externalLiveConnections!==false||audit.cleanInstallLifecycle!=='PASS'||!(audit.stages||[]).every(x=>x.ok===true))blockers.push('FINAL_AUDIT_NOT_CURRENT_PASS');
  const connectors=connectorRegistry.getConnectorRegistry();if(connectors.liveConnectionsEnabled!==false||(connectors.items||[]).some(x=>x.liveConnection!==false||x.credentialMode!=='NONE'))blockers.push('LIVE_CONNECTOR_BOUNDARY_BROKEN');
  const envCheck=runtimeConfig.validateStandaloneEnv(process.env);if(!envCheck.valid)blockers.push(...envCheck.reasons.map(x=>`ENV:${x}`));
  if(state.revision!==0||state.mode!=='SHADOW'||state.killSwitch!==false||!Array.isArray(state.auditChain)||state.auditChain.length!==0)blockers.push('SOURCE_RUNTIME_BASELINE_NOT_CANONICAL_SAFE');
  const dist=path.join(root,'dist','loadify-intelligence-platform');const distCheck=verifyDistribution(dist);if(!distCheck.ok||distCheck.releaseDigest!==release.releaseDigest)blockers.push(`FINAL_DISTRIBUTION_INVALID:${(distCheck.errors||[]).join('|')}`);
  for(const file of sourceJsFiles(root)){const text=fs.readFileSync(file,'utf8');if(new RegExp('\\b(?:TO'+'DO|FIX'+'ME|HA'+'CK|X'+'XX)\\b').test(text))blockers.push(`UNRESOLVED_SOURCE_MARKER:${path.relative(root,file)}`);}
  const metrics={version:pkg.version,capabilities:registry.length,directEvidence:direct,moduleBundleEvidence:moduleBundle,missingEvidenceRefs:missingRefs,testSuites:suiteFiles.length,planned,designed,releaseDigest:release.releaseDigest,distributionFiles:distCheck.files||0,externalLiveConnections:false};
  return{decision:blockers.length?'HOLD':'STANDALONE_FINAL',blockers:[...new Set(blockers)],warnings,metrics};
}
function main(){const startedAt=new Date().toISOString();const result=evaluateCompleteness();const report={schemaVersion:1,product:'Loadify Intelligence Platform',startedAt,completedAt:new Date().toISOString(),...result};fs.writeFileSync(REPORT,JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));if(report.decision!=='STANDALONE_FINAL')process.exitCode=1;return report;}
if(require.main===module)main();
module.exports={evaluateCompleteness,main,sourceJsFiles};
