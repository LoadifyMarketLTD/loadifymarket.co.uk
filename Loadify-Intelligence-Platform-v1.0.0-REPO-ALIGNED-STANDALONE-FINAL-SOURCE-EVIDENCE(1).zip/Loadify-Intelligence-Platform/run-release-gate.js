'use strict';
const fs=require('fs');
const path=require('path');
const crypto=require('crypto');
const {runTestSuites}=require('./test-runner');
const ROOT=__dirname;
const manifestPath=path.join(ROOT,'data/release-manifest.json');
const attestationPath=path.join(ROOT,'data/test-attestation.json');
function sha256(v){return crypto.createHash('sha256').update(v).digest('hex');}
function shaFile(file){return sha256(fs.readFileSync(file));}
function safeEqualHex(a,b){return /^[a-f0-9]{64}$/.test(String(a||''))&&/^[a-f0-9]{64}$/.test(String(b||''))&&crypto.timingSafeEqual(Buffer.from(a,'hex'),Buffer.from(b,'hex'));}
function validateReleaseManifest(manifest,{root=ROOT}={}){
  const errors=[];
  if(!manifest||Array.isArray(manifest)||manifest.schemaVersion!==1||manifest.product!=='Loadify Intelligence Platform')errors.push('RELEASE_MANIFEST_INVALID');
  if(manifest?.externalLiveConnections!==false||manifest?.connectedMarketplace!==null)errors.push('RELEASE_BOUNDARY_INVALID');
  const forDigest={...(manifest||{})};delete forDigest.releaseDigest;forDigest.generatedAt=null;
  const actualDigest=sha256(JSON.stringify(forDigest));if(!safeEqualHex(actualDigest,manifest?.releaseDigest))errors.push('RELEASE_MANIFEST_DIGEST_INVALID');
  const suites=fs.readdirSync(root).filter(x=>x.endsWith('tests.js')).sort();
  const declared=Object.keys(manifest?.testSuiteDigests||{}).sort();
  if(Number(manifest?.coverage?.testSuites)!==suites.length||declared.length!==suites.length||JSON.stringify(declared)!==JSON.stringify(suites))errors.push('RELEASE_TEST_SUITE_SET_STALE');
  for(const suite of suites){const file=path.join(root,suite);if(manifest?.testSuiteDigests?.[suite]!==shaFile(file))errors.push(`RELEASE_TEST_SUITE_DIGEST_STALE:${suite}`);}
  for(const [rel,expected] of Object.entries(manifest?.artifacts||{})){const file=path.join(root,rel);if(!fs.existsSync(file))errors.push(`RELEASE_ARTIFACT_MISSING:${rel}`);else if(shaFile(file)!==expected)errors.push(`RELEASE_ARTIFACT_DIGEST_STALE:${rel}`);}
  const registryMap={featureRegistry:'data/feature-registry.json',standardsRegistry:'data/standards-registry.json',threatCatalog:'data/threat-catalog.json',systemManifest:'data/system-manifest.json',capabilityEvidenceIndex:'data/capability-evidence-index.json',loadifyMarketCompatibilityContract:'data/loadify-market-compatibility-contract.json',seedState:'data/seed-state.json'};
  for(const [key,rel] of Object.entries(registryMap)){const file=path.join(root,rel);if(!fs.existsSync(file)||manifest?.registries?.[key]!==shaFile(file))errors.push(`RELEASE_REGISTRY_DIGEST_STALE:${key}`);}
  return{valid:errors.length===0,errors:[...new Set(errors)],releaseDigest:manifest?.releaseDigest||null,suites:suites.length};
}
function atomicWriteJson(file,value){
  const parent=path.dirname(file);fs.mkdirSync(parent,{recursive:true});const tmp=`${file}.${process.pid}.${crypto.randomUUID()}.tmp`;let fd;
  try{fd=fs.openSync(tmp,'wx',0o600);fs.writeFileSync(fd,JSON.stringify(value,null,2)+'\n');fs.fsyncSync(fd);fs.closeSync(fd);fd=undefined;fs.renameSync(tmp,file);if(process.platform!=='win32')fs.chmodSync(file,0o600);let dirFd;try{dirFd=fs.openSync(parent,'r');fs.fsyncSync(dirFd);}finally{if(dirFd!==undefined)fs.closeSync(dirFd);}}
  catch(e){if(fd!==undefined)try{fs.closeSync(fd);}catch(_){}try{fs.unlinkSync(tmp);}catch(_){}throw e;}
}
function run(){
  if(!fs.existsSync(manifestPath))throw new Error('RELEASE_MANIFEST_MISSING');
  const manifest=JSON.parse(fs.readFileSync(manifestPath,'utf8'));
  const preflight=validateReleaseManifest(manifest);if(!preflight.valid)throw new Error(`RELEASE_GATE_PREFLIGHT_HOLD:${preflight.errors.join(',')}`);
  const execution=runTestSuites();
  const results=execution.results.map(({stdout,stderr,...x})=>x);
  const body={schemaVersion:1,product:'Loadify Intelligence Platform',releaseDigest:manifest.releaseDigest,generatedAt:new Date().toISOString(),suitesTotal:execution.suites.length,passedSuites:execution.suites.length-execution.failed.length,failedSuites:execution.failed.length,results};
  const signature=sha256(JSON.stringify({...body,generatedAt:null}));
  const attestation={...body,attestationDigest:signature};
  atomicWriteJson(attestationPath,attestation);
  console.log(JSON.stringify({releaseDigest:manifest.releaseDigest,suites:execution.suites.length,failed:execution.failed.length,attestationDigest:signature,preflight:'PASS'}));
  if(execution.failed.length)process.exitCode=1;
  return attestation;
}
if(require.main===module){try{run();}catch(e){console.error(String(e.message||e));process.exitCode=1;}}
module.exports={run,validateReleaseManifest,atomicWriteJson,sha256};
