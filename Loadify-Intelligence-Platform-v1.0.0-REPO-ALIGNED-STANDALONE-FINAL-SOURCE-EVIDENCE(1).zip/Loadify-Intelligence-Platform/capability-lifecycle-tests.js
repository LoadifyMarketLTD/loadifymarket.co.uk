'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const lifecycle = require('./lib/capability-lifecycle-engine');

function complete(overrides={}){
  return {
    id:'LIP-X', title:'Capability', module:'Policy', risk:'R3', status:'IMPLEMENTED_MODEL', owner:'Policy Owner',
    contractRef:'contract://lip-x/v1', policyRefs:['policy://default-deny/v1'], authorizationRefs:['authz://capability/v1'],
    telemetryRefs:['otel://lip-x'], auditRefs:['audit://lip-x'], testRefs:['test://lip-x/regression'],
    rollbackRef:'rollback://lip-x/v1', evidenceRefs:['evidence://lip-x/impl'], humanApprovalRequired:true,
    ...overrides
  };
}

test('R3 capability cannot be verified without rollback',()=>{
  const r=lifecycle.readiness(complete({rollbackRef:null}));
  assert.equal(r.allowed,false); assert.ok(r.reasons.includes('ROLLBACK_OR_RECOVERY_REQUIRED'));
});

test('capability cannot be verified without regression evidence',()=>{
  const r=lifecycle.readiness(complete({testRefs:[]}));
  assert.equal(r.allowed,false); assert.ok(r.reasons.includes('REGRESSION_EVIDENCE_REQUIRED'));
});

test('complete R3 capability passes verification gate',()=>{
  const r=lifecycle.readiness(complete()); assert.equal(r.allowed,true); assert.equal(r.decision,'PASS');
});

test('production eligibility requires verified status and recent verification',()=>{
  const r=lifecycle.readiness(complete({status:'IMPLEMENTED_MODEL'}),{target:'PRODUCTION_ELIGIBLE'});
  assert.equal(r.allowed,false); assert.ok(r.reasons.includes('VERIFIED_STATUS_REQUIRED')); assert.ok(r.reasons.includes('RECENT_VERIFICATION_REQUIRED'));
});

test('production dependency fails closed when disconnected',()=>{
  const r=lifecycle.readiness(complete({status:'VERIFIED',lastVerifiedAt:new Date().toISOString(),productionDependencies:['stripe'],externalDependenciesConnected:false}),{target:'PRODUCTION_ELIGIBLE'});
  assert.equal(r.allowed,false); assert.ok(r.reasons.includes('PRODUCTION_DEPENDENCIES_NOT_CONNECTED'));
});

test('status jumps are forbidden',()=>{
  const r=lifecycle.promotionDecision(complete({status:'DESIGNED'}),'VERIFIED');
  assert.equal(r.allowed,false); assert.ok(r.reasons.includes('STATUS_JUMP_FORBIDDEN'));
});

test('portfolio reports exact blockers',()=>{
  const p=lifecycle.portfolioReadiness([complete(),complete({id:'LIP-Y',testRefs:[]})]);
  assert.equal(p.ready,false); assert.equal(p.blocked,1); assert.equal(p.blockers[0].id,'LIP-Y');
});
