'use strict';const test=require('node:test');const assert=require('node:assert/strict');const {server}=require('./server');let base;
test.before(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));base=`http://127.0.0.1:${server.address().port}`});test.after(async()=>{await new Promise(r=>server.close(r));});
async function post(path,body){const r=await fetch(base+path,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});assert.equal(r.status,200);return r.json()}
const c={id:'x',name:'X',module:'Core',version:'1.0.0',owner:'o',schema:{type:'object'},api:[{operation:'read',input:{},output:{}}],invariants:['stable']};
test('contract validate endpoint passes canonical contract',async()=>{const r=await post('/api/contracts/validate',c);assert.equal(r.valid,true)});
test('contract dependency endpoint fails closed',async()=>{const r=await post('/api/contracts/dependencies',{contract:{...c,dependencies:['missing']},registry:{}});assert.equal(r.ready,false)});
