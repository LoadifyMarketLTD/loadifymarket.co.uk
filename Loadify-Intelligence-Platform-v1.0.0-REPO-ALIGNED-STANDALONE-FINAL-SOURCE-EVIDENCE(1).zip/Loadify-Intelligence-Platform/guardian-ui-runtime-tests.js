'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const path=require('path');

test('front-end hydrates Guardian and readiness health from runtime',()=>{
 const src=fs.readFileSync(path.join(__dirname,'app.js'),'utf8');
 assert.match(src,/api\('\/api\/guardian\/readiness'\)/);
 assert.match(src,/api\('\/api\/health'\)/);
 assert.match(src,/state\.guardian=guardian/);
 assert.match(src,/state\.runtimeHealthy=health\?\.ok===true/);
 assert.match(src,/Guardian: <b>\$\{esc\(state\.guardian\?\.gate\|\|'UNKNOWN'\)\}/);
});

test('mission control derives Guardian release note from runtime evidence',()=>{
 const src=fs.readFileSync(path.join(__dirname,'app.js'),'utf8');
 assert.match(src,/state\.guardian\?\.ready/);
 assert.match(src,/state\.guardian\.coverage\?\.tests/);
 assert.match(src,/state\.health\?\.releaseDigest/);
});
