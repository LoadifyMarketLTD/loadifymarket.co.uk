'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const r=require('./lib/runtime-startup-engine');
const srv=require('./server');

test('startup verifier accepts an exact cryptographically bound release fixture',()=>{
  const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'lip-startup-ok-')); fs.cpSync(srv.ROOT,tmp,{recursive:true});
  const crypto=require('node:crypto'); const release=JSON.parse(fs.readFileSync(path.join(tmp,'data/release-manifest.json'),'utf8'));
  const suites=fs.readdirSync(tmp).filter(x=>x.endsWith('tests.js')).sort(); assert.equal(suites.length,release.coverage.testSuites);
  const results=suites.map(suite=>({suite,suiteSha256:crypto.createHash('sha256').update(fs.readFileSync(path.join(tmp,suite))).digest('hex'),passed:true,status:0,signal:null}));
  const body={schemaVersion:1,product:'Loadify Intelligence Platform',releaseDigest:release.releaseDigest,generatedAt:new Date().toISOString(),suitesTotal:suites.length,passedSuites:suites.length,failedSuites:0,results};
  const signed={...body,attestationDigest:crypto.createHash('sha256').update(JSON.stringify({...body,generatedAt:null})).digest('hex')};
  fs.writeFileSync(path.join(tmp,'data/test-attestation.json'),JSON.stringify(signed,null,2)+'\n');
  const out=r.verifyRelease({root:tmp,defaults:srv.defaultState,backupDir:path.join(tmp,'data/state-backups'),stateFile:path.join(tmp,'data/state.json')});
  assert.equal(out.ready,true); assert.equal(out.decision,'START'); fs.rmSync(tmp,{recursive:true,force:true});
});

test('startup verifier fails closed when an attested artifact digest is wrong in a copied release',()=>{
  const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'lip-startup-'));
  fs.cpSync(srv.ROOT,tmp,{recursive:true});
  fs.appendFileSync(path.join(tmp,'app.js'),'\n// tamper\n');
  const out=r.verifyRelease({root:tmp,defaults:srv.defaultState,backupDir:path.join(tmp,'data/state-backups'),stateFile:path.join(tmp,'data/state.json')});
  assert.equal(out.ready,false); assert.ok(out.reasons.some(x=>x==='RELEASE_ARTIFACT_DIGEST_MISMATCH:app.js'));
  fs.rmSync(tmp,{recursive:true,force:true});
});

test('runtime lock refuses a live owner',()=>{
  const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'lip-lock-')); const lockFile=path.join(tmp,'runtime.lock');
  fs.writeFileSync(lockFile,JSON.stringify({pid:process.pid,startedAt:new Date().toISOString()}));
  const out=r.acquireRuntimeLock({lockFile}); assert.equal(out.acquired,false); assert.equal(out.reason,'RUNTIME_ALREADY_ACTIVE');
  fs.rmSync(tmp,{recursive:true,force:true});
});

test('runtime lock recovers a stale owner and releases only own lock',()=>{
  const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'lip-lock-')); const lockFile=path.join(tmp,'runtime.lock');
  fs.writeFileSync(lockFile,JSON.stringify({pid:99999999,startedAt:'2000-01-01T00:00:00Z'}));
  const out=r.acquireRuntimeLock({lockFile}); assert.equal(out.acquired,true); assert.equal(out.recoveredStale,true);
  assert.equal(r.releaseRuntimeLock({lockFile}),true); assert.equal(fs.existsSync(lockFile),false);
  fs.rmSync(tmp,{recursive:true,force:true});
});

test('startup verifier fails closed when system manifest changes after release signing',()=>{
  const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'lip-startup-system-manifest-'));fs.cpSync(srv.ROOT,tmp,{recursive:true});
  const f=path.join(tmp,'data/system-manifest.json');const m=JSON.parse(fs.readFileSync(f,'utf8'));m.invariants.push('tampered-invariant');fs.writeFileSync(f,JSON.stringify(m,null,2)+'\n');
  const out=r.verifyRelease({root:tmp,defaults:srv.defaultState,backupDir:path.join(tmp,'data/state-backups'),stateFile:path.join(tmp,'data/state.json')});
  assert.equal(out.ready,false);assert.ok(out.reasons.includes('RELEASE_REGISTRY_DIGEST_MISMATCH:systemManifest'));fs.rmSync(tmp,{recursive:true,force:true});
});
