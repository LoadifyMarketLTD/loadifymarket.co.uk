'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const {server}=require('./server');
let base;
test.before(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));base=`http://127.0.0.1:${server.address().port}`});
test.after(async()=>{await new Promise(r=>server.close(r));});
async function post(path,body){const r=await fetch(base+path,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});assert.equal(r.status,200);return r.json();}
function cap(overrides={}){return {id:'LIP-X',title:'Capability',module:'Agents',risk:'R3',status:'IMPLEMENTED_MODEL',owner:'Owner',contractRef:'contract://x',policyRefs:['policy://x'],authorizationRefs:['authz://x'],telemetryRefs:['otel://x'],auditRefs:['audit://x'],testRefs:['test://x'],rollbackRef:'rollback://x',evidenceRefs:['evidence://x'],humanApprovalRequired:true,...overrides};}
test('readiness endpoint passes complete capability',async()=>{const r=await post('/api/capabilities/readiness',cap());assert.equal(r.allowed,true)});
test('promotion endpoint blocks jumping states',async()=>{const r=await post('/api/capabilities/promotion',{capability:cap({status:'DESIGNED'}),requestedStatus:'VERIFIED'});assert.equal(r.allowed,false);assert.ok(r.reasons.includes('STATUS_JUMP_FORBIDDEN'))});
test('portfolio endpoint identifies blocker',async()=>{const r=await post('/api/capabilities/portfolio-readiness',{capabilities:[cap(),cap({id:'LIP-Y',auditRefs:[]})]});assert.equal(r.ready,false);assert.equal(r.blocked,1)});
