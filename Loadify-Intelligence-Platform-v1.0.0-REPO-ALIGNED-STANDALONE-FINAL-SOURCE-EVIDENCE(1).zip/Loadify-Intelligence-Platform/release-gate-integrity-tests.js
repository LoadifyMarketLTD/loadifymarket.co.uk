'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const crypto=require('node:crypto');
const {validateReleaseManifest}=require('./run-release-gate');
function hashFile(f){return crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');}
function fixture(){
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'lip-release-gate-'));fs.mkdirSync(path.join(root,'data'),{recursive:true});
  fs.writeFileSync(path.join(root,'a-tests.js'),'process.exit(0)\n');fs.writeFileSync(path.join(root,'server.js'),'module.exports={}\n');
  const registryMap={featureRegistry:'feature-registry.json',standardsRegistry:'standards-registry.json',threatCatalog:'threat-catalog.json',systemManifest:'system-manifest.json',capabilityEvidenceIndex:'capability-evidence-index.json',loadifyMarketCompatibilityContract:'loadify-market-compatibility-contract.json',seedState:'seed-state.json'};
  for(const file of Object.values(registryMap))fs.writeFileSync(path.join(root,'data',file),'{}\n');
  const manifest={schemaVersion:1,product:'Loadify Intelligence Platform',releaseChannel:'test',environment:'standalone',connectedMarketplace:null,generatedAt:new Date().toISOString(),coverage:{features:0,testSuites:1},testSuiteDigests:{'a-tests.js':hashFile(path.join(root,'a-tests.js'))},artifacts:{'server.js':hashFile(path.join(root,'server.js'))},registries:Object.fromEntries(Object.entries(registryMap).map(([k,f])=>[k,hashFile(path.join(root,'data',f))])),externalLiveConnections:false};
  const canonical=JSON.stringify({...manifest,generatedAt:null});manifest.releaseDigest=crypto.createHash('sha256').update(canonical).digest('hex');return{root,manifest};
}
test('release gate preflight accepts an exact current manifest and rejects stale test bytes',()=>{const x=fixture();try{assert.equal(validateReleaseManifest(x.manifest,{root:x.root}).valid,true);fs.appendFileSync(path.join(x.root,'a-tests.js'),'// changed\n');const out=validateReleaseManifest(x.manifest,{root:x.root});assert.equal(out.valid,false);assert.ok(out.errors.includes('RELEASE_TEST_SUITE_DIGEST_STALE:a-tests.js'));}finally{fs.rmSync(x.root,{recursive:true,force:true})}});
test('release gate preflight rejects self-digest and standalone-boundary tampering',()=>{const x=fixture();try{let m={...x.manifest,releaseDigest:'0'.repeat(64)};assert.ok(validateReleaseManifest(m,{root:x.root}).errors.includes('RELEASE_MANIFEST_DIGEST_INVALID'));m={...x.manifest,externalLiveConnections:true};const out=validateReleaseManifest(m,{root:x.root});assert.ok(out.errors.includes('RELEASE_BOUNDARY_INVALID'));assert.ok(out.errors.includes('RELEASE_MANIFEST_DIGEST_INVALID'));}finally{fs.rmSync(x.root,{recursive:true,force:true})}});
