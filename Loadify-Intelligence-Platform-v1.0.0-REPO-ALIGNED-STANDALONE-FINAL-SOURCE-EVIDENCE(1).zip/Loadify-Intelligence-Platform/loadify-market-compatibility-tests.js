'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const path=require('path');
const market=require('./lib/loadify-market-compatibility-engine');

test('compatibility contract is pinned to the audited Loadify Market repository but remains disconnected',()=>{
  const c=market.contract();const s=market.compatibilityStatus();
  assert.equal(c.target.repository,'LoadifyMarketLTD/loadifymarket.co.uk');
  assert.equal(c.target.auditedMainCommit,'87b571c7f316742f85ad4ff8360597e5a0861f8d');
  assert.equal(c.target.auditedTree,'8cee7901bb936122f73ac98e9e7fe77fb14b8d20');
  assert.equal(c.target.integrationState,'NOT_CONNECTED');
  assert.equal(s.decision,'ALIGNED_DISCONNECTED');assert.equal(s.liveConnection,false);assert.equal(s.credentialMode,'NONE');
});

test('canonical Loadify Market product, order and financial separations are explicit',()=>{
  const c=market.contract();
  for(const key of ['CANONICAL_PRODUCT_NE_SUPPLIER_OFFER','SUPPLIER_RAW_STOCK_NE_LOADIFY_SELLABLE_STOCK','PAYMENT_SUCCESS_NE_SUPPLIER_ORDER_SUCCESS','CUSTOMER_REFUND_NE_SUPPLIER_RECOVERY','ORDER_COMPLETED_NE_FINANCIALLY_RECONCILED','ONE_CUSTOMER_ORDER_TRUTH','ONE_CANONICAL_FINANCIAL_TRUTH']) assert.ok(c.canonicalInvariants.includes(key),key);
  assert.ok(c.ownershipBoundary.loadifyMarketOwns.includes('customer_order_truth'));
  assert.ok(c.ownershipBoundary.loadifyMarketOwns.includes('canonical_financial_truth'));
  assert.ok(c.ownershipBoundary.forbiddenForIntelligence.includes('parallel_customer_order_ledger'));
  assert.ok(c.ownershipBoundary.forbiddenForIntelligence.includes('parallel_financial_ledger'));
});

test('supplier role taxonomy and fail-closed Phase O control vocabulary match repository contract',()=>{
  const c=market.contract();
  assert.deepEqual(c.externalRoleTaxonomy,['discovery_source','catalog_source','supplier','fulfilment_provider','carrier','sales_channel','payment_finance_provider']);
  for(const op of ['*','pilot','import','publish','checkout','reservation','supplier_order','tracking_ingest','return_recovery','stock_sync','price_sync']) assert.ok(c.supplierCommerceControls.operations.includes(op));
  for(const scope of ['global','provider','supplier','offer','product','category','territory','cohort']) assert.ok(c.supplierCommerceControls.scopeTypes.includes(scope));
  assert.equal(c.supplierCommerceControls.safeDefault,'OFF_FAIL_CLOSED');
  assert.equal(c.supplierCommerceControls.auditedSnapshot.phase,'PHASE_O_CONTROLLED_PILOT');
  assert.equal(c.supplierCommerceControls.auditedSnapshot.pilotPass,false);
  assert.equal(c.supplierCommerceControls.auditedSnapshot.globalActivationAllowed,false);
});

test('canonical supplier entities include repository-native supplier data and lifecycle facts',()=>{
  const c=market.contract();
  for(const entity of ['canonical_product','supplier_catalog_item','supplier_offer','sellable_stock','reservation','supplier_order','fulfilment_leg','tracking_event','return_case','customer_refund','supplier_recovery','financial_reconciliation','supplier_pilot_program']) assert.ok(c.canonicalSupplierEntities.includes(entity),entity);
});

test('market facts are admitted only as evidence-bound read-only envelopes',()=>{
  const good=market.admitFactEnvelope({sourceSystem:'LOADIFY_MARKET',entityType:'supplier_offer',entityRef:'offer-1',observedAt:'2026-08-21T20:30:00Z',evidenceRef:'market://supplier-offer/1/v3',schemaVersion:1});
  assert.equal(good.admitted,true);assert.equal(good.readOnly,true);assert.equal(good.decision,'ADMIT_READ_ONLY');
  assert.equal(market.admitFactEnvelope({sourceSystem:'LOADIFY_MARKET',entityType:'supplier_offer',entityRef:'offer-1',observedAt:'2026-08-21T20:30:00Z',evidenceRef:'x',schemaVersion:1,authoritativeWrite:true}).admitted,false);
  assert.equal(market.admitFactEnvelope({sourceSystem:'OTHER',entityType:'supplier_offer',entityRef:'offer-1',observedAt:'2026-08-21T20:30:00Z',evidenceRef:'x',schemaVersion:1}).admitted,false);
});

test('Intelligence can emit bounded intents but cannot execute canonical commerce side effects',()=>{
  const good=market.assessActionIntent({intentClass:'REQUEST_BOUNDED_ACTION',operation:'REQUEST_MARKET_REVIEW',authorizationRef:'auth-1',evidenceRef:'ev-1',correlationId:'corr-1'});
  assert.equal(good.allowed,true);assert.equal(good.decision,'INTENT_ONLY');assert.equal(good.directExecution,false);
  for(const operation of ['DATABASE_WRITE','PAYMENT_CAPTURE','PAYMENT_REFUND','PAYOUT_RELEASE','SUPPLIER_ORDER_SUBMIT','DIRECT_PUBLISH','CONTROL_ENABLE','CONTROL_DISABLE']){
    const r=market.assessActionIntent({intentClass:'REQUEST_BOUNDED_ACTION',operation,authorizationRef:'a',evidenceRef:'e',correlationId:'c'});assert.equal(r.allowed,false,operation);
  }
});

test('canonical event separations fail closed when one fact is incorrectly used to prove another',()=>{
  assert.equal(market.canonicalSeparation({canonicalProductId:'same',supplierOfferId:'same'}).valid,false);
  assert.equal(market.canonicalSeparation({supplierRawStock:5,loadifySellableStock:5,sellableStockDerived:false}).valid,false);
  assert.equal(market.canonicalSeparation({paymentSuccess:true,supplierOrderSuccess:true,independentSupplierOrderEvidence:false}).valid,false);
  assert.equal(market.canonicalSeparation({customerRefund:true,supplierRecovery:true,independentRecoveryEvidence:false}).valid,false);
  assert.equal(market.canonicalSeparation({orderCompleted:true,financiallyReconciled:true,independentReconciliationEvidence:false}).valid,false);
  assert.equal(market.canonicalSeparation({canonicalProductId:'p',supplierOfferId:'o',supplierRawStock:5,loadifySellableStock:4,sellableStockDerived:true,paymentSuccess:true,supplierOrderSuccess:true,independentSupplierOrderEvidence:true,customerRefund:true,supplierRecovery:true,independentRecoveryEvidence:true,orderCompleted:true,financiallyReconciled:true,independentReconciliationEvidence:true}).valid,true);
});

test('repo movement triggers mandatory re-verification without enabling connectivity',()=>{
  const exact=market.assessRepositorySnapshot({repository:'LoadifyMarketLTD/loadifymarket.co.uk',mainCommit:'87b571c7f316742f85ad4ff8360597e5a0861f8d',liveConnection:false});
  assert.equal(exact.compatible,true);assert.equal(exact.reverifyRequired,false);
  const moved=market.assessRepositorySnapshot({repository:'LoadifyMarketLTD/loadifymarket.co.uk',mainCommit:'ffffffffffffffffffffffffffffffffffffffff',liveConnection:false});
  assert.equal(moved.compatible,true);assert.equal(moved.reverifyRequired,true);assert.ok(moved.warnings.includes('MAIN_MOVED_REVERIFY_REQUIRED'));
  assert.equal(market.assessRepositorySnapshot({repository:'LoadifyMarketLTD/loadifymarket.co.uk',mainCommit:'87b571c7f316742f85ad4ff8360597e5a0861f8d',liveConnection:true}).compatible,false);
});

test('system manifest binds the compatibility contract and preserves standalone boundary',()=>{
  const m=JSON.parse(fs.readFileSync(path.join(__dirname,'data/system-manifest.json'),'utf8'));
  assert.equal(m.loadifyMarketCompatibility.contractId,'LIP-LOADIFY-MARKET-COMPATIBILITY');
  assert.equal(m.loadifyMarketCompatibility.integrationState,'NOT_CONNECTED');
  assert.equal(m.loadifyMarketCompatibility.repository,'LoadifyMarketLTD/loadifymarket.co.uk');
});
