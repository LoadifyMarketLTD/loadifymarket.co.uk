'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const path=require('path');
const audit=require('./lib/audit-ledger-engine');

test('canonical seed is safe deterministic standalone baseline',()=>{
  const s=JSON.parse(fs.readFileSync(path.join(__dirname,'data/seed-state.json'),'utf8'));
  assert.equal(s.seedVersion,'1.0.0');
  assert.equal(s.environment,'standalone');
  assert.equal(s.connectedMarketplace,null);
  assert.equal(s.mode,'SHADOW');
  assert.equal(s.killSwitch,false);
  assert.equal(s.revision,0);
  assert.deepEqual(s.auditChain,[]);
  assert.deepEqual(s.telemetry,[]);
  assert.ok((s.audit||[]).every(x=>!String(x.action).toLowerCase().includes('kill switch')));
  assert.ok((s.audit||[]).every(x=>!String(x.policy).includes('v0.1')));
});

test('server default state is loaded from canonical seed instead of runtime-generated UUID/timestamps',()=>{
  const src=fs.readFileSync(path.join(__dirname,'server.js'),'utf8');
  assert.match(src,/seed-state\.json/);
  assert.doesNotMatch(src,/const defaultState = \{/);
});

test('release manifest binds canonical seed state',()=>{
  const src=fs.readFileSync(path.join(__dirname,'build-release-manifest.js'),'utf8');
  const startup=fs.readFileSync(path.join(__dirname,'lib/runtime-startup-engine.js'),'utf8');
  assert.match(src,/seedState/);
  assert.match(startup,/seedState/);
});
