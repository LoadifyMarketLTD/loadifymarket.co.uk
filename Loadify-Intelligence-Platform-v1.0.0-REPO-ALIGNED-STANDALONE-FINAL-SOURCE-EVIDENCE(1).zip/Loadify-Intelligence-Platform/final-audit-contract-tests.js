'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const path=require('path');

test('final audit contract covers source release, clean distribution and clean-install runtime',()=>{
 const src=fs.readFileSync(path.join(__dirname,'final-audit.js'),'utf8');
 for(const token of ['build-capability-evidence-index.js','build-release-manifest.js','run-release-gate.js','self-check.js','build-distribution.js','verify-distribution.js','clean-install-health','clean-install-guardian','clean-install-seed','runtime-lock-cleanup']) assert.ok(src.includes(token),token);
 assert.match(src,/decision:'HOLD'/);
 assert.match(src,/decision:'PASS'/);
});

test('final audit is part of signed release tooling',()=>{
 const src=fs.readFileSync(path.join(__dirname,'build-release-manifest.js'),'utf8');
 assert.match(src,/final-audit\.js/);
});
