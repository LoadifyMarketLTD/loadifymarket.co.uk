'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const fs=require('fs');const path=require('path');
const runner=require('./test-runner');
const statePath=path.join(__dirname,'data/state.json');
test('runtime snapshot/restore returns persistent state byte-for-byte',()=>{const before=fs.readFileSync(statePath);const snap=runner.snapshotRuntime();fs.writeFileSync(statePath,'{}');runner.restoreRuntime(snap);assert.deepEqual(fs.readFileSync(statePath),before);});
