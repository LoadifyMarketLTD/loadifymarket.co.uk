'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const {normalizePolicy,createRequestBudget}=require('./lib/request-budget-engine');

test('request budget policy clamps unsafe configuration',()=>{
  const p=normalizePolicy({windowMs:1,readLimit:0,mutationLimit:999999,maxTrackedKeys:1});
  assert.equal(p.windowMs,1000);assert.equal(p.readLimit,1);assert.equal(p.mutationLimit,10000);assert.equal(p.maxTrackedKeys,10);
});
test('read and mutation budgets are isolated per principal',()=>{
  const b=createRequestBudget({windowMs:1000,readLimit:2,mutationLimit:1,maxTrackedKeys:10});
  assert.equal(b.consume({key:'A',kind:'read',now:0}).allowed,true);
  assert.equal(b.consume({key:'A',kind:'read',now:1}).allowed,true);
  assert.equal(b.consume({key:'A',kind:'read',now:2}).allowed,false);
  assert.equal(b.consume({key:'A',kind:'mutation',now:2}).allowed,true);
  assert.equal(b.consume({key:'A',kind:'mutation',now:3}).allowed,false);
  assert.equal(b.consume({key:'B',kind:'read',now:3}).allowed,true);
});
test('expired windows reset deterministically',()=>{
  const b=createRequestBudget({windowMs:1000,readLimit:1});
  assert.equal(b.consume({key:'A',now:0}).allowed,true);
  assert.equal(b.consume({key:'A',now:999}).allowed,false);
  const next=b.consume({key:'A',now:1000});assert.equal(next.allowed,true);assert.equal(next.remaining,0);
});
test('posture is explicit, local and dependency free',()=>{
  const p=createRequestBudget().posture();assert.equal(p.enabled,true);assert.equal(p.failMode,'FAIL_CLOSED');assert.equal(p.externalDependency,false);
});
