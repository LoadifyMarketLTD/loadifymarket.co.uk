'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const fs=require('fs');
const app=fs.readFileSync('./app.js','utf8');const server=fs.readFileSync('./server.js','utf8');
test('Agent Registry hydrates Context Security from runtime posture',()=>{assert.match(app,/api\/security\/context\/posture/);assert.match(app,/Context Security/);assert.match(app,/ctx\.antiLaundering/)});
test('context posture endpoint is runtime-backed',()=>{assert.match(server,/\/api\/security\/context\/posture/);assert.match(server,/CONTEXT_SECURITY_V1/)});
