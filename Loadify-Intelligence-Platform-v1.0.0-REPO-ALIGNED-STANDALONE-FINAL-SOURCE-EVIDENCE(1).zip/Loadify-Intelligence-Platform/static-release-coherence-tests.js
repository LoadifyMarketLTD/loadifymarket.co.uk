'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const {server}=require('./server');
let base;test.before(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));base=`http://127.0.0.1:${server.address().port}`});test.after(async()=>{await new Promise(r=>server.close(r))});
test('control-plane static assets are no-store to prevent UI/runtime release drift',async()=>{for(const path of ['/','/app.js','/styles.css']){const r=await fetch(base+path);assert.equal(r.status,200);assert.match(String(r.headers.get('cache-control')),/no-store/);}});
test('static path traversal cannot escape application root',async()=>{for(const path of ['/..%2F..%2Fetc%2Fpasswd','/%2e%2e/%2e%2e/etc/passwd']){const r=await fetch(base+path);assert.notEqual(r.status,200);}});
