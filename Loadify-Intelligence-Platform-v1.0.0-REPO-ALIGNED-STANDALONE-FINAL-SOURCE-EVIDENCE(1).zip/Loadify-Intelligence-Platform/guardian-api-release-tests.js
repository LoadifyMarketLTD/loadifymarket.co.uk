'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const path=require('path');
const crypto=require('crypto');
const {server}=require('./server');
const attestationPath=path.join(__dirname,'data/test-attestation.json');
let base,previous,baseSuiteCount;

test.before(async()=>{
 previous=fs.existsSync(attestationPath)?fs.readFileSync(attestationPath):null;
 const release=JSON.parse(fs.readFileSync(path.join(__dirname,'data/release-manifest.json'),'utf8'));
 const suites=fs.readdirSync(__dirname).filter(x=>x.endsWith('tests.js')).sort(); baseSuiteCount=suites.length;
 assert.equal(suites.length,release.coverage.testSuites);
 const results=suites.map(suite=>({suite,suiteSha256:crypto.createHash('sha256').update(fs.readFileSync(path.join(__dirname,suite))).digest('hex'),passed:true,status:0,signal:null}));
 const body={schemaVersion:1,product:'Loadify Intelligence Platform',releaseDigest:release.releaseDigest,generatedAt:new Date().toISOString(),suitesTotal:suites.length,passedSuites:suites.length,failedSuites:0,results};
 const canonical={...body,generatedAt:null};
 fs.writeFileSync(attestationPath,JSON.stringify({...body,attestationDigest:crypto.createHash('sha256').update(JSON.stringify(canonical)).digest('hex')},null,2));
 await new Promise(r=>server.listen(0,'127.0.0.1',r));base=`http://127.0.0.1:${server.address().port}`;
});
test.after(async()=>{await new Promise(r=>server.close(r));if(previous)fs.writeFileSync(attestationPath,previous);else if(fs.existsSync(attestationPath))fs.unlinkSync(attestationPath);});

test('guardian API ignores caller-supplied test counts and uses local attestation',async()=>{
 const r=await fetch(`${base}/api/guardian/readiness?tests=999999&failed=999999`);assert.equal(r.status,200);const j=await r.json();
 assert.equal(j.ready,true);assert.equal(j.gate,'RELEASE_CANDIDATE');assert.equal(j.coverage.tests,baseSuiteCount);assert.equal(j.coverage.failedTests,0);
});
