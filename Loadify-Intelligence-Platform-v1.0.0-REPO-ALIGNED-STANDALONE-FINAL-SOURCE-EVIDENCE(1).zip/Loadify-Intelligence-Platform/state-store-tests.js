'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const os=require('os');
const path=require('path');
const store=require('./lib/state-store-engine');

function fixture(){
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'lip-state-'));
  return {root,file:path.join(root,'state.json'),backupDir:path.join(root,'backups'),defaults:{environment:'standalone',connectedMarketplace:null,mode:'SHADOW',killSwitch:false,createdAt:new Date().toISOString(),approvals:[],experiments:[],flags:[],agents:[],audit:[],auditChain:[]}};
}

test('state store initializes a versioned valid state',()=>{
  const f=fixture(); const r=store.loadState(f);
  assert.equal(r.state.schemaVersion,1); assert.equal(r.state.revision,0);
  assert.equal(store.storageHealth(f).healthy,true);
});

test('save is revisioned and creates recoverable backup',()=>{
  const f=fixture(); let s=store.loadState(f).state; s.mode='RECOMMEND';
  s=store.saveState({...f,state:s});
  assert.equal(s.revision,1); assert.equal(store.storageHealth(f).backupCount,1);
});

test('corrupt primary recovers from latest valid backup',()=>{
  const f=fixture(); let s=store.loadState(f).state; s.mode='RECOMMEND'; store.saveState({...f,state:s});
  fs.writeFileSync(f.file,'{broken');
  const r=store.loadState(f);
  assert.equal(r.recovered,true); assert.equal(r.state.mode,'SHADOW');
  assert.ok(r.state.recovery.sourceBackup);
});

test('future schema fails closed',()=>{
  const f=fixture(); store.loadState(f);
  const raw=JSON.parse(fs.readFileSync(f.file,'utf8')); raw.schemaVersion=999; fs.writeFileSync(f.file,JSON.stringify(raw));
  assert.throws(()=>store.loadState(f),/FUTURE_SCHEMA_VERSION_UNSUPPORTED/);
});
test('tampered signed backup is skipped during recovery',()=>{
  const f=fixture(); let s=store.loadState(f).state; s.mode='RECOMMEND'; s=store.saveState({...f,state:s}); s.mode='ASSISTED'; store.saveState({...f,state:s});
  const backups=fs.readdirSync(f.backupDir).filter(x=>x.endsWith('.json')).map(x=>path.join(f.backupDir,x)).sort((a,b)=>fs.statSync(b).mtimeMs-fs.statSync(a).mtimeMs);
  const latest=backups[0]; const tampered=JSON.parse(fs.readFileSync(latest,'utf8')); tampered.mode='CONTROLLED_AUTONOMY'; fs.writeFileSync(latest,JSON.stringify(tampered));
  fs.writeFileSync(f.file,'{broken'); const r=store.loadState(f);
  assert.equal(r.recovered,true); assert.notEqual(r.state.mode,'CONTROLLED_AUTONOMY');
});

test('backup retention is bounded',()=>{
  const f=fixture(); let s=store.loadState(f).state;
  for(let i=0;i<25;i++){s.mode=i%2?'SHADOW':'RECOMMEND';s=store.saveState({...f,state:s});}
  const backups=fs.readdirSync(f.backupDir).filter(x=>x.endsWith('.json'));
  assert.ok(backups.length<=store.DEFAULT_BACKUP_RETENTION);
});

test('recovery drill proves recoverability without mutating primary',()=>{
  const f=fixture(); store.loadState(f); const before=fs.readFileSync(f.file,'utf8');
  const r=store.recoveryDrill(f); const after=fs.readFileSync(f.file,'utf8');
  assert.equal(r.passed,true); assert.equal(after,before);
});

test('unsigned backup is not eligible for automatic recovery',()=>{
  const f=fixture();store.loadState(f);const unsigned=path.join(f.backupDir,'state-unsigned.json');fs.mkdirSync(f.backupDir,{recursive:true});fs.copyFileSync(f.file,unsigned);
  const integrity=store.verifyBackupIntegrity(unsigned);assert.equal(integrity.valid,false);assert.equal(integrity.reason,'UNSIGNED_BACKUP_REJECTED');
  fs.writeFileSync(f.file,'{broken');assert.throws(()=>store.loadState(f));
});

test('backup lifecycle enforces byte budget while preserving recovery floor',()=>{
  const f=fixture(); let s=store.loadState(f).state;
  for(let i=0;i<8;i++){s.audit.push({id:String(i),payload:'x'.repeat(4096)});s=store.saveState({...f,state:s});}
  store.pruneBackups(f.backupDir,20,{maxAgeDays:30,maxBytes:9000,minRecoveryBackups:2});
  const h=store.storageHealth(f);
  assert.ok(h.backupCount>=2);
  assert.ok(h.backupBytes<=9000 || h.backupCount===2);
});

test('storage health exposes backup lifecycle posture',()=>{
  const f=fixture();store.loadState(f);let s=store.loadState(f).state;s=store.saveState({...f,state:s});
  const h=store.storageHealth(f);
  assert.equal(h.lifecycleHealthy,true);
  assert.ok(Number.isInteger(h.backupBytes));
  assert.equal(h.invalidBackupCount,0);
  assert.equal(h.backupPolicy.retention,store.DEFAULT_BACKUP_RETENTION);
  assert.equal(h.backupPolicy.minRecoveryBackups,store.MIN_RECOVERY_BACKUPS);
});
