'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const path=require('path');
const {run}=require('./self-check');
const ROOT=__dirname;

test('self-check summarizes a valid verified release without mutating release evidence',()=>{
  const out=run({write:false,verify:()=>({ready:true,decision:'START',releaseDigest:'a'.repeat(64),guardian:{gate:'RELEASE_CANDIDATE',coverage:{features:875,tests:109}},storage:{healthy:true},reasons:[]})});
  assert.equal(out.ok,true);
  assert.equal(out.decision,'START');
  assert.equal(out.storageHealthy,true);
  assert.equal(out.capabilities,875);
  assert.match(out.releaseDigest,/^[a-f0-9]{64}$/);
});

test('self-check reports HOLD blockers from verifier',()=>{
  const out=run({write:false,verify:()=>({ready:false,decision:'HOLD',guardian:{gate:'DEVELOPMENT_HOLD',coverage:{}},storage:{healthy:true},reasons:['RELEASE_ARTIFACT_DIGEST_MISMATCH:x']})});
  assert.equal(out.ok,false);
  assert.deepEqual(out.blockers,['RELEASE_ARTIFACT_DIGEST_MISMATCH:x']);
});

test('launchers run self-check before server startup',()=>{
  const win=fs.readFileSync(path.join(ROOT,'launch-loadify-intelligence.cmd'),'utf8');
  const sh=fs.readFileSync(path.join(ROOT,'launch-loadify-intelligence.sh'),'utf8');
  assert.match(win,/node self-check\.js[\s\S]*if errorlevel 1[\s\S]*node server\.js/i);
  assert.match(sh,/node self-check\.js[\s\S]*node server\.js/);
  assert.match(win,/127\.0\.0\.1:4173/);
  assert.match(sh,/127\.0\.0\.1:4173/);
});

test('release manifest builder includes launch and self-check artifacts',()=>{
  const src=fs.readFileSync(path.join(ROOT,'build-release-manifest.js'),'utf8');
  for(const f of ['self-check.js','launch-loadify-intelligence.cmd','launch-loadify-intelligence.sh']) assert.match(src,new RegExp(f.replaceAll('.','\\.')));
});
