@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Loadify Intelligence requires Node.js 20 or newer.
  echo No application files were changed.
  pause
  exit /b 1
)
node -e "const m=Number(process.versions.node.split('.')[0]);process.exit(m>=20?0:1)"
if errorlevel 1 (
  echo Loadify Intelligence requires Node.js 20 or newer.
  pause
  exit /b 1
)
echo Verifying Loadify Intelligence release...
node self-check.js
if errorlevel 1 (
  echo.
  echo Startup refused because the local release did not pass integrity/readiness checks.
  pause
  exit /b 1
)
start "Loadify Intelligence Runtime" cmd /k "cd /d \"%~dp0\" && node server.js"
timeout /t 2 /nobreak >nul
start "" "http://127.0.0.1:4173"
endlocal
