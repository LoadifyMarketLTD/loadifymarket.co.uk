'use strict';
const fs=require('fs');
const path=require('path');
const crypto=require('crypto');
const cp=require('child_process');
const ROOT=__dirname;
const DATA=path.join(ROOT,'data');
const OUT_ROOT=path.join(ROOT,'dist');
const OUT=path.join(OUT_ROOT,'loadify-intelligence-platform');
function shaFile(file){return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');}
function copy(rel){const src=path.join(ROOT,rel),dst=path.join(OUT,rel);if(!fs.existsSync(src))throw new Error(`DIST_SOURCE_MISSING:${rel}`);fs.mkdirSync(path.dirname(dst),{recursive:true});fs.copyFileSync(src,dst);}
function walk(dir,base=dir,out=[]){for(const ent of fs.readdirSync(dir,{withFileTypes:true})){const full=path.join(dir,ent.name);if(ent.isDirectory())walk(full,base,out);else out.push(path.relative(base,full).replaceAll(path.sep,'/'));}return out;}
function build(){
  const check=cp.spawnSync(process.execPath,['self-check.js'],{cwd:ROOT,encoding:'utf8'});
  if(check.status!==0) throw new Error(`DIST_SOURCE_SELF_CHECK_HOLD:${(check.stderr||check.stdout||'').trim()}`);
  const release=JSON.parse(fs.readFileSync(path.join(DATA,'release-manifest.json'),'utf8'));
  fs.rmSync(OUT,{recursive:true,force:true});fs.mkdirSync(path.join(OUT,'data','state-backups'),{recursive:true});
  const files=new Set(Object.keys(release.artifacts||{}));
  for(const suite of Object.keys(release.testSuiteDigests||{}))files.add(suite);
  for(const rel of ['data/feature-registry.json','data/standards-registry.json','data/threat-catalog.json','data/system-manifest.json','data/capability-evidence-index.json','data/loadify-market-compatibility-contract.json','data/seed-state.json','data/release-manifest.json','data/test-attestation.json'])files.add(rel);
  for(const rel of [...files].sort())copy(rel);
  fs.copyFileSync(path.join(DATA,'seed-state.json'),path.join(OUT,'data','state.json'));
  const packaged=walk(OUT).filter(x=>x!=='distribution-manifest.json').sort();
  const hashes=Object.fromEntries(packaged.map(rel=>[rel,shaFile(path.join(OUT,rel))]));
  const manifest={schemaVersion:2,product:'Loadify Intelligence Platform',environment:'standalone',releaseDigest:release.releaseDigest,generatedAt:new Date().toISOString(),files:hashes,prohibitions:{runtimeLock:true,developmentBackups:true,externalCredentials:true,liveConnections:true}};
  manifest.manifestDigest=crypto.createHash('sha256').update(JSON.stringify(manifest)).digest('hex');
  fs.writeFileSync(path.join(OUT,'distribution-manifest.json'),JSON.stringify(manifest,null,2)+'\n');
  const verify=cp.spawnSync(process.execPath,['verify-distribution.js',OUT],{cwd:ROOT,encoding:'utf8'});
  if(verify.status!==0)throw new Error(`DIST_VERIFY_FAILED:${verify.stderr||verify.stdout}`);
  console.log(JSON.stringify({ok:true,path:OUT,releaseDigest:release.releaseDigest,files:packaged.length,verification:JSON.parse(verify.stdout)}));
  return {out:OUT,manifest};
}
if(require.main===module)build();
module.exports={build};
