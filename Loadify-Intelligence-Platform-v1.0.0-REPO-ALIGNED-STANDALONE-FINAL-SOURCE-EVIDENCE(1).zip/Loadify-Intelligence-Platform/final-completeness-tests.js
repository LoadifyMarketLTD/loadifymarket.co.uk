'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const src=fs.readFileSync(path.join(__dirname,'final-completeness.js'),'utf8');
test('final completeness gate requires implemented feature states, complete evidence, current attestation and final lifecycle audit',()=>{for(const token of ['FEATURE_NOT_IMPLEMENTED','EVIDENCE_INDEX_COVERAGE_MISMATCH','TEST_ATTESTATION_NOT_FINAL','FINAL_AUDIT_NOT_CURRENT_PASS','FINAL_DISTRIBUTION_INVALID','STANDALONE_FINAL'])assert.ok(src.includes(token),token);});
test('final completeness gate holds the standalone boundary and canonical safe source baseline',()=>{for(const token of ['LIVE_CONNECTOR_BOUNDARY_BROKEN','SOURCE_RUNTIME_BASELINE_NOT_CANONICAL_SAFE','UNRESOLVED_SOURCE_MARKER','validateStandaloneEnv'])assert.ok(src.includes(token),token);});
