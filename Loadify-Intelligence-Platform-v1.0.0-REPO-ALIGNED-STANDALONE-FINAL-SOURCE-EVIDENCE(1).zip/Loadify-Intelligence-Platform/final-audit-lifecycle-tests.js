'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const src=fs.readFileSync(path.join(__dirname,'final-audit.js'),'utf8');
test('final audit covers clean install, browser auth, mutation persistence, recovery, restart replay and pristine distribution',()=>{
  for(const token of ['clean-install-browser-session','clean-install-unauthenticated-mutation-denied','clean-install-authenticated-mutation','same-process-idempotent-replay','post-mutation-storage-health','runtime-recovery-drill','restart-persistence-and-idempotent-replay','canonical-distribution-remains-pristine'])assert.ok(src.includes(token),token);
});
test('final audit uses a dynamically reserved loopback port and bounded child execution',()=>{assert.match(src,/reservePort/);assert.match(src,/127\.0\.0\.1/);assert.match(src,/timeout:240_000/);assert.match(src,/killSignal:'SIGKILL'/);});
