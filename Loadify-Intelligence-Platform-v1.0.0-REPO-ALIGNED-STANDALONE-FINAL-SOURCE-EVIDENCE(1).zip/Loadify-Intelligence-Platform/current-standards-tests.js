'use strict';
const test=require('node:test'); const assert=require('node:assert/strict');
const sec=require('./lib/agent-security-engine');
const protocol=require('./lib/protocol-engine');
const transparency=require('./lib/transparency-engine');

test('goal hijack from untrusted source is denied or reviewed',()=>{
 const r=sec.evaluateAgentAction({goalChanged:true,goalChangeSource:'UNTRUSTED_PRODUCT_CONTENT',toolRequested:'catalog.read',allowedTools:['catalog.read'],capabilities:['catalog.read'],requestedCapability:'catalog.read'});
 assert.equal(r.allowed,false); assert.ok(r.mappedRisks.includes('ASI01'));
});

test('rogue agent governance bypass is critical deny',()=>{
 const r=sec.evaluateAgentAction({policyBypassAttempt:true}); assert.equal(r.decision,'DENY'); assert.ok(r.mappedRisks.includes('ASI10'));
});

test('inter-agent handoff requires authenticated integrity and preserves untrusted instructions as data',()=>{
 const r=sec.verifyHandoff({fromAgentId:'a',toAgentId:'b',reason:'review',requestedCapability:'review',traceId:'t',authenticated:true,integrityVerified:true,receiverCapabilities:['review'],untrustedInstructionsPreservedAsData:true});
 assert.equal(r.allowed,true);
});

test('unverified agent component is quarantined',()=>{
 const r=sec.componentAdmission({id:'tool-x',version:'1.0.0',sourceVerified:false,integrityVerified:true,permissionsReviewed:true,versionPinned:true}); assert.equal(r.admit,false);
});

test('UCP negotiation selects mutually supported capability version',()=>{
 const r=protocol.negotiateUcp({business:{version:'2026-04-08',supportedVersions:{'2026-01-23':'/old'},capabilities:{'dev.ucp.shopping.checkout':[{version:'2026-04-08'},{version:'2026-01-23'}]}},platform:{version:'2026-04-08',capabilities:{'dev.ucp.shopping.checkout':[{version:'2026-04-08'}]}},requiredCapabilities:['dev.ucp.shopping.checkout']});
 assert.equal(r.ok,true); assert.equal(r.capabilities['dev.ucp.shopping.checkout'].version,'2026-04-08');
});

test('agent commerce request fails closed when capability was not negotiated',()=>{
 const r=protocol.validateAgentCommerceRequest({agentId:'a',principalId:'p',intentId:'i',mandateId:'m',traceId:'t',capability:'checkout',negotiatedCapabilities:[]}); assert.equal(r.allowed,false);
});

test('EU AI interaction requires transparency disclosure after Article 50 effective date',()=>{
 const r=transparency.assessTransparency({jurisdiction:'EU',effectiveDate:'2026-08-20',userInteractsWithAI:true,provided:['ARTICLE_50_POLICY_CHECK']}); assert.equal(r.compliant,false); assert.ok(r.missing.includes('AI_INTERACTION_DISCLOSURE'));
});
