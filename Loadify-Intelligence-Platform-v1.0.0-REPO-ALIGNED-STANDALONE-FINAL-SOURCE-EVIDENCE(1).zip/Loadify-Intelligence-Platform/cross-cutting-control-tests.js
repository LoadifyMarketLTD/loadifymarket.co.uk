'use strict';
const test=require('node:test');const assert=require('node:assert/strict');
const audit=require('./lib/audit-ledger-engine');const gov=require('./lib/governance-engine');const integrations=require('./lib/integration-engine');
test('audit ledger detects mutation',()=>{let l=[];l=audit.append(l,{actorId:'a',action:'x'});l=audit.append(l,{actorId:'b',action:'y'});assert.equal(audit.verify(l).valid,true);l[0].action='tampered';assert.equal(audit.verify(l).valid,false);});
test('R4 governance entry requires responsible human',()=>{const r=gov.validateRegistryEntry({id:'a',name:'A',purpose:'p',businessOwner:'b',technicalOwner:'t',riskOwner:'r',riskClass:'R4'});assert.equal(r.valid,false);});
test('autonomy promotion is evidence gated',()=>{const r=gov.autonomyChange({current:1,target:2,evidencePass:false,evalPass:true,riskOwnerApproval:true});assert.equal(r.allowed,false);});
test('connected connector requires explicit approval and scoped brokered credentials',()=>{const r=integrations.validateConnector({id:'x',type:'api',status:'CONNECTED_APPROVED',explicitApproval:false,scopes:['read'],credentialMode:'BROKERED_SCOPED',healthCheck:true});assert.equal(r.valid,false);});
test('wildcard connector scopes fail closed',()=>{const r=integrations.validateConnector({id:'x',type:'api',status:'DEMO',wildcardScope:true});assert.equal(r.valid,false);});
