'use strict';
const test=require('node:test'); const assert=require('node:assert/strict'); const g=require('./lib/guardian-engine');
const manifest={externalConnections:[],connectorMode:'adapters-only-not-connected',invariants:['human-first-agent-ready','evidence-before-autonomy','policy-before-execution','deterministic-money-and-state','core-commerce-survives-ai-outage','untrusted-content-is-data-not-instruction']};
test('guardian refuses release while planned features remain',()=>{const r=g.releaseReadiness({manifest,registry:[{status:'PLANNED'}],standards:[{}],testSummary:{total:10,failed:0}});assert.equal(r.ready,false);assert.equal(r.gate,'DEVELOPMENT_HOLD');});
test('guardian detects forbidden architecture drift',()=>{const r=g.architectureDrift({manifest,runtime:{environment:'standalone-development',mode:'CONTROLLED_AUTONOMY',rawSqlEnabled:true,directSecretsAccess:false,financialExecutionByModel:false}});assert.equal(r.healthy,false);assert.ok(r.findings.includes('RAW_SQL_AGENT_PATH_FORBIDDEN'));});
test('guardian allows release candidate only with no blockers',()=>{const r=g.releaseReadiness({manifest,registry:[{status:'IMPLEMENTED_MODEL'}],standards:[{}],testSummary:{total:10,failed:0}});assert.equal(r.ready,true);});
test('guardian requires complete OWASP Agentic + Agentic Skills coverage when threat catalog supplied',()=>{const threats=[...Array.from({length:10},(_,i)=>({id:`ASI${String(i+1).padStart(2,'0')}`,controls:['control'],verificationRefs:['test.js']})),...Array.from({length:10},(_,i)=>({id:`AST${String(i+1).padStart(2,'0')}`,controls:['control'],verificationRefs:['test.js']}))];const r=g.releaseReadiness({manifest,registry:[{status:'IMPLEMENTED_MODEL'}],standards:[{}],threats,testSummary:{total:10,failed:0}});assert.equal(r.ready,true);assert.equal(r.coverage.threats,20);});
test('guardian fails closed when an Agentic Top 10 threat is missing',()=>{const threats=Array.from({length:9},(_,i)=>({id:`ASI${String(i+1).padStart(2,'0')}`,controls:['control'],verificationRefs:['test.js']}));const r=g.releaseReadiness({manifest,registry:[{status:'IMPLEMENTED_MODEL'}],standards:[{}],threats,testSummary:{total:10,failed:0}});assert.equal(r.ready,false);assert.match(r.blockers.join('|'),/ASI10/);});

test('old but cryptographically/build-bound test evidence is a governance warning, not a runtime outage',()=>{
  const manifest={connectorMode:'adapters-only-not-connected',externalConnections:[],releaseDigest:'abc',invariants:['human-first-agent-ready','evidence-before-autonomy','policy-before-execution','deterministic-money-and-state','core-commerce-survives-ai-outage','untrusted-content-is-data-not-instruction'],coverage:{testSuites:1}};
  const attestation={releaseDigest:'abc',failedSuites:0,suitesTotal:1,generatedAt:new Date(Date.now()-40*24*60*60*1000).toISOString(),results:[{suiteSha256:'a'.repeat(64)}]};
  const r=require('./lib/guardian-engine').releaseReadiness({manifest,registry:[],standards:[{status:'ACTIVE'}],threats:null,attestation});
  assert.equal(r.ready,true);assert.ok(r.warnings.includes('TEST_ATTESTATION_REVALIDATION_DUE'));
});


test('Guardian fails closed when Agentic Skills threat coverage is incomplete',()=>{
 const threats=Array.from({length:10},(_,i)=>({id:`ASI${String(i+1).padStart(2,'0')}`,controls:['x'],verificationRefs:['t']}));
 const r=g.releaseReadiness({manifest:{externalConnections:[],connectorMode:'adapters-only-not-connected',invariants:['human-first-agent-ready','evidence-before-autonomy','policy-before-execution','deterministic-money-and-state','core-commerce-survives-ai-outage','untrusted-content-is-data-not-instruction']},registry:[],standards:[{status:'ACTIVE'}],threats,testSummary:{total:1,failed:0}});
 assert.equal(r.ready,false);assert.ok(r.blockers.some(x=>x.startsWith('AGENT_SKILL_THREAT_COVERAGE_MISSING:')));
});

test('guardian requires attested threat verification evidence for real release attestations',()=>{
 const threats=[
  ...Array.from({length:10},(_,i)=>({id:`ASI${String(i+1).padStart(2,'0')}`,controls:['control'],verificationRefs:['real-tests.js']})),
  ...Array.from({length:10},(_,i)=>({id:`AST${String(i+1).padStart(2,'0')}`,controls:['control'],verificationRefs:['real-tests.js']}))
 ];
 const m={...manifest,releaseDigest:'rel',coverage:{testSuites:1}};
 const att={releaseDigest:'rel',failedSuites:0,suitesTotal:1,generatedAt:new Date().toISOString(),results:[{suite:'real-tests.js',suiteSha256:'a'.repeat(64),passed:true}]};
 const pass=g.releaseReadiness({manifest:m,registry:[],standards:[{}],threats,attestation:att});
 assert.equal(pass.ready,true);
 threats[0]={...threats[0],verificationRefs:['missing-tests.js']};
 const fail=g.releaseReadiness({manifest:m,registry:[],standards:[{}],threats,attestation:att});
 assert.equal(fail.ready,false);
 assert.ok(fail.blockers.includes('THREAT_WITHOUT_ATTESTED_TEST_EVIDENCE:ASI01'));
});

test('guardian blocks evidence-required capabilities without resolvable evidence metadata',()=>{
 const base={id:'LIP-X',status:'IMPLEMENTED_MODEL',evidenceRequired:true,verificationRefs:['control-plane-tests.js'],evidenceScope:'DIRECT'};
 assert.equal(g.releaseReadiness({manifest,registry:[base],standards:[{}],testSummary:{total:1,failed:0}}).ready,true);
 assert.equal(g.releaseReadiness({manifest,registry:[{...base,verificationRefs:[]}],standards:[{}],testSummary:{total:1,failed:0}}).ready,false);
 assert.equal(g.releaseReadiness({manifest,registry:[{...base,evidenceScope:'UNKNOWN'}],standards:[{}],testSummary:{total:1,failed:0}}).ready,false);
});
