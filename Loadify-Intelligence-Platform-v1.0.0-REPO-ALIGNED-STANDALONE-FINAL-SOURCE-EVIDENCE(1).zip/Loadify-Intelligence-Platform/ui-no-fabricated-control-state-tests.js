'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const path=require('path');

test('control-plane pages fail visibly when canonical runtime is unavailable',()=>{
 const src=fs.readFileSync(path.join(__dirname,'app.js'),'utf8');
 assert.match(src,/function runtimeUnavailable/);
 for(const name of ['experiments','agentsPage','autopilot','auditPage','integrations','policy']){
   const re=new RegExp(`function ${name}\\(\\)\\{if\\(!state\\.runtimeLoaded\\)return runtimeUnavailable`);
   assert.match(src,re,name);
 }
 assert.doesNotMatch(src,/const fallbackAgents/);
 assert.doesNotMatch(src,/audit:\[\s*\{time:/);
 assert.doesNotMatch(src,/approvals:\[\s*\{id:/);
});
