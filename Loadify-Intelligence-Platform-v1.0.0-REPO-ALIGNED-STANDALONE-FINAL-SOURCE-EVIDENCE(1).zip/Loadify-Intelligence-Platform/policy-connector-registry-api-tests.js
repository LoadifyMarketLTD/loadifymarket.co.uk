'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const path=require('path');
const {server}=require('./server');
let base;
test.before(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));base=`http://127.0.0.1:${server.address().port}`;});
test.after(async()=>new Promise(r=>server.close(r)));

test('policy endpoint exposes canonical bundle',async()=>{
 const r=await fetch(base+'/api/policy/bundle');assert.equal(r.status,200);const j=await r.json();
 assert.equal(j.id,'LIP-CONSTITUTION');assert.equal(j.version,'1.0.0');assert.equal(j.rules.length,20);assert.equal(j.defaultHighRiskDecision,'DENY');
});

test('integration registry endpoint explicitly forbids live standalone connections',async()=>{
 const r=await fetch(base+'/api/integrations/registry');assert.equal(r.status,200);const j=await r.json();
 assert.equal(j.liveConnectionsEnabled,false);assert.equal(j.items.length,7);assert.ok(j.items.every(c=>c.liveConnection===false&&c.credentialMode==='NONE'));
});

test('front-end consumes policy and integration registries instead of hardcoded copies',()=>{
 const src=fs.readFileSync(path.join(__dirname,'app.js'),'utf8');
 assert.match(src,/api\('\/api\/policy\/bundle'\)/);assert.match(src,/api\('\/api\/integrations\/registry'\)/);
 assert.match(src,/state\.policyBundle/);assert.match(src,/state\.connectorRegistry/);
 assert.doesNotMatch(src,/const xs=\[\['Loadify Market'/);
 assert.doesNotMatch(src,/const rules=\['Human-first, agent-ready'/);
});
