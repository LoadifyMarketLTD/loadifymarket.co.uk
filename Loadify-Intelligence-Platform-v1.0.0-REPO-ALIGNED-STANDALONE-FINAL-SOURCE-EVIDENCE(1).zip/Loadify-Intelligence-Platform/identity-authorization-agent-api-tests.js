'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const {server}=require('./server');let base;
test.before(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));base=`http://127.0.0.1:${server.address().port}`});test.after(async()=>{await new Promise(r=>server.close(r));});
async function post(path,body){const r=await fetch(base+path,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});assert.equal(r.status,200);return r.json()}
test('organization identity endpoint rejects unverified org',async()=>{const r=await post('/api/identity/organization/validate',{id:'o',legalName:'Org',status:'ACTIVE',verificationStatus:'PENDING'});assert.equal(r.valid,false)});
test('delegation endpoint rejects actor mismatch',async()=>{const r=await post('/api/authorization/delegation-chain',{chain:[{delegatorId:'p',delegateId:'a',capabilities:['buy']}],request:{actorId:'other',principalId:'p',capability:'buy'}});assert.equal(r.allowed,false)});
test('agent release endpoint blocks missing security gate',async()=>{const r=await post('/api/agents/release/validate',{agentId:'a',agentVersion:'1',modelRef:'m',promptVersion:'p',policyVersion:'v',evalSuiteRef:'e',artifactDigest:'d',evalPass:true,policyPass:true});assert.equal(r.releasable,false)});
