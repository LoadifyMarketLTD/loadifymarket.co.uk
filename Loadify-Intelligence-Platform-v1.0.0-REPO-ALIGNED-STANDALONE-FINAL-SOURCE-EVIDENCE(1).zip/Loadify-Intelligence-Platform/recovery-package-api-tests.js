'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const {server}=require('./server');
let base;
test.before(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));base=`http://127.0.0.1:${server.address().port}`});
test.after(async()=>{await new Promise(r=>server.close(r))});
test('exports a verifiable standalone recovery package',async()=>{
  const r=await fetch(`${base}/api/storage/export-package`);assert.equal(r.status,200);const p=await r.json();
  assert.equal(p.format,'LIP_STATE_EXPORT_V1');assert.equal(p.integrity.algorithm,'SHA-256');assert.ok(p.integrity.stateDigest);assert.ok(p.integrity.packageDigest);
});
test('import endpoint validates only and never applies',async()=>{
  let r=await fetch(`${base}/api/storage/export-package`);const p=await r.json();
  r=await fetch(`${base}/api/storage/import-package/validate`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(p)});assert.equal(r.status,200);const j=await r.json();
  assert.equal(j.valid,true);assert.equal(j.applyAllowed,false);assert.equal(j.mode,'DRY_RUN_ONLY');
});
