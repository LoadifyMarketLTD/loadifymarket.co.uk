const test=require('node:test');const assert=require('node:assert/strict');const {server}=require('./server');let base;
test.before(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));base=`http://127.0.0.1:${server.address().port}`});test.after(()=>server.close());
async function post(p,b={}){const r=await fetch(base+p,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(b)});assert.equal(r.status,200);return r.json()}
test('learning admission quarantines poison',async()=>assert.equal((await post('/api/immune/learning-admission',{trustedSource:false,promptInjectionSuspected:true})).admit,false));
test('review ring API flags coordinated pattern',async()=>assert.equal((await post('/api/immune/review-ring',{reviews:[{sameDeviceAsSeller:true},{reciprocalPattern:true}]})).risk,'HIGH'));
test('case evidence pack remains appealable',async()=>assert.equal((await post('/api/immune/evidence-pack',{evidence:[]})).appealable,true));
test('synthetic suite passes',async()=>assert.equal((await post('/api/immune/synthetic-suite')).pass,true));
