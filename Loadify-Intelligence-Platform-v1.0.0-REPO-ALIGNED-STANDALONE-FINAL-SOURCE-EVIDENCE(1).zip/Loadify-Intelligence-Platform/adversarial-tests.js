const test=require('node:test');
const assert=require('node:assert/strict');
const {evaluateAction}=require('./lib/policy-engine');
const {resolveClaim,admissionDecision}=require('./lib/evidence-engine');
const {trustVector}=require('./lib/trust-engine');
const {validateMandate,validateIntent,authorize}=require('./lib/authorization-engine');
const {assessCase,metricIntegrity,recoveryPlan}=require('./lib/immune-engine');

const now=new Date();
const iso=(deltaHours=0)=>new Date(now.getTime()+deltaHours*3600000).toISOString();

test('prompt-injection content is quarantined from durable evidence',()=>{
 const d=admissionDecision({authority:'seller_supplied',observedAt:iso(),instructionLike:true,labels:['prompt_injection']});
 assert.equal(d.admit,false); assert.equal(d.state,'QUARANTINED');
});

test('memory poisoning cannot convert untrusted instruction into confirmed fact',()=>{
 const r=resolveClaim('price=£1',[{authority:'seller_supplied',source:'listing',observedAt:iso(),supports:true,instructionLike:true,labels:['memory_poisoning']},{authority:'untrusted',source:'review',observedAt:iso(),supports:true,poisoningSuspected:true}]);
 assert.equal(r.state,'QUARANTINED'); assert.equal(r.confidence,0);
});

test('stale stock evidence fails closed',()=>{
 const r=resolveClaim('stock=10',[{claimType:'stock',authority:'verified_provider',source:'supplier-feed',observedAt:iso(-10),supports:true}]);
 assert.equal(r.state,'STALE'); assert.ok(r.reasons.includes('EVIDENCE_EXPIRED'));
});

test('conflicting authoritative claims do not become confirmed',()=>{
 const r=resolveClaim('warranty=24m',[{authority:'authoritative',source:'manufacturer',observedAt:iso(),supports:true,corroboratingSources:2},{authority:'regulated_registry',source:'registry',observedAt:iso(),supports:false,corroboratingSources:1}]);
 assert.equal(r.state,'CONFLICT');
});

test('trust score shrinks sparse extreme evidence toward prior',()=>{
 const t=trustVector({identity:100,fulfilment:100,catalogIntegrity:100,stockReliability:100,disputeHealth:100,safetyCompliance:100,evidenceQuality:100,reviewIntegrity:100,supplierReliability:100,sampleSize:1});
 assert.equal(t.band,'INSUFFICIENT_DATA'); assert.ok(t.score<80); assert.ok(t.uncertainty>50);
});

test('household sharing lowers graph risk rather than proving collusion',()=>{
 const same={signals:{velocity:.4,deviceOverlap:.9,graphDensity:.7},graph:{nodes:4,edges:7,sharedIdentifiers:3,temporalCoordination:.4},signalCoverage:.8,sourceDiversity:.7,historyDepth:.6};
 const a=assessCase(same); const b=assessCase({...same,graph:{...same.graph,knownSharedHousehold:true}});
 assert.ok(b.riskScore<a.riskScore); assert.equal(b.permanentSanctionAllowed,false);
});

test('high false-positive cost reduces automated friction pressure',()=>{
 const base={signals:{velocity:.8,graphDensity:.8,deviceOverlap:.7,paymentRisk:.5,reviewAnomaly:.8},graph:{nodes:5,edges:8,sharedIdentifiers:2,temporalCoordination:.7},signalCoverage:.8,sourceDiversity:.8,historyDepth:.8};
 const low=assessCase({...base,falsePositiveCost:0}); const high=assessCase({...base,falsePositiveCost:1});
 assert.ok(high.riskScore<low.riskScore); assert.equal(high.friction.irreversible,false);
});

test('critical conversion metrics from unverified client events are quarantined',()=>{
 const m=metricIntegrity([{id:1,metric:'seller_activation',serverVerified:false,sourceTrust:.9},{id:2,metric:'seller_activation',serverVerified:true,sourceTrust:.9}]);
 assert.equal(m.admitted,1); assert.equal(m.quarantined,1); assert.equal(m.integrityScore,.5);
});

test('bot traffic is excluded from learning admission',()=>{
 const m=metricIntegrity([{metric:'click',serverVerified:true,sourceTrust:.8,botLikelihood:.95}]);
 assert.equal(m.quarantined,1); assert.ok(m.quarantinedEvents[0].admission.reasons.includes('LIKELY_AUTOMATION'));
});

test('material price change requires reauthorization even within mandate budget',()=>{
 const d=validateMandate({id:'M',principalId:'P',actorId:'A',capabilities:['purchase'],perOrderLimit:1000,expiresAt:iso(2)},{actorId:'A',principalId:'P',capability:'purchase',amount:20,materialChange:true});
 assert.equal(d.allowed,false); assert.ok(d.reasons.includes('MATERIAL_CHANGE_REAUTHORIZATION_REQUIRED'));
});

test('merchant-bound mandate cannot be replayed at another merchant',()=>{
 const d=validateMandate({id:'M',principalId:'P',actorId:'A',capabilities:['purchase'],merchantId:'merchant-1',expiresAt:iso(2)},{actorId:'A',principalId:'P',capability:'purchase',merchantId:'merchant-2'});
 assert.equal(d.allowed,false); assert.ok(d.reasons.includes('MERCHANT_BINDING_MISMATCH'));
});

test('uncertified agent cannot act for principal even with otherwise valid mandate',()=>{
 const r=authorize({actor:{id:'A',type:'agent',certification:'EXPIRED'},principal:{id:'P'},mandate:{id:'M',principalId:'P',actorId:'A',capabilities:['purchase'],expiresAt:iso(2)},intent:{id:'I',type:'PURCHASE',nonce:'n',scope:['checkout'],expiresAt:iso(1)},action:{capability:'purchase',scope:'checkout'}});
 assert.equal(r.allowed,false); assert.ok(r.reasons.includes('AGENT_NOT_CERTIFIED'));
});

test('intent audience binding prevents cross-service replay',()=>{
 const d=validateIntent({id:'I',type:'PURCHASE',nonce:'n2',audience:'checkout.loadify',expiresAt:iso(1)},{audience:'payments.loadify'});
 assert.equal(d.allowed,false); assert.ok(d.reasons.includes('INTENT_AUDIENCE_MISMATCH'));
});

test('untrusted evidence plus human approval still cannot directly drive payment execution',()=>{
 const d=evaluateAction({actorType:'agent',action:'execute_payment',domain:'payments',sourceLabels:['review_content'],reversible:false,humanApproval:true,intentAligned:true,evidenceState:'CONFIRMED'});
 assert.equal(d.allowed,false); assert.ok(d.reasons.includes('UNTRUSTED_SOURCE_TO_PROTECTED_SINK_FORBIDDEN'));
});

test('agent cannot self-grant privilege even with humanApproval flag supplied by caller',()=>{
 const d=evaluateAction({actorType:'agent',action:'grant_self_privilege',domain:'governance',reversible:false,humanApproval:true,intentAligned:true,evidenceState:'CONFIRMED'});
 assert.equal(d.allowed,false); assert.ok(d.reasons.includes('SELF_GOVERNANCE_FORBIDDEN'));
});

test('recovery plan restores capabilities only after confirmed false positive',()=>{
 const a=recoveryPlan({falsePositiveConfirmed:false}); const b=recoveryPlan({falsePositiveConfirmed:true});
 assert.equal(a.steps.includes('restore_capabilities'),false); assert.equal(b.steps.includes('restore_capabilities'),true); assert.equal(b.reversible,true);
});
