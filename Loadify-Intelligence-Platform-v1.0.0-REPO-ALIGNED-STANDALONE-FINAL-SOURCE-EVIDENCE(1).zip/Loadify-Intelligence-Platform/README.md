# Loadify Intelligence Platform — Standalone Control Plane

Loadify Intelligence Platform (LIP) is a standalone, local-first control-plane application for marketplace intelligence, trust, governance, experimentation, agent security, policy enforcement and bounded autonomy.

## Final standalone status

Version **1.0.0** is the completed standalone build. The final completeness gate must report `STANDALONE_FINAL` before this build is treated as deliverable. Completion applies to the isolated standalone product only; connecting Loadify Market or any external live service is a separate, explicitly authorized post-completion phase.

The final build contains **902 implemented capabilities** with complete capability-evidence indexing. The current signed release gate attests **146/146 test suites passing**, and the final audit exercises a clean distribution, browser-session authorization, authenticated state mutation, same-process idempotent replay, storage recovery, restart persistence, cross-restart replay and canonical distribution integrity.

## Current operating boundary

This build is intentionally isolated. It is **not connected to Loadify Market** and has no live Stripe, Supabase, GitHub, analytics, identity-provider or AI-provider connection. External integrations remain adapters-only until a separate post-completion authorization decision.


## Loadify Market repository compatibility

This standalone v1.0.0 build is explicitly aligned to the audited Loadify Market repository contract while remaining disconnected. The compatibility contract is stored in `data/loadify-market-compatibility-contract.json` and the runtime boundary in `lib/loadify-market-compatibility-engine.js`.

The boundary is intentional: Loadify Market remains the sole owner of canonical product/supplier-offer, sellable-stock, customer-order, payment, supplier-order, fulfilment, tracking, returns/refunds, supplier-recovery and canonical-financial truth. Loadify Intelligence may interpret evidence, assess trust/risk, recommend and emit bounded action intents; it must not create a parallel commerce ledger or execute direct Supabase/Stripe/supplier side effects.

The audited repository snapshot was `LoadifyMarketLTD/loadifymarket.co.uk` main `87b571c7f316742f85ad4ff8360597e5a0861f8d` (tree `8cee7901bb936122f73ac98e9e7fe77fb14b8d20`). Any later main movement requires re-verification before integration. No live connection or credential is included.

## Run locally

Requires Node.js 20 or newer.

```bash
npm start
```

Then open the local URL printed by the server (default `http://127.0.0.1:4173`). The UI hydrates its control state from the persistent local runtime API; opening `index.html` directly is not the supported execution mode.

## Verification

```bash
npm test
npm run release:manifest
npm run release:gate
npm run audit:final
npm run audit:complete
```

The release gate runs all discovered `*tests.js` suites in isolated child processes with bounded execution time and output, restores persistent runtime state after testing, verifies release-manifest freshness before execution, and writes a local test attestation bound to the exact release digest. Guardian readiness consumes that local attestation rather than caller-supplied test counts.

`npm run audit:final` builds and verifies the distribution and executes the clean-install lifecycle audit. `npm run audit:complete` is the terminal standalone closure gate; it requires implemented feature state, full evidence-index coverage, current passing attestation, a current final-audit PASS, a pristine verified distribution, a canonical safe source runtime baseline and zero live connectors.

## Safety invariants

- Human-first, agent-ready.
- Evidence before autonomy; policy before execution.
- Deterministic software controls money, state and policy-sensitive execution.
- No raw SQL or direct production credentials for agents.
- High-risk, financial, security, compliance and irreversible actions remain gated.
- Untrusted content is data, never instruction.
- Core commerce must be able to survive AI unavailability.
- No live marketplace connection exists in this standalone build.

## Startup integrity

Standalone startup is fail-closed: the runtime verifies release artifact and registry digests, validates the cryptographically bound local test attestation through Guardian, checks State Store health, validates the runtime-lock filesystem boundary and acquires a single-instance lock before listening on loopback. A second process using the same data directory is refused. Shutdown is bounded and cleans the runtime lock deterministically.
