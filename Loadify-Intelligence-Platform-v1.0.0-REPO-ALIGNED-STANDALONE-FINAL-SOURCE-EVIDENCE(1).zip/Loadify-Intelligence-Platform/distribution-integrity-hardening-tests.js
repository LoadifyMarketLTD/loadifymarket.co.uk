'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const crypto=require('node:crypto');
const {verify,safeRelative}=require('./verify-distribution');
function digest(v){return crypto.createHash('sha256').update(v).digest('hex');}
function fixture(){
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'lip-dist-integrity-'));fs.mkdirSync(path.join(root,'data','state-backups'),{recursive:true});
 for(const [rel,body] of [['data/seed-state.json','{}\n'],['data/state.json','{}\n'],['self-check.js',"process.exit(0)\n"]]){const f=path.join(root,rel);fs.mkdirSync(path.dirname(f),{recursive:true});fs.writeFileSync(f,body);}
 const files={};for(const rel of ['data/seed-state.json','data/state.json','self-check.js'])files[rel]=digest(fs.readFileSync(path.join(root,rel)));
 const m={schemaVersion:2,product:'Loadify Intelligence Platform',environment:'standalone',releaseDigest:'a'.repeat(64),generatedAt:new Date().toISOString(),files,prohibitions:{runtimeLock:true,developmentBackups:true,externalCredentials:true,liveConnections:true}};m.manifestDigest=digest(JSON.stringify(m));fs.writeFileSync(path.join(root,'distribution-manifest.json'),JSON.stringify(m,null,2)+'\n');return root;
}
test('distribution verifier rejects files that were not declared in the signed distribution manifest',()=>{const root=fixture();fs.writeFileSync(path.join(root,'extra.js'),'x');const r=verify(root);assert.equal(r.ok,false);assert.ok(r.errors.includes('UNDECLARED_FILE:extra.js'));fs.rmSync(root,{recursive:true,force:true});});
test('distribution verifier rejects manifest tampering and unsafe declared paths',()=>{const root=fixture();let m=JSON.parse(fs.readFileSync(path.join(root,'distribution-manifest.json'),'utf8'));m.generatedAt='tampered';fs.writeFileSync(path.join(root,'distribution-manifest.json'),JSON.stringify(m));let r=verify(root);assert.ok(r.errors.includes('DISTRIBUTION_MANIFEST_DIGEST_MISMATCH'));assert.equal(safeRelative('../x'),false);assert.equal(safeRelative('lib/x.js'),true);fs.rmSync(root,{recursive:true,force:true});});
test('distribution verifier rejects symlinked declared payloads',()=>{const root=fixture();const target=path.join(root,'target');fs.writeFileSync(target,'x');const link=path.join(root,'link.js');fs.symlinkSync(target,link);let m=JSON.parse(fs.readFileSync(path.join(root,'distribution-manifest.json'),'utf8'));m.files['link.js']=digest(Buffer.from('x'));delete m.manifestDigest;m.manifestDigest=digest(JSON.stringify(m));fs.writeFileSync(path.join(root,'distribution-manifest.json'),JSON.stringify(m));const r=verify(root);assert.ok(r.errors.includes('UNSAFE_FILE_TYPE:link.js'));fs.rmSync(root,{recursive:true,force:true});});
