const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { evaluateAction } = require('./lib/policy-engine');
const { resolveClaim, admissionDecision, provenanceChain } = require('./lib/evidence-engine');
const { trustVector } = require('./lib/trust-engine');
const { validateMandate, validateIntent, authorize } = require('./lib/authorization-engine');
const { assessCase, metricIntegrity, recoveryPlan } = require('./lib/immune-engine');
const { runAdversarialSuite } = require('./lib/redteam');
const eventFabric = require('./lib/event-fabric');
const experiments = require('./lib/experiment-engine');
const memory = require('./lib/decision-memory');
const evals = require('./lib/eval-engine');
const observability = require('./lib/observability');
const finops = require('./lib/finops-engine');
const privacy = require('./lib/privacy-engine');
const reliability = require('./lib/reliability-engine');
const agentSecurity = require('./lib/agent-security-engine');
const protocol = require('./lib/protocol-engine');
const transparency = require('./lib/transparency-engine');
const supplyChain = require('./lib/supply-chain-engine');
const connectorSecurity = require('./lib/connector-security-engine');
const guardian = require('./lib/guardian-engine');
const catalog = require('./lib/catalog-engine');
const searchEngine = require('./lib/search-engine');
const recommendations = require('./lib/recommendation-engine');
const reviewIntegrity = require('./lib/review-integrity-engine');
const supportEngine = require('./lib/support-engine');
const productSafety = require('./lib/product-safety-engine');
const demandEngine = require('./lib/demand-engine');
const sellerIntel = require('./lib/seller-intelligence-engine');
const buyerIntel = require('./lib/buyer-intelligence-engine');
const strategic = require('./lib/strategic-engine');
const identityEngine = require('./lib/identity-engine');
const agenticCommerce = require('./lib/agentic-commerce-engine');
const financialFirewall = require('./lib/financial-firewall-engine');
const engineeringIntel = require('./lib/engineering-intelligence-engine');
const auditLedger = require('./lib/audit-ledger-engine');
const stateStore = require('./lib/state-store-engine');
const governanceEngine = require('./lib/governance-engine');
const integrationEngine = require('./lib/integration-engine');
const controlPlane = require('./lib/control-plane-engine');
const commerceTrust = require('./lib/commerce-trust-engine');
const learningGovernance = require('./lib/learning-governance-engine');
const standardsGovernance = require('./lib/standards-governance-engine');
const capabilityLifecycle = require('./lib/capability-lifecycle-engine');
const productStandards = require('./lib/product-standards-engine');
const operatorControl = require('./lib/operator-control-engine');
const agentRegistry = require('./lib/agent-registry-engine');
const finalHardening = require('./lib/final-planned-hardening');
const contractRegistry = require('./lib/contract-registry-engine');
const capabilityRuntimeSpec = require('./lib/capability-runtime-spec-engine');
const agentTrustBoundary = require('./lib/agent-trust-boundary-engine');
const wave4 = require('./lib/designed-wave4-engine');
const immuneWave = require('./lib/immune-wave-engine');
const wave5 = require('./lib/marketplace-wave5-engine');
const wave6 = require('./lib/identity-agentic-wave6-engine');
const runtimeConfigEngine = require('./lib/runtime-config-engine');
const runtimeStartup = require('./lib/runtime-startup-engine');
const agentSkillSecurity = require('./lib/agent-skill-security-engine');
const recoveryPackage = require('./lib/recovery-package-engine');
const apiContracts = require('./lib/api-contract-engine');
const simulation = require('./lib/simulation-engine');
const policyBundle = require('./lib/policy-bundle-engine');
const connectorRegistry = require('./lib/connector-registry-engine');
const contextSecurity = require('./lib/context-security-engine');
const controlMetrics = require('./lib/control-metrics-engine');
const llmSecurity = require('./lib/llm-security-engine');
const {createRequestBudget} = require('./lib/request-budget-engine');
const {createIdempotencyStore} = require('./lib/idempotency-engine');
const {readStaticAsset} = require('./lib/static-asset-engine');
const httpAdmission = require('./lib/http-admission-engine');
const loadifyMarketCompatibility = require('./lib/loadify-market-compatibility-engine');

const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, 'data');
const STATE_FILE = path.join(DATA_DIR, 'state.json');
const REGISTRY_FILE = path.join(DATA_DIR, 'feature-registry.json');
const STATE_BACKUP_DIR = path.join(DATA_DIR, 'state-backups');
const RUNTIME_CONFIG = runtimeConfigEngine.runtimeConfig(process.env);
const PORT = RUNTIME_CONFIG.port;
const LOCAL_SESSION_COOKIE = 'LIP_LOCAL_SESSION';
const LOCAL_SESSION_SECRET = crypto.randomBytes(32).toString('hex');
const LOCAL_TOOLING_SECRET = crypto.randomBytes(32).toString('hex');
const IS_TEST_PROCESS = process.env.LIP_TEST_MODE==='1' || process.argv.some(a=>/tests\.js$/i.test(String(a||'')));
const REQUEST_BUDGET = createRequestBudget();
const IDEMPOTENCY_STORE = createIdempotencyStore({file:IS_TEST_PROCESS?null:path.join(DATA_DIR,'idempotency-store.json')});
const TRANSPORT_LIMITS = Object.freeze({headersTimeoutMs:10_000,requestTimeoutMs:15_000,keepAliveTimeoutMs:5_000,maxRequestsPerSocket:100,maxHeadersCount:httpAdmission.DEFAULT_LIMITS.maxHeadersCount,maxHeaderBytes:httpAdmission.DEFAULT_LIMITS.maxHeaderBytes,bodyIdleTimeoutMs:5_000,maxBodyBytes:1_000_000});
const REQUEST_TARGET_MAX_BYTES=httpAdmission.DEFAULT_LIMITS.maxRequestTargetBytes;
function timingSafeSecretMatch(supplied,expected){ supplied=String(supplied||''); expected=String(expected||''); return supplied.length===expected.length && supplied.length>0 && crypto.timingSafeEqual(Buffer.from(supplied),Buffer.from(expected)); }

fs.mkdirSync(DATA_DIR, { recursive: true });

const defaultState = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'seed-state.json'), 'utf8'));

function loadState() {
  return stateStore.loadState({file:STATE_FILE,defaults:defaultState,backupDir:STATE_BACKUP_DIR}).state;
}
function saveState(state) {
  return stateStore.saveState({file:STATE_FILE,state,defaults:defaultState,backupDir:STATE_BACKUP_DIR});
}
function audit(state, actor, action, result='RECORDED', policy='LIP-CONSTITUTION 1.0.0') {
  const at=new Date().toISOString();
  const id=crypto.randomUUID();
  state.audit.unshift({ id, at, actor, action, result, policy });
  state.audit = state.audit.slice(0, 1000);
  state.auditChain = auditLedger.compact(auditLedger.append(Array.isArray(state.auditChain)?state.auditChain:[], {
    id, at, actorId:actor, policyVersion:policy, action, result
  }),5000);
}
function securityHeaders({api=false}={}) {
  return {
    ...(api?{'Cache-Control':'no-store'}:{}),
    'X-Content-Type-Options':'nosniff',
    'X-Frame-Options':'DENY',
    'Referrer-Policy':'no-referrer',
    'Cross-Origin-Opener-Policy':'same-origin',
    'Cross-Origin-Resource-Policy':'same-origin',
    'Permissions-Policy':'camera=(), microphone=(), geolocation=(), payment=(), usb=()',
    'Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"
  };
}
function digestJson(value){ return crypto.createHash('sha256').update(JSON.stringify(value)).digest('hex'); }
function json(res, code, body, headers={}) {
  if(res._lipIdempotencyKey) IDEMPOTENCY_STORE.complete({key:res._lipIdempotencyKey,status:code,body});
  const serialized=JSON.stringify(body);
  res.writeHead(code, { 'Content-Type':'application/json; charset=utf-8','Content-Length':String(Buffer.byteLength(serialized)),'X-Request-ID':res._lipRequestId||crypto.randomUUID(), ...securityHeaders({api:true}), ...headers });
  res.end(serialized);
}
function parseCookies(req){
  const out={};
  for(const part of String(req.headers.cookie||'').split(';')){const i=part.indexOf('=');if(i>0)out[part.slice(0,i).trim()]=part.slice(i+1).trim();}
  return out;
}
function sessionCookieBoundary(req){
  const raw=String(req.headers.cookie||'');if(Buffer.byteLength(raw)>4096)return{allowed:false,status:400,error:'COOKIE_HEADER_TOO_LARGE'};
  if(!raw)return{allowed:true,cookies:{}};
  const parts=raw.split(';');if(parts.length>50)return{allowed:false,status:400,error:'COOKIE_COUNT_LIMIT_EXCEEDED'};
  const cookies={},seen=new Set();
  for(const rawPart of parts){const part=rawPart.trim(),i=part.indexOf('=');if(i<=0)return{allowed:false,status:400,error:'MALFORMED_COOKIE'};const name=part.slice(0,i).trim(),value=part.slice(i+1).trim();if(!/^[!#$%&'*+\-.^_`|~0-9A-Za-z]+$/.test(name)||!/^[\x21-\x3A\x3C-\x7E]*$/.test(value))return{allowed:false,status:400,error:'MALFORMED_COOKIE'};if(seen.has(name))return{allowed:false,status:400,error:name===LOCAL_SESSION_COOKIE?'DUPLICATE_LOCAL_SESSION_COOKIE':'DUPLICATE_COOKIE_NAME'};seen.add(name);cookies[name]=value;}
  if(Object.hasOwn(cookies,LOCAL_SESSION_COOKIE)&&!/^[a-f0-9]{64}$/.test(cookies[LOCAL_SESSION_COOKIE]))return{allowed:false,status:401,error:'INVALID_LOCAL_SESSION_TOKEN'};
  return{allowed:true,cookies};
}
let RELEASE_REPLAY_SCOPE=null;
function releaseReplayScope(principalClass){
  if(!RELEASE_REPLAY_SCOPE){
    try{const manifest=JSON.parse(fs.readFileSync(path.join(DATA_DIR,'release-manifest.json'),'utf8'));const digest=String(manifest.releaseDigest||'');RELEASE_REPLAY_SCOPE=/^[a-f0-9]{64}$/.test(digest)?digest:'UNSIGNED-RELEASE';}
    catch(_){RELEASE_REPLAY_SCOPE='UNSIGNED-RELEASE';}
  }
  return `LOCAL-${principalClass}-${RELEASE_REPLAY_SCOPE}`;
}
function requestPrincipal(req){
  const cookies=parseCookies(req);
  if(timingSafeSecretMatch(cookies[LOCAL_SESSION_COOKIE],LOCAL_SESSION_SECRET)){
    return {id:`LOCAL-SESSION-${crypto.createHash('sha256').update(LOCAL_SESSION_SECRET).digest('hex').slice(0,12)}`,replayScope:releaseReplayScope('BROWSER'),role:'APPROVER',principalType:'EPHEMERAL_BROWSER_SESSION',persistentIdentity:false};
  }
  if(timingSafeSecretMatch(req.headers['x-lip-tooling-token'],LOCAL_TOOLING_SECRET)){
    return {id:`LOCAL-TOOLING-${crypto.createHash('sha256').update(LOCAL_TOOLING_SECRET).digest('hex').slice(0,12)}`,replayScope:releaseReplayScope('TOOLING'),role:'APPROVER',principalType:'EPHEMERAL_LOCAL_TOOLING',persistentIdentity:false};
  }
  if(IS_TEST_PROCESS) return {id:'TEST-TOOLING',replayScope:'LOCAL-TEST-TOOLING',role:'APPROVER',principalType:'EPHEMERAL_TEST_TOOLING',persistentIdentity:false};
  return {id:'UNAUTHENTICATED',replayScope:'UNAUTHENTICATED',role:'NONE',principalType:'UNAUTHENTICATED',persistentIdentity:false};
}
function validateLocalHostHeader(req){
  const activePort=Number(req.socket?.localPort)||PORT;
  return httpAdmission.validateHostAuthority(req.headers.host,{expectedPort:activePort});
}
function requestMetadataBoundary(req){
  const target=httpAdmission.validateRequestTarget(req.url);
  if(!target.allowed)return{...target,requestId:crypto.randomUUID()};
  req._lipRequestTarget=target;
  if((req.rawHeaders||[]).length/2>TRANSPORT_LIMITS.maxHeadersCount)return{allowed:false,status:431,error:'HEADER_COUNT_LIMIT_EXCEEDED',requestId:crypto.randomUUID()};
  const counts={};for(let i=0;i<(req.rawHeaders||[]).length;i+=2){const name=String(req.rawHeaders[i]||'').toLowerCase();counts[name]=(counts[name]||0)+1;}
  const requestId=String(req.headers['x-request-id']||'').trim()||crypto.randomUUID();
  for(const name of ['host','accept','expect','content-type','content-encoding','content-length','transfer-encoding','trailer','te','idempotency-key','idempotency-content-digest','origin','x-request-id','cookie','x-lip-tooling-token','sec-fetch-site','sec-fetch-mode','sec-fetch-dest','range','if-none-match'])if((counts[name]||0)>1)return{allowed:false,status:400,error:`DUPLICATE_${name.toUpperCase().replaceAll('-','_')}_HEADER`,requestId:crypto.randomUUID()};
  if(!/^[A-Za-z0-9._:-]{8,64}$/.test(requestId))return{allowed:false,status:400,error:'INVALID_REQUEST_ID',requestId:crypto.randomUUID()};
  if(req.headers.expect!==undefined)return{allowed:false,status:417,error:'EXPECTATION_NOT_SUPPORTED',requestId};
  const encoding=String(req.headers['content-encoding']||'').trim().toLowerCase();if(encoding&&encoding!=='identity')return{allowed:false,status:415,error:'CONTENT_ENCODING_NOT_SUPPORTED'};
  const transfer=String(req.headers['transfer-encoding']||'').trim().toLowerCase();if(transfer&&transfer!=='chunked')return{allowed:false,status:400,error:'TRANSFER_ENCODING_NOT_SUPPORTED'};
  if(req.headers.trailer!==undefined||req.headers.te!==undefined)return{allowed:false,status:400,error:'HTTP_TRAILERS_NOT_SUPPORTED',requestId};
  if(transfer&&req.headers['content-length']!==undefined)return{allowed:false,status:400,error:'AMBIGUOUS_MESSAGE_FRAMING'};
  const contentLength=httpAdmission.validateContentLength(req.headers['content-length'],{maxBodyBytes:TRANSPORT_LIMITS.maxBodyBytes});if(!contentLength.allowed)return{...contentLength,requestId};
  const contentType=httpAdmission.validateJsonContentType(req.headers['content-type']);if(!contentType.allowed)return{...contentType,requestId};
  const method=String(req.method||'GET').toUpperCase();
  if(['GET','HEAD'].includes(method)&&(transfer||Number(contentLength.value||0)>0))return{allowed:false,status:400,error:'REQUEST_BODY_NOT_ALLOWED_FOR_METHOD',requestId};
  return{allowed:true,requestId};
}
function localMutationAuth({browserContext=false,sessionValid=false,toolingValid=false,testProcess=false}={}){
  if(sessionValid&&toolingValid)return{allowed:false,status:400,error:'AMBIGUOUS_LOCAL_CREDENTIALS'};
  if(browserContext) return sessionValid?{allowed:true}:{allowed:false,status:401,error:'LOCAL_SESSION_REQUIRED'};
  if(testProcess) return {allowed:true};
  return toolingValid?{allowed:true}:{allowed:false,status:401,error:'LOCAL_TOOLING_AUTH_REQUIRED'};
}
async function apiRequestBoundary(req) {
  const method=String(req.method||'GET').toUpperCase();
  if(!['GET','POST'].includes(method)) return {allowed:false,status:405,error:'METHOD_NOT_ALLOWED'};
  const accept=httpAdmission.validateAcceptHeader(req.headers.accept);if(!accept.allowed)return accept;
  const fetchSite=String(req.headers['sec-fetch-site']||'').toLowerCase();
  if(fetchSite==='cross-site')return{allowed:false,status:403,error:'CROSS_SITE_REQUEST_DENIED'};
  if(fetchSite&&!['same-origin','none'].includes(fetchSite)) return {allowed:false,status:403,error:'FETCH_SITE_NOT_ALLOWED'};
  const origin=req.headers.origin;
  if(origin){
    let parsed;
    try{parsed=new URL(origin);}catch(_){return {allowed:false,status:403,error:'INVALID_ORIGIN'};}
    const host=String(req.headers.host||'');
    if(parsed.host!==host || parsed.protocol!=='http:') return {allowed:false,status:403,error:'ORIGIN_NOT_ALLOWED'};
  }
  const browserContext=Boolean(origin||fetchSite);
  const principal=requestPrincipal(req);
  if(method==='POST'){
    const cookieBoundary=sessionCookieBoundary(req);if(!cookieBoundary.allowed)return cookieBoundary;
    if(browserContext&&!origin)return{allowed:false,status:403,error:'BROWSER_MUTATION_ORIGIN_REQUIRED'};
    const fetchMode=String(req.headers['sec-fetch-mode']||'').toLowerCase();if(fetchMode&&!['cors','same-origin'].includes(fetchMode))return{allowed:false,status:403,error:'FETCH_MODE_NOT_ALLOWED'};
    const fetchDest=String(req.headers['sec-fetch-dest']||'').toLowerCase();if(fetchDest&&fetchDest!=='empty')return{allowed:false,status:403,error:'FETCH_DESTINATION_NOT_ALLOWED'};
    const cookies=cookieBoundary.cookies;
    const auth=localMutationAuth({browserContext,sessionValid:timingSafeSecretMatch(cookies[LOCAL_SESSION_COOKIE],LOCAL_SESSION_SECRET),toolingValid:timingSafeSecretMatch(req.headers['x-lip-tooling-token'],LOCAL_TOOLING_SECRET),testProcess:IS_TEST_PROCESS});
    if(!auth.allowed) return auth;
    await bodyJson(req);
    const suppliedDigest=String(req.headers['idempotency-content-digest']||'').toLowerCase();
    if(req.headers['idempotency-key'] && suppliedDigest!==req._lipBodyDigest) return {allowed:false,status:409,error:'IDEMPOTENCY_CONTENT_DIGEST_MISMATCH'};
    const idempotency=IDEMPOTENCY_STORE.preflight({key:req.headers['idempotency-key'],method,path:req._lipRequestTarget?.canonicalTarget||req.url,payloadDigest:req._lipBodyDigest,scope:(principal.replayScope||principal.id)});
    if(idempotency.decision==='DENY') return {allowed:false,status:idempotency.status,error:idempotency.error};
    if(idempotency.decision==='REPLAY') return {allowed:true,replay:idempotency};
    if(browserContext && !IS_TEST_PROCESS && idempotency.decision!=='PROCEED') return {allowed:false,status:400,error:'IDEMPOTENCY_KEY_REQUIRED'};
    if(idempotency.decision==='PROCEED') req._lipIdempotencyKey=idempotency.key;
  }
  const remote=String(req.socket?.remoteAddress||'local');
  const budget=REQUEST_BUDGET.consume({key:`${principal.id}:${remote}`,kind:method==='POST'?'mutation':'read'});
  if(!budget.allowed) return {allowed:false,status:429,error:'REQUEST_BUDGET_EXCEEDED',budget};
  return {allowed:true,budget};
}
class RequestBodyError extends Error { constructor(code,status){ super(code); this.code=code; this.status=status; } }
function bodyJson(req) {
  if(req._lipBodyParsed===true) return Promise.resolve(req._lipParsedBody);
  return new Promise((resolve, reject) => {
    const typeBoundary=httpAdmission.validateJsonContentType(req.headers['content-type']);
    if(!typeBoundary.allowed) return reject(new RequestBodyError(typeBoundary.error,typeBoundary.status));
    const contentType=typeBoundary.present?String(req.headers['content-type']||''):'';
    const lengthBoundary=httpAdmission.validateContentLength(req.headers['content-length'],{maxBodyBytes:TRANSPORT_LIMITS.maxBodyBytes});
    if(!lengthBoundary.allowed) return reject(new RequestBodyError(lengthBoundary.error,lengthBoundary.status));
    const chunks=[];let bodyBytes=0;let settled=false;let timer=null;
    const finish=(fn,value)=>{if(settled)return;settled=true;if(timer)clearTimeout(timer);fn(value);};
    const armIdleTimer=()=>{if(timer)clearTimeout(timer);timer=setTimeout(()=>finish(reject,new RequestBodyError('REQUEST_BODY_TIMEOUT',408)),TRANSPORT_LIMITS.bodyIdleTimeoutMs);timer.unref?.();};
    armIdleTimer();
    req.on('data', c => {
      if(settled) return;
      const chunk=Buffer.isBuffer(c)?c:Buffer.from(c);
      bodyBytes+=chunk.length;
      if(bodyBytes>TRANSPORT_LIMITS.maxBodyBytes)return finish(reject,new RequestBodyError('PAYLOAD_TOO_LARGE',413));
      chunks.push(chunk);armIdleTimer();
    });
    req.on('end', () => {
      if(settled) return;
      if(lengthBoundary.present&&bodyBytes!==lengthBoundary.value)return finish(reject,new RequestBodyError('CONTENT_LENGTH_MISMATCH',400));
      const raw=Buffer.concat(chunks,bodyBytes);
      if(raw.length&&!contentType)return finish(reject,new RequestBodyError('JSON_CONTENT_TYPE_REQUIRED',415));
      let body='';
      try{body=new TextDecoder('utf-8',{fatal:true}).decode(raw);}catch(_){return finish(reject,new RequestBodyError('INVALID_UTF8_JSON',400));}
      try { const parsed=body ? JSON.parse(body) : {};const structure=httpAdmission.validateJsonStructure(parsed);if(!structure.allowed)return finish(reject,new RequestBodyError(structure.error,structure.status));req._lipBodyParsed=true;req._lipParsedBody=parsed;req._lipRawBodyBytes=raw.length;req._lipBodyDigest=crypto.createHash('sha256').update(raw).digest('hex');finish(resolve,parsed); }
      catch(e) { if(e instanceof RequestBodyError)return finish(reject,e);finish(reject,new RequestBodyError('INVALID_JSON',400)); }
    });
    req.on('aborted',()=>finish(reject,new RequestBodyError('REQUEST_ABORTED',400)));
    req.on('error',e=>finish(reject,e));
  });
}
const PUBLIC_ASSETS=Object.freeze({'/index.html':{type:'text/html; charset=utf-8',maxBytes:64*1024},'/app.js':{type:'application/javascript; charset=utf-8',maxBytes:512*1024},'/styles.css':{type:'text/css; charset=utf-8',maxBytes:256*1024}});
function staticFile(req,res, pathname) {
  const requested = pathname === '/' ? '/index.html' : pathname;
  if(!Object.hasOwn(PUBLIC_ASSETS,requested)) return false;
  if(!['GET','HEAD'].includes(String(req.method||'GET').toUpperCase())){res.writeHead(405,{'Content-Type':'text/plain; charset=utf-8','Cache-Control':'no-store','Allow':'GET, HEAD','X-Request-ID':res._lipRequestId,...securityHeaders()});res.end('Method not allowed');return true;}
  const fetchSite=String(req.headers['sec-fetch-site']||'').toLowerCase();if(fetchSite&&!['same-origin','none'].includes(fetchSite)){res.writeHead(403,{'Content-Type':'text/plain; charset=utf-8','Cache-Control':'no-store','X-Request-ID':res._lipRequestId,...securityHeaders()});res.end('Forbidden');return true;}
  if(req.headers.origin){let origin;try{origin=new URL(req.headers.origin);}catch(_){origin=null;}if(!origin||origin.protocol!=='http:'||origin.host!==String(req.headers.host||'')){res.writeHead(403,{'Content-Type':'text/plain; charset=utf-8','Cache-Control':'no-store','X-Request-ID':res._lipRequestId,...securityHeaders()});res.end('Forbidden');return true;}}
  if(req.headers.range){res.writeHead(416,{'Content-Type':'text/plain; charset=utf-8','Cache-Control':'no-store','Accept-Ranges':'none','X-Request-ID':res._lipRequestId,...securityHeaders()});res.end('Range not supported');return true;}
  let asset;try{asset=readStaticAsset({root:ROOT,relativePath:`.${requested}`,maxBytes:PUBLIC_ASSETS[requested].maxBytes});}catch(_){return false;}
  const common={'Content-Type':PUBLIC_ASSETS[requested].type,'Cache-Control':'no-store','ETag':asset.etag,'Accept-Ranges':'none','X-Request-ID':res._lipRequestId,...securityHeaders()};
  if(req.headers['if-none-match']===asset.etag){res.writeHead(304,common);res.end();return true;}
  const sessionHeader=requested==='/index.html'&&req.method==='GET'?{'Set-Cookie':`${LOCAL_SESSION_COOKIE}=${LOCAL_SESSION_SECRET}; Path=/; HttpOnly; SameSite=Strict; Priority=High`}:{};
  res.writeHead(200,{...common,'Content-Length':String(asset.size),...sessionHeader});
  if(req.method==='HEAD'){res.end();return true;}res.end(asset.bytes);return true;
}

const server = http.createServer({maxHeaderSize:TRANSPORT_LIMITS.maxHeaderBytes},async (req,res) => {
  const metadataBoundary=requestMetadataBoundary(req);
  res._lipRequestId=metadataBoundary.requestId||crypto.randomUUID();
  if(!metadataBoundary.allowed)return json(res,metadataBoundary.status,{error:metadataBoundary.error});
  const hostBoundary=validateLocalHostHeader(req);
  if(!hostBoundary.allowed) return json(res,hostBoundary.status,{error:hostBoundary.error});
  const target=req._lipRequestTarget||httpAdmission.validateRequestTarget(req.url);
  if(!target.allowed) return json(res,target.status,{error:target.error});
  const p = target.pathname;
  const query = target.query||{};
  try {
    if(p.startsWith('/api/')) { const boundary=await apiRequestBoundary(req); if(!boundary.allowed) return json(res,boundary.status,{error:boundary.error,budget:boundary.budget||null},boundary.budget?{'Retry-After':String(boundary.budget.retryAfterSeconds)}:{}); if(boundary.replay)return json(res,boundary.replay.status,boundary.replay.body,{'Idempotency-Replayed':'true'}); if(req._lipIdempotencyKey)res._lipIdempotencyKey=req._lipIdempotencyKey; }
    if (p === '/api/security/request-budget/posture' && req.method === 'GET') return json(res,200,REQUEST_BUDGET.posture());
    if (p === '/api/security/transport/posture' && req.method === 'GET') return json(res,200,{enabled:true,scope:'LOCAL_RUNTIME_TRANSPORT',failMode:'FAIL_CLOSED',limits:{...TRANSPORT_LIMITS},externalDependency:false});
    if (p === '/api/security/http-admission/posture' && req.method === 'GET') return json(res,200,httpAdmission.posture());
    if (p === '/api/security/idempotency/posture' && req.method === 'GET') return json(res,200,IDEMPOTENCY_STORE.posture());
    if (p === '/api/simulation/snapshot' && req.method === 'GET') return json(res,200,simulation.snapshot({seed:query.seed||'lip-baseline-2026',scenario:query.scenario||'BALANCED',days:query.days||30}));
    if (p === '/api/simulation/compare' && req.method === 'GET') return json(res,200,{source:'SYNTHETIC_MARKETPLACE_SIMULATOR',items:simulation.compare({seed:query.seed||'lip-baseline-2026',days:query.days||30})});
    if (p === '/api/simulation/fixtures' && req.method === 'GET') return json(res,200,simulation.fixtures({seed:query.seed||'lip-baseline-2026'}));
    if (p === '/api/dashboard/control-metrics' && req.method === 'GET') { const sim=simulation.snapshot({seed:'lip-baseline-2026',scenario:'BALANCED',days:30}); const fixtures=simulation.fixtures({seed:'lip-baseline-2026'}); return json(res,200,controlMetrics.derive({state:loadState(),simulation:sim,fixtures})); }
    if (p === '/api/security/context/posture' && req.method === 'GET') return json(res,200,{policy:'CONTEXT_SECURITY_V1',admissionMode:'FAIL_CLOSED',instructionSources:[...contextSecurity.INSTRUCTION_SOURCES],dataOnlySources:[...contextSecurity.DATA_ONLY_SOURCES],quarantineLabels:[...contextSecurity.QUARANTINE_LABELS],trustDomains:Object.keys(contextSecurity.TRUST_RANK),antiLaundering:true,memoryAdmission:'EVIDENCE_BACKED'});
    if (p === '/api/security/integrity-scope' && req.method === 'GET') return json(res,200,{model:'LOCAL_HASH_CHAIN_AND_CHECKSUMS',detects:['accidental-corruption','unsynchronised-local-modification','release-artifact-drift'],doesNotGuarantee:['protection-from-privileged-local-filesystem-attacker','external-non-repudiation','third-party-time-anchoring'],externalAnchoring:{enabled:false,status:'NOT_CONNECTED',requiresSeparateAuthorization:true},claim:'TAMPER_EVIDENT_LOCAL_SCOPE_NOT_TAMPER_PROOF'});
    if (p === '/api/security/context/assemble' && req.method === 'POST') return json(res,200,contextSecurity.assembleContext(await bodyJson(req)));
    if (p === '/api/security/context/memory-admission' && req.method === 'POST') return json(res,200,contextSecurity.memoryAdmission(await bodyJson(req)));
    if (p === '/api/security/context/handoff' && req.method === 'POST') return json(res,200,contextSecurity.handoffContext(await bodyJson(req)));
    if (p === '/api/security/agent-skills/posture' && req.method === 'GET') return json(res,200,{installedSkills:0,admittedSkills:0,quarantinedSkills:0,externalInstallEnabled:false,admissionMode:'FAIL_CLOSED',sourceMaturity:'PUBLIC_REVIEW_DRAFT',risks:Object.entries(agentSkillSecurity.AST10).map(([id,name])=>({id,name}))});
    if (p === '/api/health' && req.method === 'GET') {
      const storage=stateStore.storageHealth({file:STATE_FILE,defaults:defaultState,backupDir:STATE_BACKUP_DIR});
      let releaseDigest=null; try{releaseDigest=JSON.parse(fs.readFileSync(path.join(DATA_DIR,'release-manifest.json'),'utf8')).releaseDigest||null;}catch(_){}
      let runtimeState=null; try{runtimeState=loadState();}catch(_){}
      const ok=storage.healthy===true && runtimeState!==null;
      const policy=policyBundle.getPolicyBundle(); const connectors=connectorRegistry.getConnectorRegistry(); const standards=JSON.parse(fs.readFileSync(path.join(DATA_DIR,'standards-registry.json'),'utf8')); const evidenceIndex=JSON.parse(fs.readFileSync(path.join(DATA_DIR,'capability-evidence-index.json'),'utf8')); const registry=JSON.parse(fs.readFileSync(REGISTRY_FILE,'utf8')); const evidenceCoverage={total:registry.length,direct:registry.filter(x=>x.evidenceScope==='DIRECT').length,moduleBundle:registry.filter(x=>x.evidenceScope==='MODULE_BUNDLE').length,indexed:Object.keys(evidenceIndex.features||{}).length};
      return json(res,ok?200:503,{ok,environment:'standalone',time:new Date().toISOString(),releaseDigest,stateRevision:runtimeState?.revision??null,schemaVersion:runtimeState?.schemaVersion??null,mode:runtimeState?.mode??null,killSwitch:runtimeState?.killSwitch??null,storage:{healthy:storage.healthy,backupCount:storage.backupCount,primary:storage.primary},externalLiveConnections:connectors.liveConnectionsEnabled===true,connectedMarketplace:null,apiContractDigest:apiContracts.contractDocument(fs.readFileSync(__filename,'utf8'),{version:'1'}).digest,runtimeConfigDigest:digestJson(RUNTIME_CONFIG),policyBundleDigest:digestJson(policy),connectorRegistryDigest:digestJson(connectors),standardsRegistryDigest:digestJson(standards),capabilityEvidenceIndexDigest:digestJson(evidenceIndex),capabilityEvidenceCoverage:evidenceCoverage});
    }
    if (p === '/api/redteam/run' && req.method === 'POST') return json(res,200,runAdversarialSuite());
    if (p === '/api/events/validate' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,eventFabric.validateEvent(b.event||{},b.registry||{})); }
    if (p === '/api/events/quality' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,eventFabric.eventQuality(Array.isArray(b.events)?b.events:[])); }
    if (p === '/api/events/deduplicate' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,eventFabric.deduplicate(Array.isArray(b.events)?b.events:[])); }
    if (p === '/api/experiments/assign' && req.method === 'POST') return json(res,200,experiments.assignVariant(await bodyJson(req)));
    if (p === '/api/experiments/guardrails' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,experiments.guardrailStatus(b.metrics||[],b.rules||[])); }
    if (p === '/api/experiments/collision' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,experiments.collisionCheck(b.candidate||{},b.active||[])); }
    if (p === '/api/experiments/rollout-decision' && req.method === 'POST') return json(res,200,experiments.rolloutDecision(await bodyJson(req)));
    if (p === '/api/memory/admission' && req.method === 'POST') { const b=await bodyJson(req); const m=memory.createMemory(b); return json(res,200,{memory:m,admission:memory.admission(m)}); }
    if (p === '/api/memory/freshness' && req.method === 'POST') return json(res,200,memory.freshness(await bodyJson(req)));
    if (p === '/api/evals/release' && req.method === 'POST') return json(res,200,evals.evaluateRelease(await bodyJson(req)));
    if (p === '/api/evals/calibration' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,evals.calibrationScore(b.predictions||[])); }
    if (p === '/api/observability/genai-span' && req.method === 'POST') return json(res,200,observability.genAiSpan(await bodyJson(req)));
    if (p === '/api/observability/redact' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,observability.redact(b.payload||{},b.allowContent===true)); }
    if (p === '/api/observability/record' && req.method === 'POST') {
      const b=await bodyJson(req);
      const kind=String(b.kind||'event').slice(0,80);
      const traceId=b.traceId?String(b.traceId).slice(0,128):crypto.randomUUID();
      const correlationId=b.correlationId?String(b.correlationId).slice(0,128):traceId;
      const entry={id:crypto.randomUUID(),at:new Date().toISOString(),kind,traceId,correlationId,payload:observability.redact(b.payload||{},false)};
      const st=loadState(); st.telemetry.unshift(entry); st.telemetry=st.telemetry.slice(0,2000); saveState(st);
      return json(res,201,entry);
    }
    if (p === '/api/observability/recent' && req.method === 'GET') {
      const limit=query.limit||50;
      const st=loadState(); return json(res,200,{items:(st.telemetry||[]).slice(0,limit),revision:st.revision});
    }
    if (p === '/api/finops/budget' && req.method === 'POST') return json(res,200,finops.budgetDecision(await bodyJson(req)));
    if (p === '/api/finops/route-model' && req.method === 'POST') return json(res,200,finops.routeModel(await bodyJson(req)));
    if (p === '/api/privacy/use' && req.method === 'POST') return json(res,200,privacy.canUse(await bodyJson(req)));
    if (p === '/api/privacy/retention' && req.method === 'POST') return json(res,200,privacy.retentionDecision(await bodyJson(req)));
    if (p === '/api/reliability/fallback' && req.method === 'POST') return json(res,200,reliability.fallbackPlan(await bodyJson(req)));
    if (p === '/api/reliability/retry' && req.method === 'POST') return json(res,200,reliability.retryDecision(await bodyJson(req)));
    if (p === '/api/reliability/load-shedding' && req.method === 'POST') return json(res,200,reliability.loadShedding(await bodyJson(req)));
    if (p === '/api/security/llm-top10/posture' && req.method === 'GET') return json(res,200,{reference:'OWASP GenAI LLM Top 10 2026',risks:llmSecurity.posture()});
    if (p === '/api/security/llm-top10/assess' && req.method === 'POST') return json(res,200,llmSecurity.assess(await bodyJson(req)));
    if (p === '/api/security/agent-action' && req.method === 'POST') return json(res,200,agentSecurity.evaluateAgentAction(await bodyJson(req)));
    if (p === '/api/security/handoff' && req.method === 'POST') return json(res,200,agentSecurity.verifyHandoff(await bodyJson(req)));
    if (p === '/api/security/component-admission' && req.method === 'POST') return json(res,200,agentSecurity.componentAdmission(await bodyJson(req)));
    if (p === '/api/protocols/ucp/negotiate' && req.method === 'POST') return json(res,200,protocol.negotiateUcp(await bodyJson(req)));
    if (p === '/api/protocols/ucp/schema-plan' && req.method === 'POST') return json(res,200,protocol.schemaResolutionPlan(await bodyJson(req)));
    if (p === '/api/protocols/ucp/response-capabilities' && req.method === 'POST') return json(res,200,protocol.responseCapabilitySelection(await bodyJson(req)));
    if (p === '/api/protocols/agent-commerce/validate' && req.method === 'POST') return json(res,200,protocol.validateAgentCommerceRequest(await bodyJson(req)));
    if (p === '/api/transparency/assess' && req.method === 'POST') return json(res,200,transparency.assessTransparency(await bodyJson(req)));
    if (p === '/api/supply-chain/sbom/validate' && req.method === 'POST') return json(res,200,supplyChain.validateSbomComponent(await bodyJson(req)));
    if (p === '/api/supply-chain/provenance/verify' && req.method === 'POST') return json(res,200,supplyChain.verifyProvenance(await bodyJson(req)));
    if (p === '/api/supply-chain/admission' && req.method === 'POST') return json(res,200,supplyChain.admission(await bodyJson(req)));
    if (p === '/api/connectors/security/assess' && req.method === 'POST') return json(res,200,connectorSecurity.assessConnector(await bodyJson(req)));
    if (p === '/api/connectors/mcp/security/assess' && req.method === 'POST') return json(res,200,connectorSecurity.assessMcpServer(await bodyJson(req)));
    if (p === '/api/connectors/tool-call/validate' && req.method === 'POST') return json(res,200,connectorSecurity.validateToolCall(await bodyJson(req)));



    if (p === '/api/seller/funnel' && req.method === 'POST') return json(res,200,sellerIntel.activationFunnel(await bodyJson(req)));
    if (p === '/api/seller/bottlenecks' && req.method === 'POST') return json(res,200,sellerIntel.bottlenecks(await bodyJson(req)));
    if (p === '/api/seller/health' && req.method === 'POST') return json(res,200,sellerIntel.sellerHealth(await bodyJson(req)));
    if (p === '/api/seller/coach' && req.method === 'POST') return json(res,200,sellerIntel.coach(await bodyJson(req)));
    if (p === '/api/seller/churn' && req.method === 'POST') return json(res,200,sellerIntel.churnRisk(await bodyJson(req)));
    if (p === '/api/buyer/intent' && req.method === 'POST') return json(res,200,buyerIntel.inferIntent(await bodyJson(req)));
    if (p === '/api/buyer/project' && req.method === 'POST') return json(res,200,buyerIntel.projectPlan(await bodyJson(req)));
    if (p === '/api/buyer/bundle' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,buyerIntel.buildBundle(Array.isArray(b.candidates)?b.candidates:[],Array.isArray(b.requirements)?b.requirements:[])); }
    if (p === '/api/buyer/preferences/admit' && req.method === 'POST') return json(res,200,buyerIntel.preferenceAdmission(await bodyJson(req)));
    if (p === '/api/buyer/return-prevention' && req.method === 'POST') return json(res,200,buyerIntel.returnPrevention(await bodyJson(req)));
    if (p === '/api/strategy/growth-quality' && req.method === 'POST') return json(res,200,strategic.growthQuality(await bodyJson(req)));
    if (p === '/api/strategy/resilience' && req.method === 'POST') return json(res,200,strategic.resilience(await bodyJson(req)));
    if (p === '/api/strategy/simulate' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,strategic.simulate(b.base||{},b.scenario||{})); }
    if (p === '/api/strategy/digital-twin' && req.method === 'POST') return json(res,200,strategic.digitalTwinSnapshot(await bodyJson(req)));
    if (p === '/api/strategy/scenarios' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,strategic.compareScenarios(b.base||{},Array.isArray(b.scenarios)?b.scenarios:[])); }
    if (p === '/api/support/classify' && req.method === 'POST') return json(res,200,supportEngine.classify(await bodyJson(req)));
    if (p === '/api/support/cluster' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,supportEngine.cluster(Array.isArray(b.tickets)?b.tickets:[])); }
    if (p === '/api/support/draft' && req.method === 'POST') return json(res,200,supportEngine.groundedDraft(await bodyJson(req)));
    if (p === '/api/support/complaint-to-code' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,supportEngine.complaintToCode(Array.isArray(b.clusters)?b.clusters:[])); }
    if (p === '/api/safety/pre-publication' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,productSafety.prePublication(b.product||{},b.policy||{})); }
    if (p === '/api/safety/recall-match' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,productSafety.recallMatch(b.product||{},Array.isArray(b.recalls)?b.recalls:[])); }
    if (p === '/api/safety/batch-recall-graph' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,productSafety.batchRecallGraph(Array.isArray(b.records)?b.records:[],b.recall||{})); }
    if (p === '/api/demand/zero-results' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,demandEngine.zeroResults(Array.isArray(b.searches)?b.searches:[])); }
    if (p === '/api/demand/supply-gaps' && req.method === 'POST') return json(res,200,demandEngine.supplyGaps(await bodyJson(req)));
    if (p === '/api/demand/spikes' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,demandEngine.spikes(Array.isArray(b.series)?b.series:[],Number(b.threshold||2))); }
    if (p === '/api/demand/liquidity' && req.method === 'POST') return json(res,200,demandEngine.liquidity(await bodyJson(req)));
    if (p === '/api/demand/geographic' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,demandEngine.geographic(Array.isArray(b.searches)?b.searches:[])); }
    if (p === '/api/audit/ledger/verify' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,auditLedger.verify(Array.isArray(b.ledger)?b.ledger:[])); }
    if (p === '/api/audit/ledger/append' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,{ledger:auditLedger.append(Array.isArray(b.ledger)?b.ledger:[],b.event||{})}); }
    if (p === '/api/governance/entry/validate' && req.method === 'POST') return json(res,200,governanceEngine.validateRegistryEntry(await bodyJson(req)));
    if (p === '/api/governance/debt' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,governanceEngine.governanceDebt(Array.isArray(b.entries)?b.entries:[])); }
    if (p === '/api/governance/autonomy/change' && req.method === 'POST') return json(res,200,governanceEngine.autonomyChange(await bodyJson(req)));
    if (p === '/api/integrations/connector/validate' && req.method === 'POST') return json(res,200,integrationEngine.validateConnector(await bodyJson(req)));
    if (p === '/api/integrations/connector/health' && req.method === 'POST') return json(res,200,integrationEngine.health(await bodyJson(req)));
    if (p === '/api/identity/credential/validate' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,identityEngine.validateCredential(b.credential||{},b.context||{})); }
    if (p === '/api/identity/authorize' && req.method === 'POST') return json(res,200,identityEngine.authorizeIdentity(await bodyJson(req)));
    if (p === '/api/agentic/capabilities/discover' && req.method === 'POST') return json(res,200,agenticCommerce.discoverCapabilities(await bodyJson(req)));
    if (p === '/api/agentic/action/authorize' && req.method === 'POST') return json(res,200,agenticCommerce.authorizeAgenticAction(await bodyJson(req)));
    if (p === '/api/agentic/ucp/negotiate' && req.method === 'POST') return json(res,200,agenticCommerce.ucpNegotiation(await bodyJson(req)));
    if (p === '/api/financial/firewall/assess' && req.method === 'POST') return json(res,200,financialFirewall.assessFinancialAction(await bodyJson(req)));
    if (p === '/api/financial/intent/build' && req.method === 'POST') return json(res,200,financialFirewall.buildFinancialIntent(await bodyJson(req)));
    if (p === '/api/engineering/change/plan' && req.method === 'POST') return json(res,200,engineeringIntel.planChange(await bodyJson(req)));
    if (p === '/api/engineering/test-integrity' && req.method === 'POST') return json(res,200,engineeringIntel.evaluateTestIntegrity(await bodyJson(req)));
    if (p === '/api/engineering/deployment-gate' && req.method === 'POST') return json(res,200,engineeringIntel.deploymentGate(await bodyJson(req)));
    if (p === '/api/catalog/product/validate' && req.method === 'POST') return json(res,200,catalog.canonicalProduct(await bodyJson(req)));
    if (p === '/api/catalog/offer/validate' && req.method === 'POST') return json(res,200,catalog.sellerOffer(await bodyJson(req)));
    if (p === '/api/catalog/identity/match' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,catalog.identityMatch(b.a||{},b.b||{})); }
    if (p === '/api/catalog/stock/revalidate' && req.method === 'POST') return json(res,200,catalog.preCheckoutStockCheck(await bodyJson(req)));
    if (p === '/api/search/rank' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,searchEngine.rank(b.query||'',Array.isArray(b.items)?b.items:[],b.options||{})); }
    if (p === '/api/recommendations/by-mode' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,recommendations.recommendByMode(b.mode,Array.isArray(b.candidates)?b.candidates:[],b.context||{})); }
    if (p === '/api/recommendations/rank' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,recommendations.recommend(Array.isArray(b.candidates)?b.candidates:[],b.context||{})); }
    if (p === '/api/recommendations/material-change' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,recommendations.materialChange(b.before||{},b.after||{})); }
    if (p === '/api/reviews/integrity/assess' && req.method === 'POST') return json(res,200,reviewIntegrity.assessReview(await bodyJson(req)));
    if (p === '/api/reviews/integrity/rating' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,reviewIntegrity.ratingIntegrity(Array.isArray(b.reviews)?b.reviews:[])); }
    if (p === '/api/standards' && req.method === 'GET') { const standards=JSON.parse(fs.readFileSync(path.join(DATA_DIR,'standards-registry.json'),'utf8')); return json(res,200,{items:standards,count:Array.isArray(standards)?standards.length:0}); }
    if (p === '/api/standards/posture' && req.method === 'GET') { const standards=JSON.parse(fs.readFileSync(path.join(DATA_DIR,'standards-registry.json'),'utf8')); const items=standards.map(entry=>({...entry,governance:standardsGovernance.classify(entry)})); return json(res,200,{items,count:items.length,bindingEligible:items.filter(x=>x.governance.bindingEligible).length,nonBinding:items.filter(x=>!x.governance.bindingEligible).length,unknown:items.filter(x=>x.governance.known===false).length}); }
    if (p === '/api/meta/contracts' && req.method === 'GET') { const source=fs.readFileSync(__filename,'utf8'); const doc=apiContracts.contractDocument(source,{version:'1'}); const uniqueness=apiContracts.validateUnique(doc.items); return json(res,uniqueness.valid?200:500,{...doc,uniqueness}); }
    if (p === '/api/guardian/readiness' && req.method === 'GET') { const systemManifest=JSON.parse(fs.readFileSync(path.join(DATA_DIR,'system-manifest.json'),'utf8')); const releaseManifest=JSON.parse(fs.readFileSync(path.join(DATA_DIR,'release-manifest.json'),'utf8')); const manifest={...systemManifest,releaseDigest:releaseManifest.releaseDigest}; const registry=JSON.parse(fs.readFileSync(REGISTRY_FILE,'utf8')); const standards=JSON.parse(fs.readFileSync(path.join(DATA_DIR,'standards-registry.json'),'utf8')); const threats=JSON.parse(fs.readFileSync(path.join(DATA_DIR,'threat-catalog.json'),'utf8')); const evidenceIndex=JSON.parse(fs.readFileSync(path.join(DATA_DIR,'capability-evidence-index.json'),'utf8')); const attestationPath=path.join(DATA_DIR,'test-attestation.json'); const attestation=fs.existsSync(attestationPath)?JSON.parse(fs.readFileSync(attestationPath,'utf8')):null; return json(res,200,guardian.releaseReadiness({manifest,registry,standards,threats,attestation,testSummary:{total:0,failed:0},policyBundle:policyBundle.getPolicyBundle(),connectorRegistry:connectorRegistry.getConnectorRegistry(),evidenceIndex})); }
    if (p === '/api/guardian/drift' && req.method === 'POST') { const manifest=JSON.parse(fs.readFileSync(path.join(DATA_DIR,'system-manifest.json'),'utf8')); return json(res,200,guardian.architectureDrift({manifest,runtime:await bodyJson(req)})); }
    if (p === '/api/security/agent-skill/admission' && req.method === 'POST') return json(res,200,agentSkillSecurity.assessSkill(await bodyJson(req)));
    if (p === '/api/security/agent-skill/drift' && req.method === 'POST') return json(res,200,agentSkillSecurity.runtimeDrift(await bodyJson(req)));
    if (p === '/api/standards/register/validate' && req.method === 'POST') return json(res,200,standardsGovernance.registryEntry(await bodyJson(req)));
    if (p === '/api/standards/policy-binding/check' && req.method === 'POST') return json(res,200,standardsGovernance.canBindPolicy(await bodyJson(req)));
    if (p === '/api/standards/adapter/version' && req.method === 'POST') return json(res,200,standardsGovernance.adapterVersionDecision(await bodyJson(req)));
    if (p === '/api/standards/compatibility' && req.method === 'POST') return json(res,200,standardsGovernance.compatibilityMatrix(await bodyJson(req)));
    if (p === '/api/standards/lifecycle' && req.method === 'POST') return json(res,200,standardsGovernance.lifecycleDecision(await bodyJson(req)));
    if (p === '/api/standards/gs1-digital-link/readiness' && req.method === 'POST') return json(res,200,productStandards.gs1DigitalLinkReadiness(await bodyJson(req)));
    if (p === '/api/standards/dpp/readiness' && req.method === 'POST') return json(res,200,productStandards.dppReadiness(await bodyJson(req)));
    if (p === '/api/standards/dpp/marketplace-exposure' && req.method === 'POST') return json(res,200,productStandards.marketplaceDppExposure(await bodyJson(req)));
    if (p === '/api/contracts/validate' && req.method === 'POST') return json(res,200,contractRegistry.validateContract(await bodyJson(req)));
    if (p === '/api/contracts/register' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,contractRegistry.register(b.registry||{},b.contract||{})); }
    if (p === '/api/contracts/compatibility' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,contractRegistry.compatibility(b.previous||{},b.next||{})); }
    if (p === '/api/contracts/dependencies' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,contractRegistry.dependencyClosure(b.contract||{},b.registry||{})); }
    if (p === '/api/capabilities/spec' && req.method === 'POST') { const b=await bodyJson(req); const rr=JSON.parse(fs.readFileSync(REGISTRY_FILE,'utf8')); const items=Array.isArray(rr)?rr:rr.features; const f=items.find(x=>x.id===b.featureId); return f?json(res,200,capabilityRuntimeSpec.canonicalSpec(f)):json(res,404,{error:'FEATURE_NOT_FOUND'}); }
    if (p === '/api/capabilities/evidence' && req.method === 'POST') { const b=await bodyJson(req); const rr=JSON.parse(fs.readFileSync(REGISTRY_FILE,'utf8')); const items=Array.isArray(rr)?rr:rr.features; const f=items.find(x=>x.id===b.featureId); return f?json(res,200,capabilityRuntimeSpec.observabilityAuditEvidence(f,b.event||{})):json(res,404,{error:'FEATURE_NOT_FOUND'}); }
    if (p === '/api/capability-runtime/readiness' && req.method === 'POST') { const b=await bodyJson(req); const rr=JSON.parse(fs.readFileSync(REGISTRY_FILE,'utf8')); const items=Array.isArray(rr)?rr:rr.features; const f=items.find(x=>x.id===b.featureId); return f?json(res,200,capabilityRuntimeSpec.readiness(f,b.evidence||{})):json(res,404,{error:'FEATURE_NOT_FOUND'}); }
    if (p === '/api/capabilities/portfolio' && req.method === 'GET') { const rr=JSON.parse(fs.readFileSync(REGISTRY_FILE,'utf8')); const items=Array.isArray(rr)?rr:rr.features; return json(res,200,capabilityRuntimeSpec.portfolio(items)); }
    if (p === '/api/agentic/ap2/boundary' && req.method === 'POST') return json(res,200,agentTrustBoundary.ap2Boundary(await bodyJson(req)));
    if (p === '/api/governance/agent-nonrepudiation/readiness' && req.method === 'POST') return json(res,200,agentTrustBoundary.nonRepudiationReadiness(await bodyJson(req)));
    if (p === '/api/identity/nonhuman/lifecycle' && req.method === 'POST') return json(res,200,agentTrustBoundary.identityLifecycle(await bodyJson(req)));
    if (p === '/api/identity/credential/policy' && req.method === 'POST') return json(res,200,agentTrustBoundary.credentialPolicy(await bodyJson(req)));
    if (p === '/api/authorization/continuous-agent-boundary' && req.method === 'POST') return json(res,200,agentTrustBoundary.continuousAuthorization(await bodyJson(req)));
    if (p === '/api/authorization/transaction-binding' && req.method === 'POST') return json(res,200,agentTrustBoundary.transactionBinding(await bodyJson(req)));
    if (p === '/api/audit/agent-evidence-bundle' && req.method === 'POST') return json(res,200,agentTrustBoundary.evidenceBundle(await bodyJson(req)));
    if (p === '/api/observability/agent-handoff' && req.method === 'POST') return json(res,200,agentTrustBoundary.handoffTrace(await bodyJson(req)));
    if (p === '/api/observability/agent-cascade' && req.method === 'POST') return json(res,200,agentTrustBoundary.cascadeTelemetry(await bodyJson(req)));
    if (p === '/api/compliance/ai-transparency' && req.method === 'POST') return json(res,200,agentTrustBoundary.transparencyObligation(await bodyJson(req)));
    if (p === '/api/immune/graph/evaluate' && req.method === 'POST') return json(res,200,finalHardening.abuseGraphDecision(await bodyJson(req)));
    if (p === '/api/experiments/metric-contract' && req.method === 'POST') return json(res,200,finalHardening.experimentMetricContract(await bodyJson(req)));
    if (p === '/api/experiments/srm' && req.method === 'POST') return json(res,200,finalHardening.sampleRatioMismatch(await bodyJson(req)));
    if (p === '/api/policy/version-decision' && req.method === 'POST') return json(res,200,finalHardening.policyVersionDecision(await bodyJson(req)));
    if (p === '/api/policy/jurisdiction-adapter' && req.method === 'POST') return json(res,200,finalHardening.jurisdictionAdapter(await bodyJson(req)));
    if (p === '/api/policy/simulation' && req.method === 'POST') return json(res,200,finalHardening.policySimulation(await bodyJson(req)));
    if (p === '/api/financial/provider-adapter' && req.method === 'POST') return json(res,200,finalHardening.providerAdapterDecision(await bodyJson(req)));
    if (p === '/api/agentic/mcp/evaluate' && req.method === 'POST') return json(res,200,finalHardening.mcpAdapterDecision(await bodyJson(req)));
    if (p === '/api/agentic/a2a/evaluate' && req.method === 'POST') return json(res,200,finalHardening.a2aAdapterDecision(await bodyJson(req)));
    if (p === '/api/evidence/source-authority' && req.method === 'POST') return json(res,200,finalHardening.sourceAuthorityDecision(await bodyJson(req)));
    if (p === '/api/search/relevance-calibration' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,finalHardening.relevanceCalibration(Array.isArray(b.samples)?b.samples:[])); }
    if (p === '/api/reliability/queue-backpressure' && req.method === 'POST') return json(res,200,finalHardening.queueBackpressure(await bodyJson(req)));
    if (p === '/api/identity/organization/validate' && req.method === 'POST') return json(res,200,identityEngine.validateOrganizationIdentity(await bodyJson(req)));
    if (p === '/api/identity/agent/validate' && req.method === 'POST') return json(res,200,identityEngine.validateAgentIdentity(await bodyJson(req)));
    if (p === '/api/identity/service/validate' && req.method === 'POST') return json(res,200,identityEngine.validateServiceIdentity(await bodyJson(req)));
    if (p === '/api/identity/assurance/evaluate' && req.method === 'POST') return json(res,200,identityEngine.assuranceDecision(await bodyJson(req)));
    if (p === '/api/authorization/actor-principal' && req.method === 'POST') return json(res,200,require('./lib/authorization-engine').actorPrincipalDecision(await bodyJson(req)));
    if (p === '/api/authorization/delegation-chain' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,require('./lib/authorization-engine').validateDelegationChain(Array.isArray(b.chain)?b.chain:[],b.request||{})); }
    if (p === '/api/agents/registry/validate' && req.method === 'POST') return json(res,200,agentRegistry.validateAgentRecord(await bodyJson(req)));
    if (p === '/api/agents/release/validate' && req.method === 'POST') return json(res,200,agentRegistry.releaseManifest(await bodyJson(req)));
    if (p === '/api/agents/capability-graph/evaluate' && req.method === 'POST') return json(res,200,agentRegistry.capabilityGraphDecision(await bodyJson(req)));
    if (p === '/api/operator/mission-control' && req.method === 'POST') return json(res,200,operatorControl.missionControlSnapshot(await bodyJson(req)));
    if (p === '/api/operator/approval/evaluate' && req.method === 'POST') return json(res,200,operatorControl.approvalDecision(await bodyJson(req)));
    if (p === '/api/operator/explanation' && req.method === 'POST') return json(res,200,operatorControl.explanationView(await bodyJson(req)));
    if (p === '/api/operator/evidence-view' && req.method === 'POST') return json(res,200,operatorControl.evidenceViewer(await bodyJson(req)));
    if (p === '/api/operator/trust-profile' && req.method === 'POST') return json(res,200,operatorControl.trustProfileView(await bodyJson(req)));
    if (p === '/api/operator/audit-event' && req.method === 'POST') return json(res,200,operatorControl.operatorAuditEvent(await bodyJson(req)));
    if (p === '/api/capabilities/readiness' && req.method === 'POST') return json(res,200,capabilityLifecycle.readiness(await bodyJson(req)));
    if (p === '/api/capabilities/promotion' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,capabilityLifecycle.promotionDecision(b.capability||{},b.requestedStatus||'VERIFIED')); }
    if (p === '/api/capabilities/portfolio-readiness' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,capabilityLifecycle.portfolioReadiness(Array.isArray(b.capabilities)?b.capabilities:[],b.options||{})); }
    if (p === '/api/standards/change-radar' && req.method === 'POST') return json(res,200,standardsGovernance.changeRadar(await bodyJson(req)));
    if (p === '/api/privacy/classify' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,privacy.classifyRecord(b.record||{},b.fieldClasses||{})); }
    if (p === '/api/privacy/boundary-redact' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,privacy.boundaryRedact(b.record||{},b.fieldClasses||{},b.maxClass||'INTERNAL')); }
    if (p === '/api/privacy/tool-output-policy' && req.method === 'POST') return json(res,200,privacy.toolOutputPolicy(await bodyJson(req)));
    if (p === '/api/finops/usage-cost' && req.method === 'POST') return json(res,200,finops.usageCost(await bodyJson(req)));
    if (p === '/api/finops/outcome-economics' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,finops.outcomeEconomics(Array.isArray(b.entries)?b.entries:[])); }
    if (p === '/api/events/schema/register' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,eventFabric.registerSchema(b.registry||{},b.definition||{})); }
    if (p === '/api/events/schema/compatibility' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,eventFabric.compatibilityDecision(b.previous||{},b.next||{})); }
    if (p === '/api/events/schema/health' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,eventFabric.schemaRegistryHealth(b.registry||{})); }
    if (p === '/api/observability/slo/evaluate' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,learningGovernance.sloPortfolio(Array.isArray(b.metrics)?b.metrics:[])); }
    if (p === '/api/observability/trace/correlate' && req.method === 'POST') return json(res,200,learningGovernance.correlateTrace(await bodyJson(req)));
    if (p === '/api/observability/session-replay/authorize' && req.method === 'POST') return json(res,200,learningGovernance.sessionReplayDecision(await bodyJson(req)));
    if (p === '/api/evals/golden/validate' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,learningGovernance.validateGoldenCases(Array.isArray(b.cases)?b.cases:[])); }
    if (p === '/api/evals/historical-replay' && req.method === 'POST') return json(res,200,learningGovernance.historicalReplay(await bodyJson(req)));
    if (p === '/api/evals/counterfactual-replay' && req.method === 'POST') return json(res,200,learningGovernance.counterfactualReplay(await bodyJson(req)));
    if (p === '/api/memory/decision-journal' && req.method === 'POST') return json(res,200,learningGovernance.decisionJournalEntry(await bodyJson(req)));
    if (p === '/api/evidence/fields/provenance' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,commerceTrust.fieldProvenance(b.fields||{},Array.isArray(b.evidence)?b.evidence:[])); }
    if (p === '/api/evidence/freshness' && req.method === 'POST') return json(res,200,commerceTrust.freshnessPolicy(await bodyJson(req)));
    if (p === '/api/evidence/conflicts' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,commerceTrust.conflictSummary(Array.isArray(b.evidence)?b.evidence:[])); }
    if (p === '/api/trust/seller' && req.method === 'POST') return json(res,200,commerceTrust.sellerTrustProfile(await bodyJson(req)));
    if (p === '/api/trust/product' && req.method === 'POST') return json(res,200,commerceTrust.productTrustProfile(await bodyJson(req)));
    if (p === '/api/trust/supplier' && req.method === 'POST') return json(res,200,commerceTrust.supplierTrustProfile(await bodyJson(req)));
    if (p === '/api/trust/stock' && req.method === 'POST') return json(res,200,commerceTrust.stockTrustProfile(await bodyJson(req)));
    if (p === '/api/trust/fulfilment' && req.method === 'POST') return json(res,200,commerceTrust.fulfilmentTrustProfile(await bodyJson(req)));
    if (p === '/api/control-plane/evaluate' && req.method === 'POST') return json(res,200,controlPlane.controlDecision(await bodyJson(req)));
    if (p === '/api/control-plane/source/register' && req.method === 'POST') return json(res,200,controlPlane.registerSource(await bodyJson(req)));
    if (p === '/api/control-plane/capability/issue' && req.method === 'POST') return json(res,200,controlPlane.issueCapabilityToken(await bodyJson(req)));
    if (p === '/api/control-plane/capability/validate' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,controlPlane.validateCapabilityToken(b.token||{},b.request||{})); }
    if (p === '/api/control-plane/policy/simulate' && req.method === 'POST') return json(res,200,controlPlane.simulatePolicy(await bodyJson(req)));

    if (p === '/api/analytics/funnel' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,wave4.funnelReport(Array.isArray(b.events)?b.events:[],Array.isArray(b.steps)?b.steps:[])); }
    if (p === '/api/experiments/bandit/choose' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,wave4.chooseBanditArm(Array.isArray(b.arms)?b.arms:[],b.context||{})); }
    if (p === '/api/governance/nist-lifecycle' && req.method === 'POST') return json(res,200,wave4.nistLifecycle(await bodyJson(req)));
    if (p === '/api/catalog/identity' && req.method === 'POST') return json(res,200,wave4.productIdentity(await bodyJson(req)));
    if (p === '/api/catalog/canonicalise' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,wave4.canonicaliseCandidates(Array.isArray(b.items)?b.items:[])); }
    if (p === '/api/catalog/attributes/extract' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,wave4.extractAttributes(b.proposal||{},b.evidence||{})); }
    if (p === '/api/demand/liquidity-v2' && req.method === 'POST') return json(res,200,wave4.liquidityScore(await bodyJson(req)));
    if (p === '/api/seller/quality' && req.method === 'POST') return json(res,200,wave4.sellerQuality(await bodyJson(req)));
    if (p === '/api/buyer/intent-v2' && req.method === 'POST') return json(res,200,wave4.buyerIntent(await bodyJson(req)));
    if (p === '/api/buyer/return-prevention-v2' && req.method === 'POST') return json(res,200,wave4.returnPrevention(await bodyJson(req)));
    if (p === '/api/safety/recall-graph-v2' && req.method === 'POST') return json(res,200,wave4.recallMatch(await bodyJson(req)));
    if (p === '/api/compliance/eligibility' && req.method === 'POST') return json(res,200,wave4.jurisdictionEligibility(await bodyJson(req)));
    if (p === '/api/authorization/delegation' && req.method === 'POST') return json(res,200,wave4.delegatedAuthority(await bodyJson(req)));
    if (p === '/api/authorization/material-change' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,wave4.materialChangeReauthorization(b.before||{},b.after||{})); }
    if (p === '/api/agentic/attribution' && req.method === 'POST') return json(res,200,wave4.agentAttribution(await bodyJson(req)));
    if (p === '/api/engineering/test-integrity-guard' && req.method === 'POST') return json(res,200,wave4.testIntegrityGuard(await bodyJson(req)));
    if (p === '/api/engineering/blast-radius' && req.method === 'POST') return json(res,200,wave4.blastRadius(await bodyJson(req)));
    if (p === '/api/engineering/architecture-guard' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,wave4.architectureGuard(b.change||{},Array.isArray(b.contracts)?b.contracts:[])); }
    if (p === '/api/finops/ledger' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,wave4.aiCostLedger(Array.isArray(b.entries)?b.entries:[])); }
    if (p === '/api/reliability/circuit-breaker' && req.method === 'POST') return json(res,200,wave4.circuitBreaker(await bodyJson(req)));

    if (p === '/api/immune/learning-admission' && req.method === 'POST') return json(res,200,immuneWave.learningAdmission(await bodyJson(req)));
    if (p === '/api/immune/metric-integrity-v2' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,immuneWave.metricIntegrity(Array.isArray(b.events)?b.events:[])); }
    if (p === '/api/immune/sybil-graph' && req.method === 'POST') return json(res,200,immuneWave.sybilGraph(await bodyJson(req)));
    if (p === '/api/immune/review-ring' && req.method === 'POST') return json(res,200,immuneWave.reviewRing(await bodyJson(req)));
    if (p === '/api/immune/refund-abuse' && req.method === 'POST') return json(res,200,immuneWave.refundAbuse(await bodyJson(req)));
    if (p === '/api/immune/promo-abuse' && req.method === 'POST') return json(res,200,immuneWave.promoAbuse(await bodyJson(req)));
    if (p === '/api/immune/collusion' && req.method === 'POST') return json(res,200,immuneWave.collusion(await bodyJson(req)));
    if (p === '/api/immune/manipulation' && req.method === 'POST') return json(res,200,immuneWave.manipulation(await bodyJson(req)));
    if (p === '/api/immune/evidence-pack' && req.method === 'POST') return json(res,200,immuneWave.caseEvidencePack(await bodyJson(req)));
    if (p === '/api/immune/friction-budget' && req.method === 'POST') return json(res,200,immuneWave.frictionBudget(await bodyJson(req)));
    if (p === '/api/immune/reintegration' && req.method === 'POST') return json(res,200,immuneWave.reintegration(await bodyJson(req)));
    if (p === '/api/immune/synthetic-suite' && req.method === 'POST') return json(res,200,immuneWave.syntheticAbuseSuite());

    if (p === '/api/catalog/separation' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,wave5.catalogSeparation(b.product||{},b.offer||{})); }
    if (p === '/api/catalog/identifier-hierarchy' && req.method === 'POST') return json(res,200,wave5.identifierHierarchy(await bodyJson(req)));
    if (p === '/api/catalog/duplicates/resolve-v2' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,wave5.duplicateResolution(Array.isArray(b.items)?b.items:[])); }
    if (p === '/api/catalog/virtual-inventory' && req.method === 'POST') return json(res,200,wave5.virtualInventory(await bodyJson(req)));
    if (p === '/api/catalog/lifecycle-graph' && req.method === 'POST') return json(res,200,wave5.lifecycleGraph(await bodyJson(req)));
    if (p === '/api/catalog/standards-readiness' && req.method === 'POST') return json(res,200,wave5.standardsReadiness(await bodyJson(req)));
    if (p === '/api/catalog/image-integrity' && req.method === 'POST') return json(res,200,wave5.imageIntegrity(await bodyJson(req)));
    if (p === '/api/demand/opportunities-v2' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,wave5.demandOpportunities(Array.isArray(b.searches)?b.searches:[],Array.isArray(b.offers)?b.offers:[])); }
    if (p === '/api/demand/concentration-risk' && req.method === 'POST') return json(res,200,wave5.concentrationRisk(await bodyJson(req)));
    if (p === '/api/demand/rfq' && req.method === 'POST') return json(res,200,wave5.rfq(await bodyJson(req)));
    if (p === '/api/seller/supplier-reliability' && req.method === 'POST') return json(res,200,wave5.supplierReliability(await bodyJson(req)));
    if (p === '/api/buyer/grounded-answer' && req.method === 'POST') return json(res,200,wave5.groundedBuyerAnswer(await bodyJson(req)));
    if (p === '/api/buyer/pricing-fairness' && req.method === 'POST') return json(res,200,wave5.pricingFairness(await bodyJson(req)));
    if (p === '/api/safety/inbox-v2' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,wave5.safetyInbox(Array.isArray(b.products)?b.products:[],b.policy||{})); }
    if (p === '/api/safety/regulatory-radar' && req.method === 'POST') return json(res,200,wave5.regulatoryRadar(await bodyJson(req)));
    if (p === '/api/safety/regulation-trace' && req.method === 'POST') return json(res,200,wave5.regulationTrace(await bodyJson(req)));
    if (p === '/api/safety/green-claim' && req.method === 'POST') return json(res,200,wave5.greenClaimGuard(await bodyJson(req)));

    if (p === '/api/identity/assurance-v2' && req.method === 'POST') return json(res,200,wave6.assuranceDecision(await bodyJson(req)));
    if (p === '/api/identity/selective-disclosure' && req.method === 'POST') return json(res,200,wave6.selectiveDisclosure(await bodyJson(req)));
    if (p === '/api/identity/organization-principal' && req.method === 'POST') return json(res,200,wave6.organizationPrincipal(await bodyJson(req)));
    if (p === '/api/authorization/continuous' && req.method === 'POST') return json(res,200,wave6.continuousAuthorization(await bodyJson(req)));
    if (p === '/api/authorization/consent-receipt' && req.method === 'POST') return json(res,200,wave6.consentReceipt(await bodyJson(req)));
    if (p === '/api/agentic/intent-receipt' && req.method === 'POST') return json(res,200,wave6.intentReceipt(await bodyJson(req)));
    if (p === '/api/agentic/replay-protection' && req.method === 'POST') { const b=await bodyJson(req); const ledger=new Set(Array.isArray(b.usedKeys)?b.usedKeys:[]); return json(res,200,wave6.replayProtection(b.request||{},ledger)); }
    if (p === '/api/agentic/channel-funnel' && req.method === 'POST') { const b=await bodyJson(req); return json(res,200,wave6.agentChannelFunnel(Array.isArray(b.events)?b.events:[])); }
    if (p === '/api/agentic/sandbox' && req.method === 'POST') return json(res,200,wave6.sandboxDecision(await bodyJson(req)));
    if (p === '/api/agentic/rate-limit' && req.method === 'POST') return json(res,200,wave6.agentRateLimit(await bodyJson(req)));
    if (p === '/api/financial/provider-boundary-v2' && req.method === 'POST') return json(res,200,wave6.paymentAdapterBoundary(await bodyJson(req)));
    if (p === '/api/financial/economic-exposure' && req.method === 'POST') return json(res,200,wave6.economicExposure(await bodyJson(req)));
    if (p === '/api/reliability/complexity-budget' && req.method === 'POST') return json(res,200,wave6.complexityBudget(await bodyJson(req)));
    if (p === '/api/policy/bundle' && req.method === 'GET') return json(res,200,policyBundle.getPolicyBundle());
    if (p === '/api/integrations/loadify-market/compatibility' && req.method === 'GET') return json(res,200,loadifyMarketCompatibility.compatibilityStatus());
    if (p === '/api/integrations/loadify-market/fact/admit' && req.method === 'POST') return json(res,200,loadifyMarketCompatibility.admitFactEnvelope(await bodyJson(req)));
    if (p === '/api/integrations/loadify-market/action/assess' && req.method === 'POST') return json(res,200,loadifyMarketCompatibility.assessActionIntent(await bodyJson(req)));
    if (p === '/api/integrations/registry' && req.method === 'GET') return json(res,200,connectorRegistry.getConnectorRegistry());
    if (p === '/api/state' && req.method === 'GET') return json(res,200,loadState());
    if (p === '/api/storage/health' && req.method === 'GET') return json(res,200,stateStore.storageHealth({file:STATE_FILE,defaults:defaultState,backupDir:STATE_BACKUP_DIR}));
    if (p === '/api/storage/audit-chain/verify' && req.method === 'GET') { const s=loadState(); return json(res,200,auditLedger.verify(Array.isArray(s.auditChain)?s.auditChain:[])); }
    if (p === '/api/storage/export-package' && req.method === 'GET') { const s=loadState(); const releaseManifest=JSON.parse(fs.readFileSync(path.join(DATA_DIR,'release-manifest.json'),'utf8')); const systemManifest=JSON.parse(fs.readFileSync(path.join(DATA_DIR,'system-manifest.json'),'utf8')); return json(res,200,recoveryPackage.buildExport({state:s,releaseManifest,systemManifest})); }
    if (p === '/api/storage/import-package/validate' && req.method === 'POST') return json(res,200,recoveryPackage.validateImport(await bodyJson(req),{defaults:defaultState}));
    if (p === '/api/storage/recovery-drill' && req.method === 'POST') return json(res,200,stateStore.recoveryDrill({file:STATE_FILE,defaults:defaultState,backupDir:STATE_BACKUP_DIR}));
    if (p === '/api/registry' && req.method === 'GET') {
      const registry = fs.existsSync(REGISTRY_FILE) ? JSON.parse(fs.readFileSync(REGISTRY_FILE,'utf8')) : [];
      return json(res,200,{count:registry.length,features:registry});
    }
    if (p === '/api/policy/evaluate' && req.method === 'POST') {
      const decision = evaluateAction(await bodyJson(req));
      return json(res,200,decision);
    }
    if (p === '/api/evidence/resolve' && req.method === 'POST') {
      const b = await bodyJson(req);
      return json(res,200,resolveClaim(b.claim || null, Array.isArray(b.evidence) ? b.evidence : []));
    }
    if (p === '/api/evidence/admission' && req.method === 'POST') {
      return json(res,200,admissionDecision(await bodyJson(req)));
    }
    if (p === '/api/evidence/provenance' && req.method === 'POST') {
      const b=await bodyJson(req); return json(res,200,{chain:provenanceChain(Array.isArray(b.evidence)?b.evidence:[])});
    }
    if (p === '/api/trust/evaluate' && req.method === 'POST') {
      return json(res,200,trustVector(await bodyJson(req)));
    }
    if (p === '/api/authorization/mandate' && req.method === 'POST') {
      const b = await bodyJson(req);
      return json(res,200,validateMandate(b.mandate || {}, b.action || {}));
    }
    if (p === '/api/authorization/intent' && req.method === 'POST') {
      const b = await bodyJson(req);
      return json(res,200,validateIntent(b.intent || {}, b.action || {}));
    }
    if (p === '/api/authorization/evaluate' && req.method === 'POST') {
      return json(res,200,authorize(await bodyJson(req)));
    }
    if (p === '/api/immune/assess' && req.method === 'POST') {
      return json(res,200,assessCase(await bodyJson(req)));
    }
    if (p === '/api/immune/metric-integrity' && req.method === 'POST') {
      const b=await bodyJson(req); return json(res,200,metricIntegrity(Array.isArray(b.events)?b.events:[]));
    }
    if (p === '/api/immune/recovery' && req.method === 'POST') {
      return json(res,200,recoveryPlan(await bodyJson(req)));
    }
    if (p === '/api/mode' && req.method === 'POST') {
      const {mode} = await bodyJson(req); const allowed=['OFF','SHADOW','RECOMMEND','ASSISTED','CONTROLLED_AUTONOMY'];
      if (!allowed.includes(mode)) return json(res,400,{error:'invalid_mode'});
      const s=loadState(); const nextKill=(mode==='OFF'||mode==='SHADOW'||mode==='RECOMMEND')?false:s.killSwitch;
      if(s.mode===mode && s.killSwitch===nextKill) return json(res,200,{...s,noOp:true});
      s.mode=mode; s.killSwitch=nextKill; audit(s,requestPrincipal(req).id,`Autopilot mode changed to ${mode}`,'RECORDED','Autonomy Boundary v1'); const saved=saveState(s); return json(res,200,saved);
    }
    if (p === '/api/kill-switch' && req.method === 'POST') {
      const s=loadState(); s.killSwitch=true; s.mode='RECOMMEND'; audit(s,'Safety Controller','Global kill switch activated; execution reduced to Recommend','PASS','Circuit Breaker v1'); const saved=saveState(s); return json(res,200,saved);
    }
    if (p.startsWith('/api/approvals/') && req.method === 'POST') {
      const parts=p.split('/').filter(Boolean); const id=parts[2]; const action=parts[3]; if(!['approve','reject'].includes(action)) return json(res,404,{error:'not_found'});
      const s=loadState(); const a=s.approvals.find(x=>x.id===id); if(!a) return json(res,404,{error:'approval_not_found'});
      if(a.status!=='PENDING') return json(res,409,{error:'approval_not_pending'});
      const actor=requestPrincipal(req);
      if(action==='reject'){
        a.status='REJECTED';a.resolvedAt=new Date().toISOString();a.resolvedBy=actor.id;
        audit(s,actor.id,`REJECTED: ${a.title}`,'REJECTED',a.policyRef||'Human Approval v1');saveState(s);return json(res,200,a);
      }
      const highRisk=['R3','R4'].includes(a.risk);
      const decision=operatorControl.approvalDecision({approval:a,actor,action:highRisk&&a.firstApproverId?'FINAL_APPROVE':'APPROVE'});
      if(!decision.allowed) return json(res,403,{error:'approval_policy_denied',decision});
      if(highRisk && a.requireFourEyes===true && !a.firstApproverId){
        a.firstApproverId=actor.id;a.firstApprovedAt=new Date().toISOString();a.status='PENDING';
        audit(s,actor.id,`FIRST APPROVAL RECORDED: ${a.title}`,'PENDING_SECOND_APPROVER',a.policyRef||'Human Approval v1');saveState(s);
        return json(res,202,{...a,decision:'PENDING_SECOND_APPROVER'});
      }
      a.status='APPROVED';a.resolvedAt=new Date().toISOString();a.resolvedBy=actor.id;
      audit(s,actor.id,`APPROVED: ${a.title}`,'APPROVED',a.policyRef||'Human Approval v1');saveState(s);return json(res,200,a);
    }
    if (p === '/api/experiments' && req.method === 'POST') {
      const b=await bodyJson(req); if(!b.name || !b.primaryMetric) return json(res,400,{error:'name_and_primaryMetric_required'});
      const s=loadState(); const allowedRisks=['R0','R1','R2','R3','R4']; const e={id:`EXP-${String(s.experiments.length+1).padStart(3,'0')}`,name:String(b.name).slice(0,120),type:['A/B','A/B/C','BANDIT'].includes(b.type)?b.type:'A/B',primaryMetric:String(b.primaryMetric).slice(0,120),status:'DRAFT',rollout:0,risk:allowedRisks.includes(b.risk)?b.risk:'R1'}; s.experiments.push(e); audit(s,requestPrincipal(req).id,`Created standalone experiment ${e.name}`,'RECORDED','Experiment Governance v1'); saveState(s); return json(res,201,e);
    }
    if (p.startsWith('/api/flags/') && req.method === 'POST') {
      const id=p.split('/')[3]; const b=await bodyJson(req); const s=loadState(); const f=s.flags.find(x=>x.id===id); if(!f) return json(res,404,{error:'flag_not_found'});
      const requestedState=String(b.state||'').toUpperCase();
      if(requestedState==='INTERNAL'){f.rollout=0;f.state='INTERNAL';audit(s,requestPrincipal(req).id,`Feature flag ${f.key} → INTERNAL`,'RECORDED','Feature Flag Governance v1');saveState(s);return json(res,200,f);}
      if(requestedState==='OFF'){f.rollout=0;f.state='OFF';audit(s,requestPrincipal(req).id,`Feature flag ${f.key} → OFF`,'RECORDED','Feature Flag Governance v1');saveState(s);return json(res,200,f);}
      const rollout=Number(b.rollout); if(!Number.isFinite(rollout)||rollout<1||rollout>100) return json(res,400,{error:'rollout_1_100_or_explicit_state'}); f.rollout=rollout; f.state='PERCENTAGE'; audit(s,requestPrincipal(req).id,`Feature flag ${f.key} rollout → ${rollout}%`,'RECORDED','Feature Flag Governance v1'); saveState(s); return json(res,200,f);
    }
    if (p.startsWith('/api/agents/') && p.endsWith('/autonomy-request') && req.method === 'POST') {
      const id=p.split('/')[3]; const b=await bodyJson(req); const target=Number(b.target); if(!Number.isInteger(target)||target<0||target>4) return json(res,400,{error:'target_0_4'});
      const s=loadState(); const agent=s.agents.find(x=>x.id===id); if(!agent) return json(res,404,{error:'agent_not_found'});
      const approval={id:`APR-${String(s.approvals.length+1).padStart(3,'0')}`,type:'Autonomy change',title:`${agent.name}: Level ${agent.autonomy} → ${target}`,risk:agent.risk,status:'PENDING',requestedBy:'AI Governance',requestedById:'AI-GOVERNANCE',policyRef:'Autonomy Promotion v1',requestedAt:new Date().toISOString(),metadata:{agentId:id,target}}; s.approvals.push(approval); audit(s,'AI Governance',`Requested autonomy change for ${agent.name} to L${target}`,'PENDING','Autonomy Promotion v1'); saveState(s); return json(res,202,approval);
    }
    if (p.startsWith('/api/')) return json(res,404,{error:'not_found'});
    if (staticFile(req,res,p)) return;
    res.writeHead(404,{'Content-Type':'text/plain; charset=utf-8','Cache-Control':'no-store','X-Request-ID':res._lipRequestId,...securityHeaders()});res.end('Not found');
  } catch (e) {
    if(e instanceof RequestBodyError) return json(res,e.status,{error:e.code});
    return json(res,500,{error:'internal_error'});
  }
});
server.headersTimeout=TRANSPORT_LIMITS.headersTimeoutMs;
server.requestTimeout=TRANSPORT_LIMITS.requestTimeoutMs;
server.keepAliveTimeout=TRANSPORT_LIMITS.keepAliveTimeoutMs;
server.maxRequestsPerSocket=TRANSPORT_LIMITS.maxRequestsPerSocket;
server.maxHeadersCount=TRANSPORT_LIMITS.maxHeadersCount;
server.on('checkContinue',(req,res)=>{res._lipRequestId=crypto.randomUUID();return json(res,417,{error:'EXPECTATION_NOT_SUPPORTED'});});
server.on('checkExpectation',(req,res)=>{res._lipRequestId=crypto.randomUUID();return json(res,417,{error:'EXPECTATION_NOT_SUPPORTED'});});

function createShutdownHandler({runtimeServer=server,cleanup=()=>{},exitFn=code=>process.exit(code),graceMs=2000}={}){
  let stopping=false,finished=false,timer=null;
  const finish=()=>{if(finished)return;finished=true;if(timer)clearTimeout(timer);try{cleanup();}finally{exitFn(0);}};
  return ()=>{
    if(stopping)return;stopping=true;
    try{runtimeServer.close(()=>finish());runtimeServer.closeIdleConnections?.();}
    catch(_){return finish();}
    timer=setTimeout(()=>{try{runtimeServer.closeAllConnections?.();}finally{finish();}},Math.max(10,Number(graceMs)||2000));
    timer.unref?.();
  };
}

if (require.main === module) {
  const lockFile=path.join(DATA_DIR,'runtime.lock');
  const preflight=runtimeStartup.verifyRelease({root:ROOT,defaults:defaultState,backupDir:STATE_BACKUP_DIR,stateFile:STATE_FILE});
  if(!preflight.ready){console.error(JSON.stringify({error:'STARTUP_PREFLIGHT_HOLD',reasons:preflight.reasons}));process.exitCode=1;}
  else {
    const lock=runtimeStartup.acquireRuntimeLock({lockFile});
    if(!lock.acquired){console.error(JSON.stringify({error:lock.reason,existing:lock.existing||null}));process.exitCode=1;}
    else {
      const cleanup=()=>runtimeStartup.releaseRuntimeLock({lockFile});
      const shutdown=createShutdownHandler({runtimeServer:server,cleanup});
      process.once('exit',cleanup);process.once('SIGINT',shutdown);process.once('SIGTERM',shutdown);
      server.listen(PORT, RUNTIME_CONFIG.bindHost, () => { console.log(`LIP standalone server on http://${RUNTIME_CONFIG.bindHost}:${PORT}`); if(process.env.LIP_PRINT_TOOLING_TOKEN==='1') console.log(`LIP local tooling token: ${LOCAL_TOOLING_SECRET}`); });
    }
  }
}
module.exports = { server, loadState, saveState, defaultState, STATE_FILE, STATE_BACKUP_DIR, ROOT, localMutationAuth, requestMetadataBoundary, sessionCookieBoundary, validateLocalHostHeader, bodyJson, createShutdownHandler, TRANSPORT_LIMITS, REQUEST_TARGET_MAX_BYTES, httpAdmission };
