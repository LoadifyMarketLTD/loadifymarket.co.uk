'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const cp=require('./lib/control-plane-engine');

function base(){
  const source=cp.registerSource({id:'SRC-1',type:'internal',authority:'merchant_system',integrityVerified:true,allowedPurposes:['operations']}).record;
  const policyBundle=cp.buildPolicyBundle({id:'core',version:'1.0.0',rules:[{id:'default-deny'}]}).bundle;
  const token=cp.issueCapabilityToken({tokenId:'TOK-1',actorId:'AG-1',principalId:'ORG-1',capabilities:['catalog.read'],audience:'lip'});
  return {source,policyBundle,capabilityToken:token,actor:{id:'AG-1',type:'agent'},principal:{id:'ORG-1'},agent:{id:'AG-1',allowedTools:['catalog.read'],deniedTools:['payments.*']},audience:'lip',privacy:{dataClass:'INTERNAL',purpose:'operations',allowedPurposes:['operations'],actorClearance:'INTERNAL',minimumNecessary:true},budget:{dailyBudget:10,dailySpend:1,workflowBudget:2,workflowSpend:.2,estimatedNextCost:.1,maxToolCalls:10,toolCalls:1,loopProgress:1},dependencies:{aiProvider:'UP',payments:'UP',database:'UP',queue:'UP'},autopilot:{mode:'CONTROLLED_AUTONOMY',killSwitch:false},action:{name:'read_catalog',capability:'catalog.read',tool:'catalog.read',domain:'catalog',risk:'R1',effect:'EXECUTE',reversible:true,humanApproval:false,intentAligned:true,evidenceState:'CONFIRMED'}};
}

test('registered source requires integrity verification',()=>{
  const r=cp.registerSource({id:'x',type:'external',authority:'verified_provider'}); assert.equal(r.valid,false); assert.ok(r.reasons.includes('SOURCE_INTEGRITY_NOT_VERIFIED'));
});
test('capability token is principal and audience bound',()=>{
  const t=cp.issueCapabilityToken({actorId:'a',principalId:'p',capabilities:['catalog.*'],audience:'lip'});
  assert.equal(cp.validateCapabilityToken(t,{actorId:'a',principalId:'p',capability:'catalog.read',audience:'lip'}).allowed,true);
  assert.equal(cp.validateCapabilityToken(t,{actorId:'a',principalId:'other',capability:'catalog.read',audience:'lip'}).allowed,false);
});
test('denylist overrides allowlist',()=>{
  const d=cp.evaluateToolAccess({tool:'payments.execute',capability:'payments.execute',allowlist:['payments.*'],denylist:['payments.execute']}); assert.equal(d.allowed,false); assert.ok(d.reasons.includes('TOOL_EXPLICITLY_DENIED'));
});
test('shadow mode cannot execute',()=>{ assert.equal(cp.autonomyGate({mode:'SHADOW',risk:'R1',reversible:true,requestedEffect:'EXECUTE'}).allowed,false); });
test('controlled autonomy can execute bounded reversible R1 action',()=>{ assert.equal(cp.autonomyGate({mode:'CONTROLLED_AUTONOMY',risk:'R1',reversible:true,requestedEffect:'EXECUTE'}).allowed,true); });
test('kill switch blocks execution independent of mode',()=>{ assert.equal(cp.autonomyGate({mode:'CONTROLLED_AUTONOMY',risk:'R1',reversible:true,requestedEffect:'EXECUTE',killSwitch:true}).allowed,false); });

test('recommend mode allows recommendation but not execution',()=>{
  assert.equal(cp.autonomyGate({mode:'RECOMMEND',risk:'R1',reversible:true,requestedEffect:'RECOMMEND'}).allowed,true);
  assert.equal(cp.autonomyGate({mode:'RECOMMEND',risk:'R1',reversible:true,requestedEffect:'EXECUTE'}).allowed,false);
});
test('assisted mode requires human approval for execution',()=>{
  assert.equal(cp.autonomyGate({mode:'ASSISTED',risk:'R1',reversible:true,requestedEffect:'EXECUTE',humanApproval:false}).allowed,false);
  assert.equal(cp.autonomyGate({mode:'ASSISTED',risk:'R1',reversible:true,requestedEffect:'EXECUTE',humanApproval:true}).allowed,true);
});
test('tool allowlist fails closed when capability is absent',()=>{
  const d=cp.evaluateToolAccess({tool:'catalog.write',capability:'catalog.write',allowlist:['catalog.read'],denylist:[]});
  assert.equal(d.allowed,false); assert.ok(d.reasons.includes('TOOL_NOT_ALLOWLISTED'));
});

test('unified control plane allows fully bounded action',()=>{ const d=cp.controlDecision(base()); assert.equal(d.allowed,true,d.reasons.join(',')); assert.equal(d.auditEvidence.decision,'ALLOW'); });
test('unified control plane fails closed on stale source',()=>{ const x=base(); x.source.observedAt='2020-01-01T00:00:00Z'; x.sourceRequirements={purpose:'operations',maxAgeHours:1,now:'2026-08-20T20:00:00Z'}; const d=cp.controlDecision(x); assert.equal(d.allowed,false); assert.ok(d.reasons.some(x=>x.includes('SOURCE_STALE'))); });
test('unified control plane blocks expired capability token',()=>{ const x=base(); x.capabilityToken.expiresAt='2020-01-01T00:00:00Z'; x.now='2026-08-20T20:00:00Z'; const d=cp.controlDecision(x); assert.equal(d.allowed,false); assert.ok(d.reasons.some(x=>x.includes('CAPABILITY_TOKEN_EXPIRED'))); });
test('unified control plane blocks budget abuse',()=>{ const x=base(); x.budget.dailyBudget=1; x.budget.dailySpend=.95; x.budget.estimatedNextCost=.2; const d=cp.controlDecision(x); assert.equal(d.allowed,false); assert.ok(d.reasons.some(x=>x.includes('DAILY_BUDGET_EXCEEDED'))); });
test('policy simulation reports changed decisions',()=>{
  const x=base();
  const next={...x.policyBundle,status:'DRAFT'};
  const s=cp.simulatePolicy({currentBundle:x.policyBundle,candidateBundle:next,scenarios:[{...x,id:'S1'}]});
  assert.equal(s.safeToEvaluate,false);
});
