'use strict';const test=require('node:test');const assert=require('node:assert/strict');const fs=require('fs');const v=require('./lib/demo-promotion-verifier');
const registry=JSON.parse(fs.readFileSync('./data/feature-registry.json','utf8'));const ids=Object.keys(v.MAP);const byId=new Map(registry.map(x=>[x.id,x]));
test('all 13 promoted features retain explicit runtime/test/API evidence',()=>{const r=v.verifyAll(ids);assert.equal(r.count,13);assert.equal(r.verified,true,JSON.stringify(r.results.filter(x=>!x.verified)));for(const id of ids)assert.equal(byId.get(id)?.status,'IMPLEMENTED_MODEL');});
test('unknown feature cannot be promoted',()=>assert.equal(v.verify('LIP-UNKNOWN').verified,false));
