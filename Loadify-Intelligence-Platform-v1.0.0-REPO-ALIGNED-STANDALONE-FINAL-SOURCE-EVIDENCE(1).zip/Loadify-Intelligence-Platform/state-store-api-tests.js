'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const {server,STATE_FILE}=require('./server');
let base,before;

test.before(async()=>{before=fs.readFileSync(STATE_FILE);await new Promise(r=>server.listen(0,'127.0.0.1',r)); base=`http://127.0.0.1:${server.address().port}`;});
test.after(async()=>{await new Promise(r=>server.close(r));fs.writeFileSync(STATE_FILE,before);});

test('storage health endpoint reports valid versioned primary',async()=>{
  const r=await fetch(`${base}/api/storage/health`); assert.equal(r.status,200); const j=await r.json();
  assert.equal(j.healthy,true); assert.equal(j.currentSchemaVersion,1); assert.equal(j.primary.valid,true); assert.ok(Number.isInteger(j.primary.revision));
});

test('persistent audit chain verifies after a state mutation',async()=>{
  let r=await fetch(`${base}/api/kill-switch`,{method:'POST',headers:{'content-type':'application/json'},body:'{}'}); assert.equal(r.status,200);
  r=await fetch(`${base}/api/storage/audit-chain/verify`); assert.equal(r.status,200); const j=await r.json();
  assert.equal(j.valid,true); assert.ok(j.count>=1);
});
