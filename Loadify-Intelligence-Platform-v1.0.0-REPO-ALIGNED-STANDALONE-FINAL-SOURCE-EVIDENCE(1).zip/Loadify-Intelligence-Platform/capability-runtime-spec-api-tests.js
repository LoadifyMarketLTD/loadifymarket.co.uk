'use strict';
const test=require('node:test'); const assert=require('node:assert/strict');
process.env.PORT='4199'; const {server}=require('./server'); server.listen(4199,'127.0.0.1');
const base='http://127.0.0.1:4199';
async function post(path,body){const r=await fetch(base+path,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});return {status:r.status,body:await r.json()};}
test('canonical capability spec is available by registry id',async()=>{const r=await post('/api/capabilities/spec',{featureId:'LIP-122'});assert.equal(r.status,200);assert.equal(r.body.valid,true);assert.equal(r.body.spec.featureId,'LIP-122');assert.equal(r.body.spec.audit.appendOnly,true);});
test('capability evidence rejects unattributed event',async()=>{const r=await post('/api/capabilities/evidence',{featureId:'LIP-197',event:{requestId:'R',decision:'ALLOW',policyVersion:'P1'}});assert.equal(r.body.accepted,false);assert.ok(r.body.reasons.includes('ACTOR_REQUIRED'));});
test('capability readiness fails closed without rollback proof for R2+',async()=>{const r=await post('/api/capability-runtime/readiness',{featureId:'LIP-122',evidence:{contractTestPassed:true,regressionPassed:true,apiProbePassed:true,auditProbePassed:true}});assert.equal(r.body.ready,false);assert.ok(r.body.reasons.includes('ROLLBACK_PROBE_REQUIRED'));});
test('portfolio compiles all supported generic capabilities',async()=>{const r=await fetch(base+'/api/capabilities/portfolio');const b=await r.json();assert.equal(b.decision,'PASS');assert.ok(b.count>=195);});
test.after(()=>new Promise(resolve=>server.close(resolve)));
