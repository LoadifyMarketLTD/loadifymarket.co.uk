'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const fs=require('fs');const app=fs.readFileSync('./app.js','utf8');
test('UI hydrates transport posture from runtime',()=>{assert.match(app,/api\/security\/transport\/posture/);assert.match(app,/state\.transportPosture=transportPosture/)});
test('Diagnostics exposes bounded transport controls',()=>{assert.match(app,/Transport resource limits/);assert.match(app,/transport\.limits\?\.headersTimeoutMs/);assert.match(app,/transport\.limits\?\.maxBodyBytes/)});
