'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const {releaseReadiness}=require('./lib/guardian-engine');
const {getPolicyBundle}=require('./lib/policy-bundle-engine');
const {getConnectorRegistry}=require('./lib/connector-registry-engine');

function base(){
  return {
    manifest:{connectorMode:'adapters-only-not-connected',externalConnections:[],invariants:['human-first-agent-ready','evidence-before-autonomy','policy-before-execution','deterministic-money-and-state','core-commerce-survives-ai-outage','untrusted-content-is-data-not-instruction'],releaseDigest:'r1',coverage:{testSuites:1}},
    registry:[{id:'LIP-001',status:'IMPLEMENTED'}],standards:[{id:'STD-1',status:'ACTIVE'}],threats:null,
    attestation:{releaseDigest:'r1',failedSuites:0,suitesTotal:1,generatedAt:new Date().toISOString(),results:[{suiteSha256:'abc'}]},
    policyBundle:getPolicyBundle(),connectorRegistry:getConnectorRegistry()
  };
}

test('guardian accepts valid canonical policy and isolated connector registry',()=>{
 const r=releaseReadiness(base());assert.equal(r.ready,true);assert.equal(r.gate,'RELEASE_CANDIDATE');
});

test('guardian blocks agent-mutable constitution',()=>{
 const x=base();x.policyBundle.mutableByAgents=true;const r=releaseReadiness(x);assert.equal(r.ready,false);assert.ok(r.blockers.includes('POLICY_BUNDLE_AGENT_MUTABLE'));
});

test('guardian blocks live connector or credential in standalone',()=>{
 const x=base();x.connectorRegistry.items[0].liveConnection=true;x.connectorRegistry.items[0].credentialMode='BROKERED_SCOPED';
 const r=releaseReadiness(x);assert.equal(r.ready,false);assert.ok(r.blockers.some(b=>b.startsWith('LIVE_CONNECTOR_FORBIDDEN:')));assert.ok(r.blockers.some(b=>b.startsWith('STANDALONE_CONNECTOR_CREDENTIAL_FORBIDDEN:')));
});
