const test = require('node:test');
const assert = require('node:assert/strict');
const { server } = require('./server');

let base;
test.before(async () => {
  await new Promise(resolve => server.listen(0,'127.0.0.1',resolve));
  base = `http://127.0.0.1:${server.address().port}`;
});
test.after(() => server.close());

test('health endpoint works', async () => {
  const r = await fetch(base + '/api/health');
  assert.equal(r.status,200); const j=await r.json(); assert.equal(j.ok,true);
});

test('state is standalone and disconnected', async () => {
  const r = await fetch(base + '/api/state'); const j=await r.json();
  assert.equal(j.environment,'standalone'); assert.equal(j.connectedMarketplace,null);
});

test('kill switch reduces autonomy to recommend', async () => {
  const r = await fetch(base + '/api/kill-switch',{method:'POST'}); const j=await r.json();
  assert.equal(j.mode,'RECOMMEND'); assert.equal(j.killSwitch,true);
});

test('invalid autonomy mode rejected', async () => {
  const r = await fetch(base + '/api/mode',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({mode:'UNBOUNDED'})});
  assert.equal(r.status,400);
});

test('feature registry is readable', async () => {
  const r = await fetch(base + '/api/registry'); const j=await r.json();
  assert.ok(j.count >= 60); assert.equal(j.features[0].id,'LIP-001');
});

test('financial action is denied without human approval', async () => {
  const r = await fetch(base + '/api/policy/evaluate',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({actorType:'agent',agentId:'AG-GROWTH',action:'execute_refund',domain:'refunds',reversible:false,humanApproval:false,intentAligned:true,evidenceState:'CONFIRMED'})});
  const j=await r.json(); assert.equal(j.allowed,false); assert.ok(j.reasons.includes('HUMAN_APPROVAL_REQUIRED'));
});

test('untrusted seller content cannot reach protected sink', async () => {
  const r = await fetch(base + '/api/policy/evaluate',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({actorType:'agent',action:'execute_payment',domain:'payments',sourceLabels:['seller_content'],reversible:false,humanApproval:true,intentAligned:true,evidenceState:'CONFIRMED'})});
  const j=await r.json(); assert.equal(j.allowed,false); assert.ok(j.reasons.includes('UNTRUSTED_SOURCE_TO_PROTECTED_SINK_FORBIDDEN'));
});

test('low-risk reversible action can be allowed', async () => {
  const r = await fetch(base + '/api/policy/evaluate',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({actorType:'agent',action:'create_copy_experiment',domain:'experimentation',sourceLabels:['canonical_analytics'],reversible:true,humanApproval:false,intentAligned:true,evidenceState:'CONFIRMED'})});
  const j=await r.json(); assert.equal(j.allowed,true); assert.equal(j.decision,'ALLOW');
});

test('agent cannot self-modify governance', async () => {
  const r = await fetch(base + '/api/policy/evaluate',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({actorType:'agent',action:'modify_constitution',domain:'governance',reversible:false,humanApproval:true,intentAligned:true,evidenceState:'CONFIRMED'})});
  const j=await r.json(); assert.equal(j.allowed,false); assert.ok(j.reasons.includes('SELF_GOVERNANCE_FORBIDDEN'));
});

test('evidence engine distinguishes conflict from confirmation', async () => {
  const r = await fetch(base + '/api/evidence/resolve',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({claim:'warranty=24m',evidence:[
    {authority:'authoritative',observedAt:new Date().toISOString(),ttlHours:48,corroboratingSources:2,direct:true,supports:true},
    {authority:'verified_provider',observedAt:new Date().toISOString(),ttlHours:48,corroboratingSources:1,direct:true,supports:true}
  ]})});
  const j=await r.json(); assert.equal(j.state,'CONFIRMED'); assert.ok(j.confidence>0.5);
});

test('trust engine protects new sellers from false certainty', async () => {
  const r = await fetch(base + '/api/trust/evaluate',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({identity:95,fulfilment:95,catalogIntegrity:90,stockReliability:90,disputeHealth:95,safetyCompliance:95,evidenceQuality:90,sampleSize:2})});
  const j=await r.json(); assert.equal(j.band,'INSUFFICIENT_DATA');
});

test('mandate blocks spend above per-order limit', async () => {
  const r = await fetch(base + '/api/authorization/mandate',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({mandate:{id:'M1',principalId:'P1',actorId:'A1',capabilities:['purchase'],perOrderLimit:100,currency:'GBP',expiresAt:'2099-01-01T00:00:00Z'},action:{capability:'purchase',amount:125,currency:'GBP'}})});
  const j=await r.json(); assert.equal(j.allowed,false); assert.ok(j.reasons.includes('PER_ORDER_LIMIT_EXCEEDED'));
});

test('intent replay is denied', async () => {
  const r = await fetch(base + '/api/authorization/intent',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({intent:{id:'I1',type:'PURCHASE',nonce:'n-1',scope:['checkout'],expiresAt:'2099-01-01T00:00:00Z'},action:{scope:'checkout',replayedNonces:['n-1']}})});
  const j=await r.json(); assert.equal(j.allowed,false); assert.ok(j.reasons.includes('INTENT_REPLAY_DETECTED'));
});

test('immune engine escalates high coordinated-abuse risk without irreversible sanction', async () => {
  const r = await fetch(base + '/api/immune/assess',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({signals:{velocity:1,graphDensity:1,deviceOverlap:1,paymentRisk:.9,reviewAnomaly:1,promoLoop:.9,catalogIntegrity:.8,identityRisk:.8},signalCoverage:.9,sourceDiversity:.8})});
  const j=await r.json(); assert.ok(j.riskScore>.75); assert.equal(j.friction.irreversible,false); assert.equal(j.requiresHuman,true);
});

test('red-team baseline suite passes all protected scenarios', async () => {
  const r=await fetch(base+'/api/redteam/run',{method:'POST'}); const j=await r.json();
  assert.equal(j.total,12); assert.equal(j.failed,0); assert.equal(j.passRate,1);
});
