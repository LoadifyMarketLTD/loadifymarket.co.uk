'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const {server}=require('./server');
let base;
test.before(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));base=`http://127.0.0.1:${server.address().port}`;});
test.after(async()=>new Promise(r=>server.close(r)));

test('health exposes canonical configuration and registry provenance digests',async()=>{
 const r=await fetch(base+'/api/health');assert.equal(r.status,200);const j=await r.json();
 for(const k of ['runtimeConfigDigest','policyBundleDigest','connectorRegistryDigest','standardsRegistryDigest','apiContractDigest']){
   assert.match(j[k],/^[a-f0-9]{64}$/i,k);
 }
 assert.equal(j.externalLiveConnections,false);
});
