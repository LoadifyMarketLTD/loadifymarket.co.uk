'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const c=require('./lib/connector-security-engine');
const p=require('./lib/protocol-engine');
const D='a'.repeat(64), E='b'.repeat(64);

test('MCP admission allows pinned scoped server with immutable tool/schema evidence',()=>{
  const r=c.assessMcpServer({type:'MCP',serverId:'mcp.demo',endpoint:'https://mcp.example.com/rpc',pinnedOrigin:'https://mcp.example.com',toolsetDigest:D,schemaDigest:E,dynamicToolDiscovery:false,ambientCredentials:false,sessionBound:true,audienceBound:true,inputTaintTracking:true,resourceContentCanInstruct:false,promptContentCanEscalate:false,egressRestricted:true,auditEnabled:true});
  assert.equal(r.admit,true);assert.equal(r.decision,'ALLOW');
});

test('MCP admission denies unapproved toolset mutation',()=>{
  const r=c.assessMcpServer({type:'MCP',serverId:'mcp.demo',endpoint:'https://mcp.example.com/rpc',pinnedOrigin:'https://mcp.example.com',toolsetDigest:D,schemaDigest:E,previousToolsetDigest:'c'.repeat(64),changeApproved:false,dynamicToolDiscovery:false,ambientCredentials:false,sessionBound:true,audienceBound:true,inputTaintTracking:true,resourceContentCanInstruct:false,promptContentCanEscalate:false,egressRestricted:true,auditEnabled:true});
  assert.equal(r.decision,'DENY');assert.ok(r.reasons.includes('MCP_TOOLSET_CHANGED_UNAPPROVED'));
});

test('MCP admission denies ambient credentials and resource instruction confusion',()=>{
  const r=c.assessMcpServer({type:'MCP',serverId:'mcp.demo',endpoint:'https://mcp.example.com/rpc',pinnedOrigin:'https://mcp.example.com',toolsetDigest:D,schemaDigest:E,dynamicToolDiscovery:false,ambientCredentials:true,sessionBound:true,audienceBound:true,inputTaintTracking:true,resourceContentCanInstruct:true,promptContentCanEscalate:false,egressRestricted:true,auditEnabled:true});
  assert.equal(r.decision,'DENY');assert.ok(r.reasons.includes('MCP_AMBIENT_CREDENTIALS_FORBIDDEN'));assert.ok(r.reasons.includes('MCP_RESOURCE_INSTRUCTION_CONFUSION'));
});

test('UCP response capabilities include only root and extensions relevant to operation',()=>{
  const caps={
    'dev.ucp.shopping.checkout':{version:'2026-04-08'},
    'dev.ucp.shopping.cart':{version:'2026-04-08'},
    'dev.ucp.shopping.discount':{version:'2026-04-08',extends:'dev.ucp.shopping.checkout'},
    'dev.ucp.shopping.cart-note':{version:'2026-04-08',extends:'dev.ucp.shopping.cart'}
  };
  const r=p.responseCapabilitySelection({operation:'complete_checkout',negotiatedCapabilities:caps});
  assert.equal(r.ok,true);assert.deepEqual(Object.keys(r.capabilities).sort(),['dev.ucp.shopping.checkout','dev.ucp.shopping.discount'].sort());
});

test('UCP response capability selection fails closed when operation root is not negotiated',()=>{
  const r=p.responseCapabilitySelection({operation:'complete_checkout',negotiatedCapabilities:{'dev.ucp.shopping.cart':{version:'2026-04-08'}}});
  assert.equal(r.ok,false);assert.ok(r.reasons.includes('ROOT_CAPABILITY_NOT_NEGOTIATED'));
});
