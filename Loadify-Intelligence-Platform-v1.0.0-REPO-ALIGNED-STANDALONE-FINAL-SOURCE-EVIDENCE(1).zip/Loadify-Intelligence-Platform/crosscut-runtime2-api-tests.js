'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const {server}=require('./server');let base;
test.before(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));base=`http://127.0.0.1:${server.address().port}`});test.after(async()=>{await new Promise(r=>server.close(r));});
async function post(path,body){const r=await fetch(base+path,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});assert.equal(r.status,200);return r.json()}
test('privacy API classifies financial field',async()=>{const r=await post('/api/privacy/classify',{record:{x:'1'},fieldClasses:{x:'FINANCIAL'}});assert.equal(r.classification,'FINANCIAL')});
test('finops API attributes token cost',async()=>{const r=await post('/api/finops/usage-cost',{inputTokens:1000000,inputPerMillion:2});assert.equal(r.totalCost,2)});
test('event compatibility API detects breaking required field',async()=>{const r=await post('/api/events/schema/compatibility',{previous:{version:1,requiredFields:['id']},next:{version:2,requiredFields:['id','x']}});assert.equal(r.compatible,false)});
