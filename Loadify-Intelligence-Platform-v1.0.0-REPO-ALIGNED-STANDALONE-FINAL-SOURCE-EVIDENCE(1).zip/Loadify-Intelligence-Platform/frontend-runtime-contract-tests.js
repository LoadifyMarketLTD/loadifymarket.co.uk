'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const fs=require('fs');
const app=fs.readFileSync('./app.js','utf8');
test('front-end no longer stores autonomy state in localStorage',()=>{assert.equal(/localStorage\.setItem\(['\"]lip_mode/.test(app),false);assert.equal(/localStorage\.getItem\(['\"]lip_mode/.test(app),false);});
test('front-end hydrates control state from persistent runtime API',()=>{assert.match(app,/api\('\/api\/state'/);assert.match(app,/applyRuntime/);});
test('critical operator controls call server-side APIs',()=>{for(const route of ['/api/mode','/api/kill-switch','/api/experiments'])assert.ok(app.includes(route),route);assert.match(app,/\/api\/approvals\//);assert.match(app,/\/api\/agents\//);});
