'use strict';
const path=require('path');
const runtimeStartup=require('./lib/runtime-startup-engine');
const {defaultState,STATE_FILE,STATE_BACKUP_DIR,ROOT}=require('./server');

function run({verify=runtimeStartup.verifyRelease,write=true}={}){
  const result=verify({root:ROOT,defaults:defaultState,backupDir:STATE_BACKUP_DIR,stateFile:STATE_FILE});
  const summary={
    ok:result.ready===true,
    decision:result.decision,
    releaseDigest:result.releaseDigest||null,
    guardian:result.guardian?.gate||null,
    capabilities:result.guardian?.coverage?.features??null,
    attestedSuites:result.guardian?.coverage?.tests??null,
    storageHealthy:result.storage?.healthy===true,
    blockers:result.reasons||[]
  };
  if(write) console.log(JSON.stringify(summary,null,2));
  if(write && !result.ready) process.exitCode=1;
  return summary;
}
if(require.main===module)run();
module.exports={run};
