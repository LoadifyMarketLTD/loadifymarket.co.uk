'use strict';
const test=require('node:test'); const assert=require('node:assert/strict'); const http=require('node:http'); const {server}=require('./server');
let base; test.before(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));base=`http://127.0.0.1:${server.address().port}`}); test.after(async()=>{await new Promise(r=>server.close(r));});

test('POST API requiring body rejects non-JSON content type',async()=>{
  const r=await fetch(base+'/api/protocols/ucp/response-capabilities',{method:'POST',headers:{'content-type':'text/plain'},body:'{}'});
  assert.equal(r.status,415); assert.deepEqual(await r.json(),{error:'JSON_CONTENT_TYPE_REQUIRED'});
});

test('invalid JSON returns controlled 400 without internal detail',async()=>{
  const r=await fetch(base+'/api/protocols/ucp/response-capabilities',{method:'POST',headers:{'content-type':'application/json'},body:'{bad'});
  assert.equal(r.status,400); const b=await r.json(); assert.equal(b.error,'INVALID_JSON'); assert.equal('detail' in b,false);
});

test('declared oversized payload fails before parsing',async()=>{
  const port=server.address().port;
  const result=await new Promise((resolve,reject)=>{
    const req=http.request({host:'127.0.0.1',port,path:'/api/protocols/ucp/response-capabilities',method:'POST',headers:{'content-type':'application/json','content-length':'1000001'}},res=>{
      let body='';res.on('data',c=>body+=c);res.on('end',()=>resolve({status:res.statusCode,body}));
    });
    req.on('error',reject); req.end();
  });
  assert.equal(result.status,413); assert.equal(JSON.parse(result.body).error,'PAYLOAD_TOO_LARGE');
});
