'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const path=require('path');
const {server}=require('./server');
let base;
test.before(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));base=`http://127.0.0.1:${server.address().port}`;});
test.after(async()=>new Promise(r=>server.close(r)));

test('readiness health reports storage, release and isolation posture',async()=>{
 const r=await fetch(base+'/api/health');assert.equal(r.status,200);const j=await r.json();
 assert.equal(j.ok,true);assert.equal(j.environment,'standalone');assert.equal(j.storage.healthy,true);
 assert.ok(Number.isInteger(j.stateRevision));assert.ok(Number.isInteger(j.schemaVersion));
 assert.equal(j.externalLiveConnections,false);assert.equal(j.connectedMarketplace,null);
 const manifest=JSON.parse(fs.readFileSync(path.join(__dirname,'data/release-manifest.json'),'utf8'));
 assert.equal(j.releaseDigest,manifest.releaseDigest);
});
