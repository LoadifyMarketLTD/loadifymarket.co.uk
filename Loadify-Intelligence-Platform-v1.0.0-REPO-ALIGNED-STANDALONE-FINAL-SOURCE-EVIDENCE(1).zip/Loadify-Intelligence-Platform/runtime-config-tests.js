'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const c=require('./lib/runtime-config-engine');
test('standalone runtime is permanently loopback-bound',()=>{const r=c.runtimeConfig({PORT:'4173'});assert.equal(r.bindHost,'127.0.0.1');assert.equal(r.externalConnections,false);assert.equal(r.allowPublicBind,false);});
test('invalid low/public-service port is rejected',()=>{assert.throws(()=>c.parsePort('80'),/INVALID_PORT/);assert.throws(()=>c.parsePort('abc'),/INVALID_PORT/);});
test('non-loopback bind fails closed',()=>{const r=c.validateBindHost('0.0.0.0');assert.equal(r.allowed,false);assert.ok(r.reasons.includes('PUBLIC_OR_NON_LOOPBACK_BIND_FORBIDDEN'));});

test('standalone rejects application-scoped live credentials and modes',()=>{const x=c.validateStandaloneEnv({LIP_STRIPE_SECRET_KEY:'secret',LIP_EXTERNAL_CONNECTIONS:'true'});assert.equal(x.valid,false);assert.ok(x.reasons.some(r=>r.includes('LIP_STRIPE_SECRET_KEY')));assert.ok(x.reasons.includes('EXTERNAL_CONNECTIONS_MODE_FORBIDDEN'));assert.throws(()=>c.runtimeConfig({PORT:'4173',LIP_GITHUB_TOKEN:'token'}),/STANDALONE_CONFIG_DENIED/);});
