'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const s=require('./lib/simulation-engine');
test('synthetic marketplace snapshot is explicitly non-live and reproducible in metrics',()=>{const a=s.snapshot({seed:'x',scenario:'BALANCED'}),b=s.snapshot({seed:'x',scenario:'BALANCED'});assert.equal(a.live,false);assert.equal(a.provenance.kind,'SYNTHETIC');assert.deepEqual(a.metrics,b.metrics)});
test('stress scenario activates at least one guardrail',()=>{const x=s.snapshot({seed:'stress',scenario:'STRESS'});assert.ok(Object.values(x.guardrails).some(g=>g.status==='HOLD'))});
test('scenario compare returns four isolated snapshots',()=>{const x=s.compare({seed:'x'});assert.equal(x.length,4);assert.equal(new Set(x.map(v=>v.scenario)).size,4)});
