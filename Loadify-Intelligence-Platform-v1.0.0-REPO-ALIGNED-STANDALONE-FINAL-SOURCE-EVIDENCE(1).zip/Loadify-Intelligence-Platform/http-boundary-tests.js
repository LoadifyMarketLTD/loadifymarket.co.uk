'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const {server}=require('./server');
const runner=require('./test-runner');
const runtimeSnapshot=runner.snapshotRuntime();
let base,host;
test.before(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r)); host=`127.0.0.1:${server.address().port}`; base=`http://${host}`;});
test.after(async()=>{await new Promise(r=>server.close(r));runner.restoreRuntime(runtimeSnapshot);});

test('cross-site browser request is rejected before API execution',async()=>{
 const r=await fetch(`${base}/api/kill-switch`,{method:'POST',headers:{origin:'https://evil.example','sec-fetch-site':'cross-site','content-type':'application/json'},body:'{}'});
 assert.equal(r.status,403); assert.equal((await r.json()).error,'CROSS_SITE_REQUEST_DENIED');
});

test('same-origin API request remains allowed',async()=>{
 const r=await fetch(`${base}/api/health`,{headers:{origin:base,'sec-fetch-site':'same-origin'}}); assert.equal(r.status,200);
});

test('unsupported API methods fail closed',async()=>{
 const r=await fetch(`${base}/api/state`,{method:'PUT',headers:{'content-type':'application/json'},body:'{}'}); assert.equal(r.status,405);
});

test('API exposes hardened browser isolation headers',async()=>{
 const r=await fetch(`${base}/api/health`);
 assert.equal(r.headers.get('x-frame-options'),'DENY');
 assert.equal(r.headers.get('cross-origin-opener-policy'),'same-origin');
 assert.equal(r.headers.get('cross-origin-resource-policy'),'same-origin');
 assert.match(r.headers.get('permissions-policy')||'',/payment=\(\)/);
});

test('browser-like same-origin mutation requires local session cookie',async()=>{
 const r=await fetch(`${base}/api/kill-switch`,{method:'POST',headers:{origin:base,'sec-fetch-site':'same-origin','content-type':'application/json'},body:'{}'});
 assert.equal(r.status,401); assert.equal((await r.json()).error,'LOCAL_SESSION_REQUIRED');
});

test('loading the app establishes strict HttpOnly local session for browser mutations',async()=>{
 const home=await fetch(`${base}/`);
 const cookie=home.headers.get('set-cookie');
 assert.ok(cookie); assert.match(cookie,/LIP_LOCAL_SESSION=/); assert.match(cookie,/HttpOnly/i); assert.match(cookie,/SameSite=Strict/i);
 const pair=cookie.split(';')[0];
 const r=await fetch(`${base}/api/kill-switch`,{method:'POST',headers:{origin:base,'sec-fetch-site':'same-origin','content-type':'application/json',cookie:pair},body:'{}'});
 assert.equal(r.status,200);
});

test('non-loopback Host header is rejected to reduce DNS-rebinding surface',async()=>{
 const http=require('http');
 const result=await new Promise((resolve,reject)=>{const req=http.request({hostname:'127.0.0.1',port:server.address().port,path:'/api/health',method:'GET',headers:{Host:'attacker.example'}},res=>{let b='';res.on('data',c=>b+=c);res.on('end',()=>resolve({status:res.statusCode,body:JSON.parse(b)}));});req.on('error',reject);req.end();});
 assert.equal(result.status,403);assert.equal(result.body.error,'HOST_NOT_ALLOWED');
});
