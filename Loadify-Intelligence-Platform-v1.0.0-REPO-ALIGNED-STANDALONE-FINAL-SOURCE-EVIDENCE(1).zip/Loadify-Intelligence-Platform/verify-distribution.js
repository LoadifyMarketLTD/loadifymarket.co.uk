'use strict';
const fs=require('fs');
const path=require('path');
const crypto=require('crypto');
const cp=require('child_process');
function shaFile(file){return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');}
function shaValue(value){return crypto.createHash('sha256').update(value).digest('hex');}
function walk(dir,base=dir,out=[]){for(const ent of fs.readdirSync(dir,{withFileTypes:true})){const full=path.join(dir,ent.name);if(ent.isDirectory())walk(full,base,out);else out.push(path.relative(base,full).replaceAll(path.sep,'/'));}return out;}
function safeRelative(rel){return typeof rel==='string'&&rel.length>0&&!path.isAbsolute(rel)&&!rel.includes('\\')&&!rel.split('/').some(x=>x===''||x==='.'||x==='..');}
function verify(dir){
  dir=path.resolve(dir||''); const errors=[]; const mf=path.join(dir,'distribution-manifest.json');
  if(!fs.existsSync(mf))return {ok:false,errors:['DISTRIBUTION_MANIFEST_MISSING']};
  let m;try{m=JSON.parse(fs.readFileSync(mf,'utf8'));}catch{return {ok:false,errors:['DISTRIBUTION_MANIFEST_INVALID']};}
  if(!m||Array.isArray(m)||m.schemaVersion!==2||m.product!=='Loadify Intelligence Platform'||m.environment!=='standalone'||!/^[a-f0-9]{64}$/.test(String(m.releaseDigest||''))||!/^[a-f0-9]{64}$/.test(String(m.manifestDigest||'')))errors.push('DISTRIBUTION_MANIFEST_INVALID');
  const digestBody={...m};delete digestBody.manifestDigest;if(shaValue(JSON.stringify(digestBody))!==m.manifestDigest)errors.push('DISTRIBUTION_MANIFEST_DIGEST_MISMATCH');
  const declared=Object.keys(m.files||{}).sort();if(declared.length>2000)errors.push('DISTRIBUTION_FILE_COUNT_LIMIT_EXCEEDED');
  for(const rel of declared){
    if(!safeRelative(rel)){errors.push(`UNSAFE_FILE_PATH:${rel}`);continue;}
    const f=path.join(dir,rel);let stat;try{stat=fs.lstatSync(f);}catch{errors.push(`FILE_MISSING:${rel}`);continue;}
    if(!stat.isFile()||stat.isSymbolicLink()||stat.nlink!==1){errors.push(`UNSAFE_FILE_TYPE:${rel}`);continue;}
    if(shaFile(f)!==m.files[rel])errors.push(`FILE_DIGEST_MISMATCH:${rel}`);
  }
  const actual=walk(dir).filter(x=>x!=='distribution-manifest.json').sort();
  for(const rel of actual)if(!declared.includes(rel))errors.push(`UNDECLARED_FILE:${rel}`);
  for(const rel of declared)if(!actual.includes(rel))errors.push(`DECLARED_FILE_MISSING:${rel}`);
  for(const forbidden of ['data/runtime.lock','.env','.env.local','data/idempotency-store.json'])if(fs.existsSync(path.join(dir,forbidden)))errors.push(`FORBIDDEN_FILE:${forbidden}`);
  const backupDir=path.join(dir,'data','state-backups'); if(fs.existsSync(backupDir)&&fs.readdirSync(backupDir).length)errors.push('DEVELOPMENT_BACKUPS_PRESENT');
  const statePath=path.join(dir,'data','state.json'),seedPath=path.join(dir,'data','seed-state.json');
  if(!fs.existsSync(statePath)||!fs.existsSync(seedPath)||shaFile(statePath)!==shaFile(seedPath))errors.push('DISTRIBUTION_STATE_NOT_CANONICAL_SEED');
  if(!errors.length){const r=cp.spawnSync(process.execPath,['self-check.js'],{cwd:dir,encoding:'utf8',timeout:120_000,maxBuffer:8*1024*1024});if(r.status!==0||r.error)errors.push('DISTRIBUTION_SELF_CHECK_HOLD');}
  return {ok:errors.length===0,releaseDigest:m.releaseDigest||null,manifestDigest:m.manifestDigest||null,files:declared.length,errors:[...new Set(errors)]};
}
if(require.main===module){const r=verify(process.argv[2]);console.log(JSON.stringify(r));if(!r.ok)process.exitCode=1;}
module.exports={verify,safeRelative,walk};
