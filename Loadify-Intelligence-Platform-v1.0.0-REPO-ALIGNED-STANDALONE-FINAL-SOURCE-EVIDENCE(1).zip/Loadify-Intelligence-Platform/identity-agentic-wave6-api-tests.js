const test=require('node:test');const assert=require('node:assert/strict');const {server}=require('./server');let base;
test.before(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));base=`http://127.0.0.1:${server.address().port}`});test.after(()=>server.close());
async function post(p,b={}){const r=await fetch(base+p,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(b)});assert.equal(r.status,200);return r.json()}
test('selective disclosure minimizes claims',async()=>assert.equal(Object.keys((await post('/api/identity/selective-disclosure',{claims:{age:true,name:'x'},requiredClaims:['age']})).disclosed).length,1));
test('continuous auth fails step up',async()=>assert.equal((await post('/api/authorization/continuous',{sessionValid:true,policyStillAllows:true,credentialFresh:true,riskIncreased:true})).allowed,false));
test('sandbox refuses production',async()=>assert.equal((await post('/api/agentic/sandbox',{externalAgent:true,certification:'VALID',environment:'PROD'})).allowed,false));
test('financial provider boundary rejects raw card',async()=>assert.equal((await post('/api/financial/provider-boundary-v2',{providerAdapter:true,rawCardData:true})).allowed,false));
test('complexity budget stops overrun',async()=>assert.equal((await post('/api/reliability/complexity-budget',{limits:{steps:1},usage:{steps:2}})).allowed,false));
