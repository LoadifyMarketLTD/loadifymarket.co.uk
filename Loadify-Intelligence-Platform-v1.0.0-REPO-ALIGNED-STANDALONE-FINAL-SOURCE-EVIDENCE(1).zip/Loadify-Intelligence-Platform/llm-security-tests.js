'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const llm=require('./lib/llm-security-engine');

test('OWASP LLM Top 10 2026 posture contains all ten risks',()=>{
  const p=llm.posture(); assert.equal(p.length,10); assert.deepEqual(p.map(x=>x.id),['LLM01','LLM02','LLM03','LLM04','LLM05','LLM06','LLM07','LLM08','LLM09','LLM10']);
});
test('prompt injection fails closed',()=>{const r=llm.assess({promptInjectionDetected:true});assert.equal(r.decision,'DENY');assert.ok(r.triggeredRisks.includes('LLM01'));});
test('sensitive disclosure requires redaction',()=>{const r=llm.assess({sensitiveDataRequested:true,redactionApplied:false});assert.equal(r.decision,'DENY');assert.ok(r.triggeredRisks.includes('LLM02'));});
test('agent action requires bounded authorized capability',()=>{const r=llm.assess({agentAction:true,capabilityAuthorized:false});assert.equal(r.decision,'DENY');assert.ok(r.triggeredRisks.includes('LLM03'));});
test('unverified component is supply chain deny',()=>{const r=llm.assess({componentAdmission:true,sourceVerified:false,integrityVerified:true,versionPinned:true});assert.equal(r.decision,'DENY');assert.ok(r.triggeredRisks.includes('LLM04'));});
test('poisonable learning source is denied',()=>{const r=llm.assess({learningAdmission:true,sourceQualityVerified:true,poisoningScreenPassed:false});assert.equal(r.decision,'DENY');assert.ok(r.triggeredRisks.includes('LLM05'));});
test('model consumption requires budget and headroom',()=>{const r=llm.assess({modelInvocation:true,budgetConfigured:true,withinBudget:false});assert.equal(r.decision,'DENY');assert.ok(r.triggeredRisks.includes('LLM06'));});
test('unsupported commercial claim cannot pass as fact',()=>{const r=llm.assess({commercialClaim:true,evidenceBacked:false});assert.equal(r.decision,'REVIEW');assert.ok(r.triggeredRisks.includes('LLM07'));});
test('secrets in hidden context are denied',()=>{const r=llm.assess({systemPromptContainsSecrets:true});assert.equal(r.decision,'DENY');assert.ok(r.triggeredRisks.includes('LLM08'));});
test('vector retrieval requires tenant isolation and trusted source',()=>{const r=llm.assess({vectorRetrieval:true,tenantIsolationVerified:false,embeddingSourceTrusted:true});assert.equal(r.decision,'DENY');assert.ok(r.triggeredRisks.includes('LLM09'));});
test('downstream execution requires validated model output',()=>{const r=llm.assess({downstreamExecution:true,outputValidated:false});assert.equal(r.decision,'DENY');assert.ok(r.triggeredRisks.includes('LLM10'));});
test('fully bounded request is allowed',()=>{const r=llm.assess({agentAction:true,capabilityAuthorized:true,excessivePermissions:false,modelInvocation:true,budgetConfigured:true,withinBudget:true});assert.equal(r.decision,'ALLOW');});
