'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const {server}=require('./server');
let base;test.before(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));base=`http://127.0.0.1:${server.address().port}`});test.after(async()=>{await new Promise(r=>server.close(r));});
async function post(path,body){const r=await fetch(base+path,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});assert.equal(r.status,200);return r.json()}
test('skill admission endpoint denies unverified package',async()=>{const r=await post('/api/security/agent-skill/admission',{id:'x',version:'1',publisherId:'p',publisherVerified:true,signatureVerified:false,packageHashVerified:true});assert.equal(r.decision,'DENY');assert.ok(r.mappedRisks.includes('AST01'))});
test('skill drift endpoint quarantines permission drift',async()=>{const r=await post('/api/security/agent-skill/drift',{admittedFingerprint:'a',currentFingerprint:'a',permissionsChanged:true});assert.equal(r.decision,'QUARANTINE')});
