'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const fs=require('fs');const {server}=require('./server');
let base;test.before(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));base=`http://127.0.0.1:${server.address().port}`});test.after(async()=>{await new Promise(r=>server.close(r))});
test('integrity scope is explicit and does not overclaim tamper-proof security',async()=>{const r=await fetch(base+'/api/security/integrity-scope');assert.equal(r.status,200);const j=await r.json();assert.equal(j.claim,'TAMPER_EVIDENT_LOCAL_SCOPE_NOT_TAMPER_PROOF');assert.equal(j.externalAnchoring.enabled,false);assert.ok(j.doesNotGuarantee.includes('protection-from-privileged-local-filesystem-attacker'));});
test('Diagnostics consumes canonical integrity scope',()=>{const app=fs.readFileSync('./app.js','utf8');assert.match(app,/api\/security\/integrity-scope/);assert.match(app,/Integrity scope/);assert.doesNotMatch(app,/tamper-proof/i);});
