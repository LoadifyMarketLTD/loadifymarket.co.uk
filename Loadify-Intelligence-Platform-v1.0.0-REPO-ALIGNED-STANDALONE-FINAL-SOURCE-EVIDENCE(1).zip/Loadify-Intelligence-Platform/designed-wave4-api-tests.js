const test=require('node:test'); const assert=require('node:assert/strict'); const {server}=require('./server');
let base;
test.before(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r)); base=`http://127.0.0.1:${server.address().port}`});
test.after(()=>server.close());
async function post(path,body){const r=await fetch(base+path,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)}); assert.equal(r.status,200); return r.json()}
test('funnel API',async()=>{const r=await post('/api/analytics/funnel',{events:[{actorId:'a',type:'v'},{actorId:'a',type:'s'}],steps:['v','s']});assert.equal(r.conversion,1)});
test('catalog evidence API fails unsupported attribute',async()=>{const r=await post('/api/catalog/attributes/extract',{proposal:{warranty:'2y'},evidence:{}});assert.equal(r.canPublish,false)});
test('recall API finds affected item',async()=>{const r=await post('/api/safety/recall-graph-v2',{recall:{gtin:'g'},items:[{id:'1',gtin:'g'}]});assert.equal(r.count,1)});
test('delegation API scopes capability',async()=>{const r=await post('/api/authorization/delegation',{delegation:{principal:'p',actor:'a',expiresAt:'2099-01-01',capabilities:['read']},action:{principal:'p',actor:'a',capability:'pay'}});assert.equal(r.allowed,false)});
test('test integrity API blocks protected weakening',async()=>{const r=await post('/api/engineering/test-integrity-guard',{files:['payment.test.js'],skipsTests:true});assert.equal(r.allowed,false)});
test('circuit breaker API fails safe',async()=>{const r=await post('/api/reliability/circuit-breaker',{errorRate:.3,errorThreshold:.1});assert.equal(r.state,'OPEN')});
