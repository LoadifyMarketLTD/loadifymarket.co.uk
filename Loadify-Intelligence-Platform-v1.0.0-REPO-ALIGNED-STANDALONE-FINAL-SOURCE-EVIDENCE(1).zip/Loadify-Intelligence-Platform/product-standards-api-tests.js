'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const {server}=require('./server');
let base;
test.before(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));base=`http://127.0.0.1:${server.address().port}`});
test.after(async()=>{await new Promise(r=>server.close(r));});
async function post(path,body){const r=await fetch(base+path,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});assert.equal(r.status,200);return r.json();}
test('GS1 endpoint returns canonical 14 digit identity',async()=>{const r=await post('/api/standards/gs1-digital-link/readiness',{gtin:'4006381333931'});assert.equal(r.ready,true);assert.equal(r.gtin14,'04006381333931')});
test('DPP endpoint remains readiness-only and disconnected',async()=>{const r=await post('/api/standards/dpp/readiness',{productId:'p1',economicOperatorId:'op1',dataCarrierType:'QR',dataLocation:'x',accessPolicyRef:'a',dataModelRef:'m',integrityProofRef:'i',lifecycleOwner:'op1'});assert.equal(r.ready,true);assert.equal(r.externalConnection,false);assert.equal(r.mode,'READINESS_ONLY')});
test('DPP exposure endpoint fails closed',async()=>{const r=await post('/api/standards/dpp/marketplace-exposure',{dppRequired:true,dppReady:false,distanceSelling:true});assert.equal(r.allowed,false)});
