'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const crypto=require('crypto');
function digestJson(v){return crypto.createHash('sha256').update(JSON.stringify(v)).digest('hex');}
test('health contract exposes capability evidence provenance and honest scope counts',()=>{
  const server=fs.readFileSync('./server.js','utf8');
  const app=fs.readFileSync('./app.js','utf8');
  const registry=JSON.parse(fs.readFileSync('./data/feature-registry.json','utf8'));
  const index=JSON.parse(fs.readFileSync('./data/capability-evidence-index.json','utf8'));
  assert.match(server,/capabilityEvidenceIndexDigest/);
  assert.match(server,/capabilityEvidenceCoverage/);
  assert.match(app,/Capability evidence/);
  assert.match(app,/module-bundle/);
  const direct=registry.filter(x=>x.evidenceScope==='DIRECT').length;
  const moduleBundle=registry.filter(x=>x.evidenceScope==='MODULE_BUNDLE').length;
  assert.ok(direct>0);
  assert.ok(moduleBundle>0);
  assert.equal(direct+moduleBundle,registry.length);
  assert.equal(Object.keys(index.features).length,registry.length);
  assert.equal(digestJson(index).length,64);
});
