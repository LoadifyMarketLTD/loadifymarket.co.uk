'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const path=require('path');
const {server,loadState}=require('./server');
const statePath=path.join(__dirname,'data/state.json');
let base,original;
async function post(route,body){const r=await fetch(base+route,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});return {status:r.status,body:await r.json()};}

test.before(async()=>{original=fs.readFileSync(statePath);const s=JSON.parse(original);s.telemetry=[];fs.writeFileSync(statePath,JSON.stringify(s,null,2));await new Promise(r=>server.listen(0,'127.0.0.1',r));base=`http://127.0.0.1:${server.address().port}`;});
test.after(async()=>{await new Promise(r=>server.close(r));fs.writeFileSync(statePath,original);});

test('telemetry record persists with correlation and secret redaction',async()=>{
 const r=await post('/api/observability/record',{kind:'agent_call',traceId:'trace-1',correlationId:'order-7',payload:{model:'abstract',token:'secret',nested:{prompt:'hidden',safe:'ok'}}});
 assert.equal(r.status,201);assert.equal(r.body.traceId,'trace-1');assert.equal(r.body.correlationId,'order-7');
 assert.equal(r.body.payload.token,'[REDACTED]');assert.equal(r.body.payload.nested.prompt,'[REDACTED]');assert.equal(r.body.payload.nested.safe,'ok');
 const state=loadState();assert.equal(state.telemetry[0].id,r.body.id);assert.equal(state.telemetry[0].payload.token,'[REDACTED]');
});

test('recent telemetry endpoint returns persisted events and state revision',async()=>{
 const r=await fetch(base+'/api/observability/recent?limit=1');assert.equal(r.status,200);const j=await r.json();assert.equal(j.items.length,1);assert.ok(Number.isInteger(j.revision));assert.equal(j.items[0].traceId,'trace-1');
});
