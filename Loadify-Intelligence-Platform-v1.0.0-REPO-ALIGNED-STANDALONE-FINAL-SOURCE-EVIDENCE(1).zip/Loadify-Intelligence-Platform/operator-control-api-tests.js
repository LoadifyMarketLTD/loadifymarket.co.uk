'use strict';
const test=require('node:test'); const assert=require('node:assert/strict'); const {server}=require('./server');
let base;test.before(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));base=`http://127.0.0.1:${server.address().port}`});test.after(async()=>{await new Promise(r=>server.close(r));});
async function post(path,body){const r=await fetch(base+path,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});assert.equal(r.status,200);return r.json()}
test('operator approval endpoint blocks self approval',async()=>{const r=await post('/api/operator/approval/evaluate',{approval:{id:'a',status:'PENDING',requestedById:'u1',risk:'R2'},actor:{id:'u1',role:'APPROVER'},action:'APPROVE'});assert.equal(r.allowed,false)});
test('public trust endpoint hides internal risk',async()=>{const r=await post('/api/operator/trust-profile',{audience:'PUBLIC',profile:{entityId:'s1',verification:'VERIFIED',internalRisk:{x:1}}});assert.equal(r.profile.internalRisk,undefined)});
test('evidence view endpoint blocks wrong purpose',async()=>{const r=await post('/api/operator/evidence-view',{actor:{allowedPurposes:['support']},purpose:'fraud',evidence:[]});assert.equal(r.allowed,false)});
