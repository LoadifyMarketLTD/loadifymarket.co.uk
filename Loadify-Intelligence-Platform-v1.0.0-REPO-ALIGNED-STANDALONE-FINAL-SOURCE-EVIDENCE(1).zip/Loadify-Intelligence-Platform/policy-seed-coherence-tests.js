'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const path=require('path');
const policy=require('./lib/policy-bundle-engine').getPolicyBundle();

test('new standalone seed references the canonical policy bundle version',()=>{
  const seed=JSON.parse(fs.readFileSync(path.join(__dirname,'data/seed-state.json'),'utf8'));
  const expected=`${policy.id} ${policy.version}`;
  const systemEntry=(seed.audit||[]).find(x=>x.actor==='System');
  assert.ok(systemEntry);
  assert.equal(systemEntry.policy,expected);
});
