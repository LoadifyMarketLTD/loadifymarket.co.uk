'use strict';
const test=require('node:test'); const assert=require('node:assert/strict'); const fs=require('fs');
const rt=require('./lib/capability-runtime-spec-engine');
const registry=JSON.parse(fs.readFileSync('./data/feature-registry.json','utf8'));
const items=Array.isArray(registry)?registry:registry.features;
const generic=items.filter(x=>['CANONICAL_CONTRACT','OBSERVABILITY_AUDIT'].includes(rt.genericKind(x)));
test('all generic registered capabilities compile to complete canonical runtime specs',()=>{
 assert.ok(generic.length>=190);
 for(const f of generic){const r=rt.canonicalSpec(f);assert.equal(r.valid,true,`${f.id}: ${r.reasons}`);assert.ok(r.spec.owner);assert.ok(r.spec.api[0].path.includes(f.id));assert.equal(r.spec.audit.appendOnly,true);}
});
test('observability evidence rejects missing attribution and raw secrets',()=>{
 const f=generic[0]; const r=rt.observabilityAuditEvidence(f,{requestId:'R1',decision:'ALLOW',policyVersion:'P1',containsRawSecret:true});
 assert.equal(r.accepted,false);assert.ok(r.reasons.includes('ACTOR_REQUIRED'));assert.ok(r.reasons.includes('RAW_SECRET_FORBIDDEN'));
});
test('observability evidence records complete bounded event',()=>{
 const f=generic.find(x=>rt.genericKind(x)==='OBSERVABILITY_AUDIT')||generic[0]; const r=rt.observabilityAuditEvidence(f,{actor:'AG-TEST',requestId:'R2',decision:'ALLOW',policyVersion:'P1'});
 assert.equal(r.accepted,true);assert.equal(r.decision,'RECORDED');assert.equal(r.audit.featureId,f.id);assert.ok(r.trace.traceId);
});
test('R3 readiness requires rollback proof',()=>{
 const base=generic[0]; const f={...base,risk:'R3'}; const r=rt.readiness(f,{contractTestPassed:true,regressionPassed:true,apiProbePassed:true,auditProbePassed:true,rollbackProbePassed:false});
 assert.equal(r.ready,false);assert.ok(r.reasons.includes('ROLLBACK_PROBE_REQUIRED'));
});
test('portfolio compiles without owner/schema gaps',()=>{const r=rt.portfolio(generic);assert.equal(r.decision,'PASS');assert.equal(r.invalid,0);});
