'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const path=require('path');
const {server}=require('./server');
const statePath=path.join(__dirname,'data/state.json');
let base,original;

async function post(route,body){
  const r=await fetch(base+route,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body||{})});
  const text=await r.text();
  let json={};try{json=text?JSON.parse(text):{}}catch{}
  return {status:r.status,body:json};
}

test.before(async()=>{
  original=fs.readFileSync(statePath);
  const s=JSON.parse(original);
  s.flags=[{id:'FLAG-T',key:'test_flag',rollout:10,state:'PERCENTAGE'}];
  s.experiments=[];
  fs.writeFileSync(statePath,JSON.stringify(s,null,2));
  await new Promise(r=>server.listen(0,'127.0.0.1',r));
  base=`http://127.0.0.1:${server.address().port}`;
});
test.after(async()=>{await new Promise(r=>server.close(r));fs.writeFileSync(statePath,original);});

test('feature flag INTERNAL remains distinct from OFF at zero rollout',async()=>{
  let r=await post('/api/flags/FLAG-T',{state:'INTERNAL'});
  assert.equal(r.status,200);assert.equal(r.body.state,'INTERNAL');assert.equal(r.body.rollout,0);
  r=await post('/api/flags/FLAG-T',{state:'OFF'});
  assert.equal(r.status,200);assert.equal(r.body.state,'OFF');assert.equal(r.body.rollout,0);
});

test('percentage feature flag requires explicit positive rollout',async()=>{
  const r=await post('/api/flags/FLAG-T',{state:'PERCENTAGE',rollout:25});
  assert.equal(r.status,200);assert.equal(r.body.state,'PERCENTAGE');assert.equal(r.body.rollout,25);
});

test('experiment creation persists requested risk classification',async()=>{
  const r=await post('/api/experiments',{name:'Risk propagation test',type:'A/B/C',primaryMetric:'seller_activation',risk:'R3'});
  assert.equal(r.status,201);assert.equal(r.body.risk,'R3');assert.equal(r.body.type,'A/B/C');
});

test('invalid experiment risk fails safely to low-risk default',async()=>{
  const r=await post('/api/experiments',{name:'Invalid risk test',type:'A/B',primaryMetric:'conversion',risk:'R99'});
  assert.equal(r.status,201);assert.equal(r.body.risk,'R1');
});

test('front-end sends explicit flag state, experiment risk, and explains pending second approval',()=>{
  const source=fs.readFileSync(path.join(__dirname,'app.js'),'utf8');
  assert.match(source,/payload=raw==='OFF'\|\|raw==='INTERNAL'\?\{state:raw\}/);
  assert.match(source,/risk=document\.getElementById\('expRisk'\)\.value/);
  assert.match(source,/primaryMetric:metric,risk/);
  assert.match(source,/First approval recorded — distinct second approver still required/);
});
