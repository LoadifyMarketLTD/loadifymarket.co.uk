'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const http=require('http');
const {server,httpAdmission}=require('./server');

let port;
test.before(async()=>new Promise(r=>server.listen(0,'127.0.0.1',()=>{port=server.address().port;r();})));
test.after(async()=>new Promise(r=>server.close(r)));

function rawRequest(path,method='GET'){
  return new Promise((resolve,reject)=>{
    const req=http.request({host:'127.0.0.1',port,path,method},res=>{let text='';res.on('data',c=>text+=c);res.on('end',()=>resolve({status:res.statusCode,text,json:()=>JSON.parse(text||'{}')}));});
    req.on('error',reject);req.end();
  });
}

test('request target requires canonical origin-form and bounded ASCII characters',()=>{
  assert.equal(httpAdmission.validateRequestTarget('http://127.0.0.1/api/health').error,'ORIGIN_FORM_REQUIRED');
  assert.equal(httpAdmission.validateRequestTarget('/api/health x').error,'INVALID_REQUEST_TARGET_CHARACTER');
  assert.equal(httpAdmission.validateRequestTarget('/api/health#frag').error,'REQUEST_FRAGMENT_NOT_ALLOWED');
  assert.equal(httpAdmission.validateRequestTarget('/api/health\u00e9').error,'INVALID_REQUEST_TARGET_CHARACTER');
});

test('encoded and backslash path aliases are rejected before URL interpretation',async()=>{
  for(const candidate of ['/api/%68ealth','/api%2fhealth','/api\\health'])assert.equal(httpAdmission.validateRequestTarget(candidate).allowed,false);
  const r=await rawRequest('/api/%68ealth');assert.equal(r.status,400);assert.equal(r.json().error,'PERCENT_ENCODED_PATH_NOT_ALLOWED');
});

test('dot segments duplicate slashes path parameters and trailing slash fail closed',async()=>{
  assert.equal(httpAdmission.validateRequestTarget('/api/x/../health').error,'DOT_SEGMENT_NOT_ALLOWED');
  assert.equal(httpAdmission.validateRequestTarget('/api//health').error,'NON_CANONICAL_DUPLICATE_SLASH');
  assert.equal(httpAdmission.validateRequestTarget('/api/health;v=1').error,'PATH_PARAMETER_NOT_ALLOWED');
  assert.equal(httpAdmission.validateRequestTarget('/api/health/').error,'NON_CANONICAL_TRAILING_SLASH');
  const r=await rawRequest('/api/x/../health');assert.equal(r.status,400);assert.equal(r.json().error,'DOT_SEGMENT_NOT_ALLOWED');
});

test('query strings are denied unless the route has an explicit query contract',async()=>{
  const r=await rawRequest('/api/health?debug=true');assert.equal(r.status,400);assert.equal(r.json().error,'QUERY_NOT_ALLOWED_FOR_ROUTE');
  const staticResult=await rawRequest('/app.js?v=1');assert.equal(staticResult.status,400);assert.equal(staticResult.json().error,'QUERY_NOT_ALLOWED_FOR_ROUTE');
});

test('query syntax rejects empty malformed duplicate and form-style ambiguous parameters',()=>{
  assert.equal(httpAdmission.validateRequestTarget('/api/simulation/fixtures?').error,'EMPTY_QUERY_NOT_ALLOWED');
  assert.equal(httpAdmission.validateRequestTarget('/api/simulation/fixtures?seed').error,'MALFORMED_QUERY_PARAMETER');
  assert.equal(httpAdmission.validateRequestTarget('/api/simulation/fixtures?seed=a&seed=b').error,'DUPLICATE_QUERY_PARAMETER');
  assert.equal(httpAdmission.validateRequestTarget('/api/simulation/fixtures?seed=a+b').error,'AMBIGUOUS_QUERY_ENCODING');
});

test('query metadata is bounded by total bytes parameter count names and values',()=>{
  assert.equal(httpAdmission.validateRequestTarget('/api/simulation/fixtures?seed='+('a'.repeat(300))).error,'QUERY_VALUE_TOO_LARGE');
  const tooMany=Array.from({length:9},(_,i)=>`x${i}=1`).join('&');
  assert.equal(httpAdmission.validateRequestTarget('/api/simulation/fixtures?'+tooMany).error,'QUERY_PARAMETER_COUNT_EXCEEDED');
  const custom={...httpAdmission.DEFAULT_LIMITS,maxQueryBytes:5};
  assert.equal(httpAdmission.validateRequestTarget('/api/simulation/fixtures?seed=a',{limits:custom}).error,'QUERY_TOO_LARGE');
});

test('each query route exposes only its declared parameters',async()=>{
  assert.equal(httpAdmission.validateRequestTarget('/api/simulation/fixtures?days=30').error,'QUERY_PARAMETER_NOT_ALLOWED');
  assert.equal(httpAdmission.validateRequestTarget('/api/observability/recent?seed=x').error,'QUERY_PARAMETER_NOT_ALLOWED');
  const r=await rawRequest('/api/simulation/compare?scenario=STRESS');assert.equal(r.status,400);assert.equal(r.json().error,'QUERY_PARAMETER_NOT_ALLOWED');
});

test('simulation seed values are bounded and canonical',async()=>{
  assert.equal(httpAdmission.validateRequestTarget('/api/simulation/fixtures?seed=').error,'INVALID_SEED_QUERY');
  assert.equal(httpAdmission.validateRequestTarget('/api/simulation/fixtures?seed=a%20b').error,'INVALID_SEED_QUERY');
  assert.equal(httpAdmission.validateRequestTarget('/api/simulation/fixtures?seed='+('a'.repeat(129))).error,'INVALID_SEED_QUERY');
  const r=await rawRequest('/api/simulation/fixtures?seed=fixture-2026');assert.equal(r.status,200);assert.equal(r.json().seed,'fixture-2026');
});

test('simulation scenario and day windows are explicit finite contracts',async()=>{
  for(const bad of ['balanced','UNKNOWN','STRESS%00'])assert.equal(httpAdmission.validateRequestTarget('/api/simulation/snapshot?scenario='+bad).allowed,false);
  for(const bad of ['0','366','01','1.5','NaN'])assert.equal(httpAdmission.validateRequestTarget('/api/simulation/snapshot?days='+bad).error,'INVALID_DAYS_QUERY');
  const r=await rawRequest('/api/simulation/snapshot?scenario=STRESS&days=365&seed=target-test');assert.equal(r.status,200);const j=r.json();assert.equal(j.scenario,'STRESS');assert.equal(j.windowDays,365);
});

test('observability limit is canonical and request-target posture is observable',async()=>{
  for(const bad of ['0','201','01','1.2','Infinity'])assert.equal(httpAdmission.validateRequestTarget('/api/observability/recent?limit='+bad).error,'INVALID_LIMIT_QUERY');
  const ok=await rawRequest('/api/observability/recent?limit=1');assert.equal(ok.status,200);assert.ok(Array.isArray(ok.json().items));
  const posture=await rawRequest('/api/security/http-admission/posture');assert.equal(posture.status,200);const p=posture.json();assert.equal(p.policies.requestTarget,'CANONICAL_ORIGIN_FORM_ONLY');assert.equal(p.policies.queryParameters,'ROUTE_AND_FIELD_ALLOWLIST');assert.ok(p.queryRoutes.includes('/api/observability/recent'));
});
