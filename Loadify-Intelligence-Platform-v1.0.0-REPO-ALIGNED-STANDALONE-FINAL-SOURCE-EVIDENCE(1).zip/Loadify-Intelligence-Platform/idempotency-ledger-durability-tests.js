'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const crypto=require('crypto');
const fs=require('fs');
const os=require('os');
const path=require('path');
const {createIdempotencyStore}=require('./lib/idempotency-engine');
const DIGEST='a'.repeat(64);
const hash=entries=>crypto.createHash('sha256').update(JSON.stringify(entries)).digest('hex');
function fixture(prefix='lip-idem-ledger-'){const dir=fs.mkdtempSync(path.join(os.tmpdir(),prefix));return{dir,file:path.join(dir,'store.json'),cleanup:()=>fs.rmSync(dir,{recursive:true,force:true})};}
function seed(file,key='KEY',now=Date.now()){const store=createIdempotencyStore({file,ttlMs:60_000});store.preflight({key,method:'POST',path:'/x',payloadDigest:DIGEST,scope:'P1',now});store.complete({key,status:201,body:{ok:true},now:now+1});return now;}
function rewrite(file,change){const body=JSON.parse(fs.readFileSync(file,'utf8'));change(body);body.integrity.entriesDigest=hash(body.entries);fs.writeFileSync(file,JSON.stringify(body));}
test('persistent ledger uses schema v2 and an embedded SHA-256 digest',()=>{const x=fixture();try{seed(x.file);const body=JSON.parse(fs.readFileSync(x.file));assert.equal(body.schemaVersion,2);assert.equal(body.integrity.algorithm,'SHA-256');assert.equal(body.integrity.entriesDigest,hash(body.entries));assert.equal(createIdempotencyStore({file:x.file}).posture().integrity,'EMBEDDED_SHA_256')}finally{x.cleanup()}});
test('payload tampering without digest renewal fails closed',()=>{const x=fixture();try{seed(x.file);const body=JSON.parse(fs.readFileSync(x.file));body.entries[0].body.ok=false;fs.writeFileSync(x.file,JSON.stringify(body));assert.throws(()=>createIdempotencyStore({file:x.file}),/IDEMPOTENCY_STORE_INTEGRITY_MISMATCH/)}finally{x.cleanup()}});
test('a symlink replay ledger is rejected',()=>{const x=fixture();try{const target=path.join(x.dir,'target.json');seed(target);fs.symlinkSync(target,x.file);assert.throws(()=>createIdempotencyStore({file:x.file}),/IDEMPOTENCY_STORE_UNSAFE_FILE_TYPE/)}finally{x.cleanup()}});
test('atomic persistence leaves an owner-only ledger and no temporary residue',()=>{const x=fixture();try{seed(x.file);if(process.platform!=='win32')assert.equal(fs.statSync(x.file).mode&0o777,0o600);assert.deepEqual(fs.readdirSync(x.dir),['store.json'])}finally{x.cleanup()}});
test('duplicate persisted keys are rejected even with a valid digest',()=>{const x=fixture();try{seed(x.file);rewrite(x.file,b=>b.entries.push({...b.entries[0]}));assert.throws(()=>createIdempotencyStore({file:x.file}),/IDEMPOTENCY_STORE_DUPLICATE_KEY/)}finally{x.cleanup()}});
test('persisted keys must satisfy the runtime key policy',()=>{const x=fixture();try{seed(x.file);rewrite(x.file,b=>{b.entries[0].key='bad key'});assert.throws(()=>createIdempotencyStore({file:x.file}),/IDEMPOTENCY_STORE_INVALID/)}finally{x.cleanup()}});
test('persisted fingerprints must be canonical lowercase SHA-256 values',()=>{const x=fixture();try{seed(x.file);rewrite(x.file,b=>{b.entries[0].fingerprint='A'.repeat(64)});assert.throws(()=>createIdempotencyStore({file:x.file}),/IDEMPOTENCY_STORE_INVALID/)}finally{x.cleanup()}});
test('persisted timestamps, states, statuses and fields are structurally strict',()=>{for(const mutate of [e=>e.at=-1,e=>e.state='IN_FLIGHT',e=>e.status=500,e=>{e.extra=true}]){const x=fixture();try{seed(x.file);rewrite(x.file,b=>mutate(b.entries[0]));assert.throws(()=>createIdempotencyStore({file:x.file}),/IDEMPOTENCY_STORE_INVALID/)}finally{x.cleanup()}}});
test('oversized persisted ledgers fail closed before admission',()=>{const x=fixture();try{seed(x.file);rewrite(x.file,b=>b.entries.push({...b.entries[0],key:'KEY2'}));assert.throws(()=>createIdempotencyStore({file:x.file,maxEntries:1}),/IDEMPOTENCY_STORE_ENTRY_LIMIT_EXCEEDED/)}finally{x.cleanup()}});
test('expired records are deterministically pruned and rewritten after restart',()=>{const x=fixture();try{const old=Date.now()-120_000;seed(x.file,'OLD',old);createIdempotencyStore({file:x.file,ttlMs:60_000});const body=JSON.parse(fs.readFileSync(x.file));assert.deepEqual(body.entries,[]);assert.equal(body.integrity.entriesDigest,hash([]))}finally{x.cleanup()}});
