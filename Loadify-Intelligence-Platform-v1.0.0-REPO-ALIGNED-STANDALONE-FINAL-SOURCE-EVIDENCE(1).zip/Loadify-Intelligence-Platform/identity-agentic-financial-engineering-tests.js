'use strict';
const test=require('node:test'); const assert=require('node:assert/strict');
const identity=require('./lib/identity-engine');
const agentic=require('./lib/agentic-commerce-engine');
const finance=require('./lib/financial-firewall-engine');
const eng=require('./lib/engineering-intelligence-engine');

test('expired credential fails closed',()=>{const r=identity.validateCredential({id:'c',subjectId:'u',issuer:'trusted',expiresAt:'2020-01-01',integrityVerified:true},{subjectId:'u',allowedIssuers:['trusted'],now:'2026-08-20'});assert.equal(r.valid,false);});
test('high assurance action rejects low assurance actor',()=>{const r=identity.authorizeIdentity({actor:{id:'u',type:'human',assurance:'LOW'},requiredAssurance:'HIGH'});assert.equal(r.allowed,false);assert.ok(r.reasons.includes('ASSURANCE_LEVEL_TOO_LOW'));});
test('capability discovery returns only policy approved intersection',()=>{const r=agentic.discoverCapabilities({businessCapabilities:['catalog.read','checkout.complete'],platformCapabilities:['catalog.read','checkout.complete'],policyAllowed:['catalog.read']});assert.deepEqual(r.capabilities,['catalog.read']);});
test('financial action requires approval verified adapter and isolation',()=>{const r=finance.assessFinancialAction({operation:'payment.refund',modelInitiated:true,providerAdapter:'VERIFIED',idempotencyKey:'i',traceId:'t',authorizationRef:'a'});assert.equal(r.allowed,false);assert.ok(r.reasons.includes('HUMAN_APPROVAL_REQUIRED'));assert.ok(r.reasons.includes('MODEL_CANNOT_EXECUTE_FINANCIAL_ACTION'));});
test('financial credentials exposed to agent are denied',()=>{assert.equal(finance.assessFinancialAction({operation:'analytics.read',credentialsExposedToAgent:true}).allowed,false);});
test('engineering changes cannot target main or bypass sandbox',()=>{const r=eng.planChange({issueId:'I-1',branch:'main',sandbox:false});assert.equal(r.allowed,false);assert.ok(r.reasons.includes('ISOLATED_BRANCH_REQUIRED'));});
test('protected engineering domain requires human approval',()=>{const r=eng.planChange({issueId:'I-1',branch:'feat/x',sandbox:true,domains:['payments']});assert.equal(r.allowed,false);});
test('deployment gate requires exact diff and tests',()=>{const r=eng.deploymentGate({unit:true,integration:true,security:true,staging:true,canaryPlan:true,exactDiffReviewed:false});assert.equal(r.pass,false);});
test('test integrity detects weakening protected tests',()=>{const r=eng.evaluateTestIntegrity({testsBefore:100,testsAfter:100,protectedTestsChanged:true});assert.equal(r.healthy,false);});
