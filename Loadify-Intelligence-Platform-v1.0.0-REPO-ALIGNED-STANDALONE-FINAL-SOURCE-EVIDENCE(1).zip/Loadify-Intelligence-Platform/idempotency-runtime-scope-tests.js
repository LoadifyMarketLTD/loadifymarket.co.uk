'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const src=fs.readFileSync(path.join(__dirname,'server.js'),'utf8');
const {createIdempotencyStore}=require('./lib/idempotency-engine');

test('runtime idempotency scope is release-stable by local principal class rather than ephemeral session secret',()=>{
  assert.match(src,/replayScope:releaseReplayScope\('BROWSER'\)/);
  assert.match(src,/replayScope:releaseReplayScope\('TOOLING'\)/);
  assert.match(src,/scope:\(principal\.replayScope\|\|principal\.id\)/);
});

test('idempotency posture declares the stable principal binding model while retaining required binding',()=>{
  const p=createIdempotencyStore().posture();assert.equal(p.principalBinding,'REQUIRED');assert.equal(p.principalBindingModel,'LOCAL_PRINCIPAL_CLASS_AND_RELEASE');
});
