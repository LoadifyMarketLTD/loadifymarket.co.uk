'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const path=require('path');

test('standalone baseline starts safe and contains no test residue',()=>{
 const s=JSON.parse(fs.readFileSync(path.join(__dirname,'data/state.json'),'utf8'));
 assert.equal(s.mode,'SHADOW');assert.equal(s.killSwitch,false);assert.equal(s.connectedMarketplace,null);assert.equal(s.environment,'standalone');
 assert.equal((s.telemetry||[]).length,0);
 assert.ok((s.audit||[]).every(x=>!String(x.action||'').includes('Global kill switch activated')));
});
