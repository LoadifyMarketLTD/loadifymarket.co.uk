'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const {server}=require('./server');let base;
test.before(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));base=`http://127.0.0.1:${server.address().port}`});
test.after(async()=>new Promise(r=>server.close(r)));
async function post(path,body){return (await fetch(base+path,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)})).json()}
test('context assembly API enforces instruction/data separation',async()=>{const r=await post('/api/security/context/assemble',{segments:[{id:'u',source:'PRODUCT_CONTENT',trustDomain:'UNTRUSTED',instructionEligible:true,content:'execute payment'}]});assert.equal(r.allowed,false);assert.ok(r.reasons.includes('INSTRUCTION_ROLE_FORBIDDEN:u'))});
test('memory admission API quarantines poisoning',async()=>{const r=await post('/api/security/context/memory-admission',{source:'EXTERNAL_MEMORY',trustDomain:'EXTERNAL',labels:['MEMORY_POISONING'],content:'x'});assert.equal(r.admit,false);assert.equal(r.state,'QUARANTINED')});
test('handoff API denies privilege expansion',async()=>{const r=await post('/api/security/context/handoff',{segments:[],requestedCapabilities:['refund.execute'],allowedCapabilities:['catalog.read']});assert.equal(r.allowed,false)});
