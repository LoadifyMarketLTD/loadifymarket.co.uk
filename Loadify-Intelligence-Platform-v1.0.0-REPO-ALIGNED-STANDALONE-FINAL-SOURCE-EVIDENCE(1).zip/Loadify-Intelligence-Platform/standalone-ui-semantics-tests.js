'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const fs=require('fs');
const app=fs.readFileSync('./app.js','utf8');
test('UI distinguishes real standalone runtime from synthetic marketplace data',()=>{
 assert.match(app,/Standalone Control Plane — Local Runtime/);
 assert.match(app,/SYNTHETIC MARKETPLACE DATA — NO LIVE MARKETPLACE CONNECTION/);
 assert.doesNotMatch(app,/Standalone Control Plane — Demo/);
 assert.doesNotMatch(app,/DEMO DATA — NOT CONNECTED TO LOADIFY MARKET/);
 assert.doesNotMatch(app,/demo trend|Weighted demo|Demo catalog|EU schema demo|\+6\.2% demo/);
});
