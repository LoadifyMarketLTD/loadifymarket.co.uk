'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const path=require('path');

test('agent registry UI renders runtime agent records when available',()=>{
 const src=fs.readFileSync(path.join(__dirname,'app.js'),'utf8');
 assert.match(src,/function agentRows\(\)/);
 assert.match(src,/if\(!state\.agentRecords\.length\)return \[\]/);
 assert.doesNotMatch(src,/fallbackAgents/);
 assert.match(src,/return state\.agentRecords\.map/);
 assert.match(src,/const rows=agentRows\(\)/);
 assert.match(src,/const a=agentRows\(\)\[state\.drawer\.i\]/);
});
