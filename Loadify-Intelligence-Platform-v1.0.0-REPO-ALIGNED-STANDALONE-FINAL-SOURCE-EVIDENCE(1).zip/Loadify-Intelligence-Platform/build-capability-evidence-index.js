'use strict';
const fs=require('fs');
const path=require('path');
const crypto=require('crypto');
const {BUNDLES}=require('./lib/capability-evidence-bundles');
const ROOT=__dirname;
const REGISTRY=path.join(ROOT,'data/feature-registry.json');
const OUTPUT=path.join(ROOT,'data/capability-evidence-index.json');
function sha256(v){return crypto.createHash('sha256').update(v).digest('hex');}
function stable(v){
  if(Array.isArray(v)) return v.map(stable);
  if(v&&typeof v==='object') return Object.fromEntries(Object.keys(v).sort().map(k=>[k,stable(v[k])]));
  return v;
}
function buildIndex(registry){
  if(!Array.isArray(registry)) throw new Error('FEATURE_REGISTRY_INVALID');
  const byModule=new Map(Object.entries(BUNDLES).map(([id,b])=>[b.module,{id,bundle:b}]));
  const features={};
  const directBundles={};
  for(const feature of registry){
    if(!feature||!feature.id||!feature.module) throw new Error('FEATURE_ID_OR_MODULE_MISSING');
    if(feature.evidenceScope==='DIRECT'){
      if(!Array.isArray(feature.verificationRefs)||feature.verificationRefs.length===0) throw new Error(`DIRECT_EVIDENCE_REFS_MISSING:${feature.id}`);
      const id=`DIRECT-${feature.id}`;
      directBundles[id]={module:feature.module,verificationRefs:[...feature.verificationRefs],scope:'DIRECT'};
      features[feature.id]=id;
      continue;
    }
    if(feature.evidenceScope!=='MODULE_BUNDLE') throw new Error(`EVIDENCE_SCOPE_INVALID:${feature.id}`);
    const found=byModule.get(feature.module);
    if(!found) throw new Error(`MODULE_BUNDLE_MISSING:${feature.module}:${feature.id}`);
    if(JSON.stringify(feature.verificationRefs||[])!==JSON.stringify(found.bundle.verificationRefs||[])) throw new Error(`MODULE_BUNDLE_REFS_DRIFT:${feature.id}`);
    features[feature.id]=found.id;
  }
  const bundles={...BUNDLES,...directBundles};
  const core={schemaVersion:1,policy:'MODULE_BUNDLE_IS_VALID_EVIDENCE_SCOPE_BUT_NOT_DEDICATED_FEATURE_TEST',bundles,features};
  const canonical=JSON.stringify(stable(core));
  return {...core,indexDigest:sha256(canonical)};
}
function serialize(index){return JSON.stringify(index,null,2)+'\n';}
function main(){
  const registry=JSON.parse(fs.readFileSync(REGISTRY,'utf8'));
  const index=buildIndex(registry);
  const text=serialize(index);
  const check=process.argv.includes('--check');
  if(check){
    if(!fs.existsSync(OUTPUT)||fs.readFileSync(OUTPUT,'utf8')!==text){console.error('CAPABILITY_EVIDENCE_INDEX_DRIFT');process.exitCode=1;return;}
    console.log(JSON.stringify({ok:true,features:Object.keys(index.features).length,bundles:Object.keys(index.bundles).length,indexDigest:index.indexDigest}));return;
  }
  fs.writeFileSync(OUTPUT,text);
  console.log(JSON.stringify({features:Object.keys(index.features).length,bundles:Object.keys(index.bundles).length,indexDigest:index.indexDigest}));
}
if(require.main===module)main();
module.exports={buildIndex,serialize,stable};
