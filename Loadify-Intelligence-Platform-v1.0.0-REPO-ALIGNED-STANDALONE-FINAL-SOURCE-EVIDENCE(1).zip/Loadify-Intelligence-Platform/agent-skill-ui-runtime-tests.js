'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const fs=require('fs');const {server}=require('./server');
let base;test.before(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));base=`http://127.0.0.1:${server.address().port}`});test.after(async()=>new Promise(r=>server.close(r)));
test('agent skill posture endpoint exposes fail-closed standalone posture',async()=>{const r=await fetch(base+'/api/security/agent-skills/posture');assert.equal(r.status,200);const j=await r.json();assert.equal(j.externalInstallEnabled,false);assert.equal(j.admissionMode,'FAIL_CLOSED');assert.equal(j.risks.length,10)});
test('Agents UI consumes runtime skill posture',()=>{const s=fs.readFileSync('./app.js','utf8');assert.match(s,/api\/security\/agent-skills\/posture/);assert.match(s,/Agent Skill Security/);assert.match(s,/externalInstallEnabled/)});
