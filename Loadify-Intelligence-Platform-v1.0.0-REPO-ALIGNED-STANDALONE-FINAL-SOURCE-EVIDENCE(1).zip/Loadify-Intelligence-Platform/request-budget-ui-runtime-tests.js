'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const fs=require('fs');const app=fs.readFileSync('./app.js','utf8');
test('UI hydrates request budget posture from runtime',()=>{assert.match(app,/api\/security\/request-budget\/posture/);assert.match(app,/state\.requestBudget=requestBudget/)});
test('Diagnostics renders request budget limits and fail mode',()=>{assert.match(app,/Runtime request budget/);assert.match(app,/budget\.policy\?\.readLimit/);assert.match(app,/budget\.failMode/)});
