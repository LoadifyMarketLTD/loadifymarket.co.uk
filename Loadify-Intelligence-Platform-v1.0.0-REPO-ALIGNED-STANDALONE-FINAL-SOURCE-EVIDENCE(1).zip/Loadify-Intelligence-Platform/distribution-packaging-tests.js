'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const path=require('path');
const ROOT=__dirname;

test('distribution builder is allowlist-driven and excludes mutable development artifacts',()=>{
 const src=fs.readFileSync(path.join(ROOT,'build-distribution.js'),'utf8');
 assert.match(src,/release\.artifacts/);
 assert.match(src,/release\.testSuiteDigests/);
 assert.match(src,/seed-state\.json/);
 assert.match(src,/state-backups/);
 assert.doesNotMatch(src,/copyFileSync\(path\.join\(DATA,'state\.json'/);
});

test('distribution verifier requires canonical seed and empty development backup set',()=>{
 const src=fs.readFileSync(path.join(ROOT,'verify-distribution.js'),'utf8');
 assert.match(src,/DISTRIBUTION_STATE_NOT_CANONICAL_SEED/);
 assert.match(src,/DEVELOPMENT_BACKUPS_PRESENT/);
 assert.match(src,/DISTRIBUTION_SELF_CHECK_HOLD/);
});
