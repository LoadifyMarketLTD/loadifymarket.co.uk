'use strict';
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const ROOT=__dirname;function hashFile(f){return crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex')}
const source=['server.js','app.js','styles.css','index.html','package.json','README.md','self-check.js','launch-loadify-intelligence.cmd','launch-loadify-intelligence.sh','build-distribution.js','verify-distribution.js','final-audit.js','final-completeness.js','build-capability-evidence-index.js','build-release-manifest.js','run-release-gate.js','test-runner.js','test-all.js',...fs.readdirSync(path.join(ROOT,'lib')).filter(x=>x.endsWith('.js')).sort().map(x=>'lib/'+x)];
const registry=JSON.parse(fs.readFileSync(path.join(ROOT,'data/feature-registry.json'),'utf8'));
const testSuiteFiles=fs.readdirSync(ROOT).filter(x=>x.endsWith('tests.js')).sort();
const testSuites=testSuiteFiles.length;
const testSuiteDigests=Object.fromEntries(testSuiteFiles.map(f=>[f,hashFile(path.join(ROOT,f))]));
const manifest={schemaVersion:1,product:'Loadify Intelligence Platform',releaseChannel:'standalone-final',environment:'standalone',connectedMarketplace:null,generatedAt:new Date().toISOString(),coverage:{features:Array.isArray(registry)?registry.length:0,testSuites},testSuiteDigests,artifacts:{},registries:{featureRegistry:hashFile(path.join(ROOT,'data/feature-registry.json')),standardsRegistry:hashFile(path.join(ROOT,'data/standards-registry.json')),threatCatalog:hashFile(path.join(ROOT,'data/threat-catalog.json')),systemManifest:hashFile(path.join(ROOT,'data/system-manifest.json')),capabilityEvidenceIndex:hashFile(path.join(ROOT,'data/capability-evidence-index.json')),loadifyMarketCompatibilityContract:hashFile(path.join(ROOT,'data/loadify-market-compatibility-contract.json')),seedState:hashFile(path.join(ROOT,'data/seed-state.json'))},externalLiveConnections:false};
for(const f of source)manifest.artifacts[f]=hashFile(path.join(ROOT,f));
const canonical=JSON.stringify({...manifest,generatedAt:null});manifest.releaseDigest=crypto.createHash('sha256').update(canonical).digest('hex');
fs.writeFileSync(path.join(ROOT,'data/release-manifest.json'),JSON.stringify(manifest,null,2)+'\n');console.log(manifest.releaseDigest);
