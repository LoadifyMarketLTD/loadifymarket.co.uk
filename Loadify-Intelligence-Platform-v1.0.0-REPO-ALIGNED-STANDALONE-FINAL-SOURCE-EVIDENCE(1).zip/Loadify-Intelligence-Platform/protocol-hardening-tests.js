'use strict';
const test=require('node:test'); const assert=require('node:assert/strict'); const p=require('./lib/protocol-engine');
const checkout={version:'2026-04-08',spec:'https://ucp.dev/2026-04-08/specification/checkout',schema:'https://ucp.dev/2026-04-08/schemas/checkout.json'};
test('UCP strict profile accepts namespace-aligned schema and spec',()=>{const r=p.validateProfile({version:'2026-04-08',capabilities:{'dev.ucp.shopping.checkout':[checkout]}},{strictSchemas:true});assert.equal(r.valid,true)});
test('UCP strict profile rejects namespace-confused schema',()=>{const r=p.validateProfile({version:'2026-04-08',capabilities:{'dev.ucp.shopping.checkout':[{...checkout,schema:'https://evil.example/schema.json'}]}},{strictSchemas:true});assert.equal(r.valid,false);assert.ok(r.reasons.some(x=>x.includes('CAPABILITY_SCHEMA_NAMESPACE_MISMATCH')))});
test('required capability fails closed when versions do not intersect',()=>{const r=p.negotiateUcp({business:{version:'2026-04-08',capabilities:{'dev.ucp.shopping.checkout':[checkout]}},platform:{version:'2026-04-08',capabilities:{'dev.ucp.shopping.checkout':[ {...checkout,version:'2026-01-23'}]}},requiredCapabilities:['dev.ucp.shopping.checkout']});assert.equal(r.ok,false);assert.ok(r.reasons.includes('CAPABILITY_INCOMPATIBLE:dev.ucp.shopping.checkout'))});
test('schema resolution requires negotiated root and schema refs',()=>{const r=p.schemaResolutionPlan({operation:'create_checkout',negotiatedCapabilities:{'dev.ucp.shopping.checkout':{version:'2026-04-08',schema:'https://ucp.dev/schema.json'}}});assert.equal(r.ready,true);assert.equal(r.rootCapability,'dev.ucp.shopping.checkout')});
test('extension without parent is excluded',()=>{const r=p.negotiateUcp({business:{version:'2026-04-08',capabilities:{'dev.ucp.shopping.discount':[{version:'2026-04-08',extends:'dev.ucp.shopping.checkout'}]}},platform:{version:'2026-04-08',capabilities:{'dev.ucp.shopping.discount':[{version:'2026-04-08',extends:'dev.ucp.shopping.checkout'}]}}});assert.equal(r.capabilities['dev.ucp.shopping.discount'],undefined)});

test('UCP extension requires protocol range and capability versions',()=>{
 const root={...checkout};
 const ext={version:'2026-04-08',extends:'dev.ucp.shopping.checkout',requires:{protocol:{min:'2026-04-08',max:'2026-09-01'},capabilities:{'dev.ucp.shopping.checkout':{min:'2026-04-08'}}}};
 const business={version:'2026-04-08',capabilities:{'dev.ucp.shopping.checkout':[root],'dev.ucp.shopping.discount':[ext]}};
 const platform={version:'2026-04-08',capabilities:{'dev.ucp.shopping.checkout':[root],'dev.ucp.shopping.discount':[ext]}};
 const r=p.negotiateUcp({business,platform,requiredCapabilities:['dev.ucp.shopping.discount']});
 assert.equal(r.ok,true);assert.ok(r.capabilities['dev.ucp.shopping.discount']);
});

test('UCP extension is excluded fail-closed when declared protocol requirement is unmet',()=>{
 const root={...checkout};
 const ext={version:'2026-04-08',extends:'dev.ucp.shopping.checkout',requires:{protocol:{min:'2026-09-01'}}};
 const business={version:'2026-04-08',capabilities:{'dev.ucp.shopping.checkout':[root],'dev.ucp.shopping.discount':[ext]}};
 const platform={version:'2026-04-08',capabilities:{'dev.ucp.shopping.checkout':[root],'dev.ucp.shopping.discount':[ext]}};
 const r=p.negotiateUcp({business,platform,requiredCapabilities:['dev.ucp.shopping.discount']});
 assert.equal(r.ok,false);assert.equal(r.capabilities['dev.ucp.shopping.discount'],undefined);assert.ok(r.reasons.some(x=>x.includes('REQUIRES_PROTOCOL_VERSION_UNSATISFIED')));
});
