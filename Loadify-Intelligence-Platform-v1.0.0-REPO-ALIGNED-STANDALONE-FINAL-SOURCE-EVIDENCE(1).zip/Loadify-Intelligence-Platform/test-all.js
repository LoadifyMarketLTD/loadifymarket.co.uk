'use strict';
const {runTestSuites}=require('./test-runner');
const r=runTestSuites();
for(const x of r.failed){console.error(`FAIL ${x.suite}`);process.stderr.write(x.stderr||x.stdout);}
console.log(JSON.stringify({suites:r.suites.length,passed:r.suites.length-r.failed.length,failed:r.failed.length}));
if(r.failed.length)process.exitCode=1;
