'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const fs=require('fs');const path=require('path');const {server}=require('./server');
const statePath=path.join(__dirname,'data/state.json');let base,original;
test.before(async()=>{original=fs.readFileSync(statePath);const s=JSON.parse(original);s.approvals=[
{id:'LOW',type:'Experiment',title:'Low risk',risk:'R1',status:'PENDING',requestedById:'AGENT-1',requestedBy:'Agent',policyRef:'p'},
{id:'HIGH',type:'Trust',title:'High risk',risk:'R3',status:'PENDING',requestedById:'AGENT-2',requestedBy:'Agent',policyRef:'p',evidenceRef:'e',requireFourEyes:true}
];fs.writeFileSync(statePath,JSON.stringify(s,null,2));await new Promise(r=>server.listen(0,'127.0.0.1',r));base=`http://127.0.0.1:${server.address().port}`;});
test.after(async()=>{await new Promise(r=>server.close(r));fs.writeFileSync(statePath,original);});
test('low-risk persistent approval is policy-authorized',async()=>{const r=await fetch(base+'/api/approvals/LOW/approve',{method:'POST',headers:{'content-type':'application/json'},body:'{}'});assert.equal(r.status,200);assert.equal((await r.json()).status,'APPROVED');});
test('high-risk first approval stays pending for distinct second approver',async()=>{const r=await fetch(base+'/api/approvals/HIGH/approve',{method:'POST',headers:{'content-type':'application/json'},body:'{}'});assert.equal(r.status,202);const j=await r.json();assert.equal(j.status,'PENDING');assert.equal(j.decision,'PENDING_SECOND_APPROVER');});
test('same local operator cannot provide second high-risk approval',async()=>{const r=await fetch(base+'/api/approvals/HIGH/approve',{method:'POST',headers:{'content-type':'application/json'},body:'{}'});assert.equal(r.status,403);const j=await r.json();assert.ok(j.decision.reasons.includes('FOUR_EYES_REQUIRES_DISTINCT_APPROVER'));});
