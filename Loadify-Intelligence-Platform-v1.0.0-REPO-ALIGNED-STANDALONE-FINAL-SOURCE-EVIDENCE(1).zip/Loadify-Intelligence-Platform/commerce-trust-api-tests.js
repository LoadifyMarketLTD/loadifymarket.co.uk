'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const {server}=require('./server');
let base;test.before(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));base=`http://127.0.0.1:${server.address().port}`});test.after(async()=>new Promise(r=>server.close(r)));
async function post(p,b){const r=await fetch(base+p,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(b)});return r.json();}
test('stock trust API fails closed on stale stock',async()=>{const r=await post('/api/trust/stock',{quantity:3,observedAt:'2020-01-01T00:00:00Z',now:'2026-08-20T20:00:00Z'});assert.equal(r.preCheckoutAllowed,false)});
test('field provenance API preserves field source',async()=>{const r=await post('/api/evidence/fields/provenance',{fields:{brand:'Acme'},evidence:[{field:'brand',sourceId:'M',authority:'manufacturer',observedAt:new Date().toISOString(),integrityVerified:true,corroboratingSources:2}]});assert.equal(r.brand.sources[0].sourceId,'M')});
