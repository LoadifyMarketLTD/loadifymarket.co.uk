'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
process.env.PORT='4231';
const {server}=require('./server');
server.listen(4231,'127.0.0.1');
const base='http://127.0.0.1:4231';
async function post(path,body){const r=await fetch(base+path,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});assert.equal(r.status,200);return r.json();}

test('LLM Top 10 posture endpoint exposes exactly ten deterministic guardrails',async()=>{const r=await fetch(base+'/api/security/llm-top10/posture');assert.equal(r.status,200);const b=await r.json();assert.equal(b.risks.length,10);assert.equal(b.risks[0].id,'LLM01');assert.equal(b.risks[9].id,'LLM10');});
test('LLM assessment endpoint blocks unvalidated downstream execution',async()=>{const b=await post('/api/security/llm-top10/assess',{downstreamExecution:true,outputValidated:false});assert.equal(b.decision,'DENY');assert.ok(b.triggeredRisks.includes('LLM10'));});
test.after(()=>new Promise(resolve=>server.close(resolve)));
