'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const fs=require('fs');
const engine=require('./lib/control-metrics-engine');const sim=require('./lib/simulation-engine');
const {server,defaultState}=require('./server');

test('control metrics separates runtime-derived, synthetic, and canonical-limit values',()=>{
  const out=engine.derive({state:defaultState,simulation:sim.snapshot({seed:'control-metrics'}),fixtures:sim.fixtures({seed:'control-metrics'})});
  assert.equal(out.source,'CONTROL_METRICS_ENGINE');
  assert.equal(out.liveMarketplace,false);
  assert.equal(out.provenance.derivedFromRuntimeState,true);
  assert.equal(out.provenance.syntheticFieldsAuthoritativeForProduction,false);
  assert.equal(out.limits.economicExposureGbp,0);
  assert.ok(out.derived.healthyAgents>0);
});

test('control metrics endpoint exposes canonical values',async(t)=>{
  await new Promise(r=>server.listen(0,'127.0.0.1',r));t.after(()=>new Promise(r=>server.close(r)));
  const r=await fetch(`http://127.0.0.1:${server.address().port}/api/dashboard/control-metrics`);assert.equal(r.status,200);const j=await r.json();assert.equal(j.limits.version,'CONTROL_LIMITS_V1');assert.equal(j.provenance.limitsCanonical,true);
});

test('control-plane UI hydrates control metrics instead of fixed headline values',()=>{
  const app=fs.readFileSync('./app.js','utf8');assert.match(app,/api\/dashboard\/control-metrics/);assert.match(app,/controlMetrics/);
  for(const literal of ["kpi('Autopilot Health','92/100'","kpi('Active experiments','3'","kpi('Global holdout','5%'","kpi('Daily AI budget','£50'","kpi('Open cases','5'","kpi('Registered AI systems','14'"]) assert.equal(app.includes(literal),false,literal);
});
