'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const {getPolicyBundle,validatePolicyBundle}=require('./lib/policy-bundle-engine');
const {getConnectorRegistry,validateRegistry}=require('./lib/connector-registry-engine');

test('canonical policy bundle is immutable-by-agent and defaults high risk to deny',()=>{
  const b=getPolicyBundle();const v=validatePolicyBundle(b);
  assert.equal(v.valid,true);assert.equal(v.count,20);assert.equal(b.defaultHighRiskDecision,'DENY');assert.equal(b.mutableByAgents,false);
  const ids=b.rules.map(r=>r.id);assert.equal(new Set(ids).size,20);assert.ok(b.rules.every(r=>r.agentMutable===false));
});

test('standalone connector registry has no live connections or credentials',()=>{
  const r=getConnectorRegistry();const v=validateRegistry(r);
  assert.equal(v.valid,true);assert.equal(r.liveConnectionsEnabled,false);assert.equal(r.count,7);
  assert.ok(r.items.every(c=>c.liveConnection===false));assert.ok(r.items.every(c=>c.credentialMode==='NONE'));
  assert.ok(r.items.every(c=>['NOT_CONNECTED','SANDBOX_ADAPTER'].includes(c.status)));
});
