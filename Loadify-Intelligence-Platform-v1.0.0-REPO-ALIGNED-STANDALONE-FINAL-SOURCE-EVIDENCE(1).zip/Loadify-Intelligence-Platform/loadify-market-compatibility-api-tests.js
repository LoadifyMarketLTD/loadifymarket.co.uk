'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const {server}=require('./server');
let base;
test.before(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));base=`http://127.0.0.1:${server.address().port}`;});
test.after(async()=>new Promise(r=>server.close(r)));
async function post(p,b){const r=await fetch(base+p,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(b)});return {status:r.status,body:await r.json()};}
test('runtime exposes an explicit disconnected Loadify Market compatibility posture',async()=>{
 const r=await fetch(base+'/api/integrations/loadify-market/compatibility');assert.equal(r.status,200);const j=await r.json();
 assert.equal(j.decision,'ALIGNED_DISCONNECTED');assert.equal(j.liveConnection,false);assert.equal(j.repository,'LoadifyMarketLTD/loadifymarket.co.uk');
});
test('runtime compatibility API admits market facts only as read-only evidence',async()=>{
 const r=await post('/api/integrations/loadify-market/fact/admit',{sourceSystem:'LOADIFY_MARKET',entityType:'supplier_offer',entityRef:'o1',observedAt:'2026-08-21T20:30:00Z',evidenceRef:'ev1',schemaVersion:1});
 assert.equal(r.status,200);assert.equal(r.body.admitted,true);assert.equal(r.body.readOnly,true);
});
test('runtime compatibility API denies direct supplier-order execution',async()=>{
 const r=await post('/api/integrations/loadify-market/action/assess',{intentClass:'REQUEST_BOUNDED_ACTION',operation:'SUPPLIER_ORDER_SUBMIT',authorizationRef:'a',evidenceRef:'e',correlationId:'c'});
 assert.equal(r.status,200);assert.equal(r.body.allowed,false);assert.ok(r.body.reasons.includes('DIRECT_OPERATION_FORBIDDEN'));
});
