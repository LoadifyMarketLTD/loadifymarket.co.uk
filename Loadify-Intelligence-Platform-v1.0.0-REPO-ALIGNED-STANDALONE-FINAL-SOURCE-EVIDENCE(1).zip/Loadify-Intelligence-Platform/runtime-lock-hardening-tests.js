'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const r=require('./lib/runtime-startup-engine');

test('runtime lock refuses symlink and hard-link lock payloads instead of following them',()=>{
  const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'lip-lock-hardening-'));
  const target=path.join(tmp,'target.json');fs.writeFileSync(target,JSON.stringify({pid:99999999,startedAt:'2000-01-01T00:00:00Z'}));
  const symlink=path.join(tmp,'runtime.lock');fs.symlinkSync(target,symlink);
  let out=r.acquireRuntimeLock({lockFile:symlink});assert.equal(out.acquired,false);assert.equal(out.reason,'RUNTIME_LOCK_UNSAFE_FILE_TYPE');
  fs.unlinkSync(symlink);const hard=path.join(tmp,'runtime.lock');fs.linkSync(target,hard);
  out=r.acquireRuntimeLock({lockFile:hard});assert.equal(out.acquired,false);assert.equal(out.reason,'RUNTIME_LOCK_UNSAFE_FILE_TYPE');
  fs.rmSync(tmp,{recursive:true,force:true});
});

test('runtime lock recovers malformed stale regular locks but never replaces a live owner',()=>{
  const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'lip-lock-recovery-'));const lock=path.join(tmp,'runtime.lock');
  fs.writeFileSync(lock,'{bad json');
  let out=r.acquireRuntimeLock({lockFile:lock});assert.equal(out.acquired,true);assert.equal(out.recoveredStale,true);assert.equal(r.releaseRuntimeLock({lockFile:lock}),true);
  fs.writeFileSync(lock,JSON.stringify({pid:process.pid,startedAt:'invalid'}));
  out=r.acquireRuntimeLock({lockFile:lock});assert.equal(out.acquired,false);assert.equal(out.reason,'RUNTIME_ALREADY_ACTIVE');
  fs.rmSync(tmp,{recursive:true,force:true});
});

test('runtime lock refuses oversized lock files and symlinked parent directories',()=>{
  const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'lip-lock-dir-'));const lock=path.join(tmp,'runtime.lock');fs.writeFileSync(lock,'x'.repeat(5000));
  let out=r.acquireRuntimeLock({lockFile:lock});assert.equal(out.acquired,false);assert.equal(out.reason,'RUNTIME_LOCK_TOO_LARGE');
  fs.rmSync(lock);const real=path.join(tmp,'real');fs.mkdirSync(real);const linked=path.join(tmp,'linked');fs.symlinkSync(real,linked,'dir');
  out=r.acquireRuntimeLock({lockFile:path.join(linked,'runtime.lock')});assert.equal(out.acquired,false);assert.equal(out.reason,'RUNTIME_LOCK_UNSAFE_DIRECTORY');
  fs.rmSync(tmp,{recursive:true,force:true});
});
