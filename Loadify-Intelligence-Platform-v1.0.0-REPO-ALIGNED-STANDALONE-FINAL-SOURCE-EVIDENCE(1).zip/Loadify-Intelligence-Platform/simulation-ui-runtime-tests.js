'use strict';const test=require('node:test');const assert=require('node:assert/strict');const fs=require('fs');
test('Mission Control consumes explicit synthetic simulation runtime',()=>{const s=fs.readFileSync('./app.js','utf8');assert.match(s,/api\/simulation\/snapshot/);assert.match(s,/Synthetic Marketplace Simulator/);assert.match(s,/state\.simulation/);});
