'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const fs=require('fs');
const app=fs.readFileSync('./app.js','utf8'),css=fs.readFileSync('./styles.css','utf8');
test('UI exposes skip link and main landmark target',()=>{assert.match(app,/skip-link/);assert.match(app,/id=\\?"mainContent/)});
test('search and mobile navigation have accessible names',()=>{assert.match(app,/aria-label=\\?"Search control plane modules/);assert.match(app,/aria-label=\\?"Toggle navigation/)});
test('dialogs expose aria semantics and form labels are associated',()=>{assert.match(app,/role=\\?"dialog/);assert.match(app,/label for=\\?"expName/);assert.match(app,/aria-modal=\\?"true/)});
test('dynamic toast is announced and reduced motion is respected',()=>{assert.match(app,/aria-live/);assert.match(css,/prefers-reduced-motion/)});
