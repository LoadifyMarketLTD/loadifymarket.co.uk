'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const fs=require('fs');
const server=fs.readFileSync('./server.js','utf8');
const registry=JSON.parse(fs.readFileSync('./data/feature-registry.json','utf8'));
const state=JSON.parse(fs.readFileSync('./data/state.json','utf8'));
const manifest=JSON.parse(fs.readFileSync('./data/system-manifest.json','utf8'));

test('no exact API route+method collisions exist',()=>{
 const re=/if \(p === '([^']+)' && req\.method === '([^']+)'\)/g; const seen=new Map(),dupes=[];let m;
 while((m=re.exec(server))){const key=`${m[2]} ${m[1]}`;if(seen.has(key))dupes.push({key,first:seen.get(key),second:m.index});else seen.set(key,m.index);}
 assert.deepEqual(dupes,[]);
});
test('all canonical features are implementation-backed and registry IDs are unique/continuous',()=>{assert.ok(registry.length>=820);assert.equal(registry.filter(x=>x.status!=='IMPLEMENTED_MODEL').length,0);const ids=registry.map(x=>x.id);assert.equal(new Set(ids).size,ids.length);for(let i=0;i<ids.length;i++)assert.equal(ids[i],`LIP-${String(i+1).padStart(3,'0')}`);});
test('standalone state has no connected marketplace',()=>{assert.equal(state.environment,'standalone');assert.equal(state.connectedMarketplace,null);});
test('source does not contain obvious live secret assignments',()=>{
 const files=['server.js','app.js',...fs.readdirSync('./lib').filter(x=>x.endsWith('.js')).map(x=>'lib/'+x)];
 const bad=[];const pats=[/sk_live_[A-Za-z0-9]+/g,/AKIA[0-9A-Z]{16}/g,/-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/g,/SUPABASE_SERVICE_ROLE_KEY\s*=\s*['\"][^'\"]+/g];
 for(const f of files){const s=fs.readFileSync(f,'utf8');for(const p of pats)if(p.test(s))bad.push(f);}
 assert.deepEqual([...new Set(bad)],[]);
});
test('manifest remains standalone and production connectors are not silently enabled',()=>{
 assert.notEqual(manifest.environment,'production');
 const text=JSON.stringify(manifest).toLowerCase();assert.equal(text.includes('live_connected'),false);
});
test('security headers include CSP, nosniff and no-store for APIs',()=>{assert.match(server,/Content-Security-Policy/);assert.match(server,/X-Content-Type-Options/);assert.match(server,/Cache-Control':'no-store/);});
