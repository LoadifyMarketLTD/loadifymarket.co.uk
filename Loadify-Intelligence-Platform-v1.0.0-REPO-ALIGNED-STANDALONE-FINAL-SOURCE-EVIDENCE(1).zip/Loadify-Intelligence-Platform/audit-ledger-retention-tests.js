'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const ledger=require('./lib/audit-ledger-engine');
const event=i=>({id:`EV-${i}`,at:new Date(1700000000000+i).toISOString(),actorId:'TEST',action:`action-${i}`,result:'RECORDED'});
test('bounded compaction retains newest events and rebases a valid chain',()=>{let l=[];for(let i=0;i<8;i++)l=ledger.append(l,event(i));const c=ledger.compact(l,5);assert.equal(c.length,5);assert.equal(c[0].id,'EV-3');assert.equal(c[0].previousHash,null);assert.equal(ledger.verify(c).valid,true)});
test('append refuses to extend a tampered chain',()=>{let l=ledger.append([],event(1));l[0].action='tampered';assert.throws(()=>ledger.append(l,event(2)),/INVALID_CHAIN/)});
test('compaction refuses to launder a tampered chain',()=>{let l=ledger.append([],event(1));l[0].hash='0'.repeat(64);assert.throws(()=>ledger.compact(l,1),/INVALID_CHAIN/)});
test('verifier rejects malformed identifiers timestamps and hashes without throwing',()=>{const r=ledger.verify([{id:'',at:'not-a-date',previousHash:null,hash:'bad'}]);assert.equal(r.valid,false);for(const reason of ['INVALID_EVENT_ID','INVALID_EVENT_TIMESTAMP','INVALID_HASH_FORMAT'])assert.ok(r.failures.some(x=>x.reason===reason))});
test('verifier rejects duplicate event identifiers',()=>{let l=[];l=ledger.append(l,event(1));l=ledger.append(l,event(2));l[1].id=l[0].id;const {hash,...body}=l[1];l[1].hash=ledger.hashEntry(body);assert.ok(ledger.verify(l).failures.some(x=>x.reason==='DUPLICATE_EVENT_ID'))});
